@echo off
setlocal EnableExtensions
title LOMAMO CareLink DIMS 6.0 - Offline Launcher
cd /d "%~dp0"
set "APP=LOMAMO-CareLink-DIMS-v6.0.html"

if not exist "%APP%" goto :missing
if /i "%~1"=="--auto" goto :lan

:menu
cls
echo.
echo   ============================================================
echo.
echo      LOMAMO FOUNDATION   .   CARELINK DIMS  v6.0
echo      Offline demonstration launcher
echo.
echo   ============================================================
echo.
echo      [1]  Open on this computer only
echo           No server. Records stay in this browser.
echo.
echo      [2]  Start the office server (recommended)
echo           The host computer holds the database. Tablets and
echo           laptops on the Wi-Fi share the same records.
echo.
echo      [3]  Check the network and firewall
echo      [4]  Read the setup and demonstration guide
echo.
echo      [0]  Exit
echo.
choice /c 12340 /n /m "      Choose 1, 2, 3, 4 or 0:  "
if errorlevel 5 goto :end
if errorlevel 4 goto :guide
if errorlevel 3 goto :netcheck
if errorlevel 2 goto :lan
goto :local

:local
echo.
echo   Opening the application. If your browser asks, allow it to
echo   open - the file is local and needs no permission.
echo.
start "" "%APP%"
exit /b 0

:netcheck
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\network-status.ps1"
echo.
pause
goto :menu

:guide
start "" notepad "%~dp0README-FIRST.txt"
goto :menu

:lan
cls
echo.
echo   Preparing the shared demonstration server...
echo.
set "PORT="
for %%P in (8000 8080 8081 8090) do (
  if not defined PORT (
    netstat -an | findstr /R /C:":%%P .*LISTENING" >nul 2>&1
    if errorlevel 1 set "PORT=%%P"
  )
)
if not defined PORT (
  echo   Ports 8000, 8080, 8081 and 8090 are all in use.
  echo   Close whatever else is serving on those ports and try again.
  echo.
  pause
  goto :menu
)

set "PY="
python -c "import sys" >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY (
  py -3 -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PY=py -3"
)

echo   ------------------------------------------------------------
echo     THE ADDRESSES TO USE
echo   ------------------------------------------------------------
echo.
echo     On this computer:
echo        http://localhost:%PORT%/
echo.
echo     On a tablet or another laptop on the same Wi-Fi:
for /f "usebackq delims=" %%I in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\lan-ip.ps1"`) do echo        http://%%I:%PORT%/
echo.
echo   ------------------------------------------------------------
echo.
echo   Configuring Windows Wi-Fi profile and local subnet firewall automatically...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\firewall.ps1" -Port %PORT%

echo.
echo   Starting the server. The browser will open in a moment.
echo   If it opens before the server is ready, press F5 once.
echo.
echo   The database is created beside this file, in the folder "data".
echo   Copy that folder as part of your weekly off-device backup.
echo.
echo   KEEP THIS WINDOW OPEN while you demonstrate.
echo   Close it, or press Ctrl+C twice, to stop sharing.
echo.
start "" "http://localhost:%PORT%/"

set "CARELINK_DATA_DIR=%~dp0data"
if defined PY (
  %PY% "%~dp0server.py" --port %PORT%
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\serve.ps1" -Port %PORT% -Root "%~dp0."
)

echo.
echo   The server has stopped. Nothing lost on any device.
echo.
pause
goto :menu

:missing
echo.
echo   ERROR
echo   -----
echo   %APP% is not in this folder.
echo.
echo   Keep start.bat in the same folder as the application file,
echo   or rename the application back to its original name.
echo.
pause
exit /b 1

:end
endlocal
exit /b 0
