#!/bin/sh
# macos-firewall.sh - let devices on the office network reach CareLink DIMS on this Mac.
#
#   sudo ./macos-firewall.sh [--port 8000] [--subnet 192.168.1.0/24]
#   sudo ./macos-firewall.sh --remove
#   ./macos-firewall.sh --dry-run          show what would run, change nothing
#
# Two things are done. The built-in application firewall is told to allow
# python3 to accept connections, and a packet-filter rule limits the port to
# the local subnet. Neither opens anything to the internet.
set -u
PORT=8000; SUBNET=""; ACTION=add; DRY=0
ANCHOR="com.apple/carelink"
SF="/usr/libexec/ApplicationFirewall/socketfilterfw"

usage() { sed -n '2,10p' "$0" | sed 's/^# \{0,1\}//'; }
say()  { printf '%s\n' "$*"; }
run()  { if [ "$DRY" = 1 ]; then say "  [dry-run] $*"; else "$@"; fi; }

while [ $# -gt 0 ]; do
  case "$1" in
    --port)    PORT="${2:-}"; shift 2 ;;
    --subnet)  SUBNET="${2:-}"; shift 2 ;;
    --remove)  ACTION=remove; shift ;;
    --dry-run) DRY=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) say "Unknown option: $1"; usage; exit 2 ;;
  esac
done
case "$PORT" in ''|*[!0-9]*) say "The port must be a number."; exit 2 ;; esac
if [ "$PORT" -lt 1 ] || [ "$PORT" -gt 65535 ]; then say "The port must be 1 to 65535."; exit 2; fi

# the subnet this Mac is on: address and mask of the first active interface
detect_subnet() {
  for i in en0 en1 en2 en3; do
    ip="$(ipconfig getifaddr "$i" 2>/dev/null)"; mask="$(ipconfig getoption "$i" subnet_mask 2>/dev/null)"
    [ -n "$ip" ] && [ -n "$mask" ] || continue
    printf '%s %s\n' "$ip" "$mask" | awk '
      function bits(m){ return (m==255)?8:(m==254)?7:(m==252)?6:(m==248)?5:(m==240)?4:(m==224)?3:(m==192)?2:(m==128)?1:0 }
      { split($1,a,"."); split($2,m,".");
        for(k=1;k<=4;k++){ blk=256-m[k]; n[k]=int(a[k]/blk)*blk; p+=bits(m[k]) }
        printf "%d.%d.%d.%d/%d\n", n[1],n[2],n[3],n[4],p }'
    return 0
  done
  return 1
}
private_cidr() { printf '%s' "$1" | grep -Eq '^(10\.|172\.(1[6-9]|2[0-9]|3[01])\.|192\.168\.)'; }

if [ "$ACTION" = "add" ]; then
  [ -n "$SUBNET" ] || SUBNET="$(detect_subnet)"
  if [ -z "$SUBNET" ]; then say "Could not work out the office network. Give --subnet, for example 192.168.1.0/24"; exit 2; fi
  if ! printf '%s' "$SUBNET" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}/([0-9]|[12][0-9]|3[0-2])$'; then say "That subnet is not valid: $SUBNET"; exit 2; fi
  if ! private_cidr "$SUBNET"; then say "Refusing to open the port to a public range: $SUBNET"; exit 2; fi
fi
if [ "$DRY" != 1 ] && [ "$(id -u)" != 0 ]; then say "Run this with sudo."; exit 1; fi

PY="$(command -v python3 || true)"
say ""
say "  CareLink DIMS  -  macOS firewall"
if [ "$ACTION" = "add" ]; then
  say "  Allow TCP $PORT from $SUBNET only"
  if [ -n "$PY" ]; then
    run "$SF" --add "$PY"
    run "$SF" --unblockapp "$PY"
  fi
  RULES="pass in quick proto tcp from $SUBNET to any port $PORT
block in quick proto tcp from any to any port $PORT"
  if [ "$DRY" = 1 ]; then
    say "  [dry-run] pfctl -a $ANCHOR -f -   with these rules:"; printf '%s\n' "$RULES" | sed 's/^/                /'
    say "  [dry-run] pfctl -E"
  else
    printf '%s\n' "$RULES" | pfctl -a "$ANCHOR" -f - && pfctl -E >/dev/null 2>&1
  fi
  say "  Done. Other devices on $SUBNET can now reach port $PORT."
else
  [ -n "$PY" ] && run "$SF" --remove "$PY"
  run pfctl -a "$ANCHOR" -F all
  say "  Done. The CareLink rules are removed."
fi
