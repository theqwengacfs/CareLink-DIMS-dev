#!/bin/sh
# linux-firewall.sh - let devices on the office network reach CareLink DIMS, and nobody else.
#
#   sudo ./linux-firewall.sh [--port 8000] [--subnet 192.168.1.0/24]
#   sudo ./linux-firewall.sh --status
#   sudo ./linux-firewall.sh --remove
#   ./linux-firewall.sh --dry-run          show what would run, change nothing
#   --backend ufw|firewalld|iptables|nft   choose one instead of auto-detecting
#
# One inbound TCP port, from the local subnet only. The subnet is detected from
# the network this computer is on, and only private ranges are ever detected
# (10.x, 172.16-31.x, 192.168.x). Nothing is opened to the internet.
set -u
PORT=8000; SUBNET=""; ACTION=add; DRY=0; BACKEND=""
TAG="CareLink DIMS"

usage() { sed -n '2,13p' "$0" | sed 's/^# \{0,1\}//'; }
have() { command -v "$1" >/dev/null 2>&1; }
say()  { printf '%s\n' "$*"; }
run()  { if [ "$DRY" = 1 ]; then say "  [dry-run] $*"; else "$@"; fi; }

while [ $# -gt 0 ]; do
  case "$1" in
    --port)    PORT="${2:-}"; shift 2 ;;
    --subnet)  SUBNET="${2:-}"; shift 2 ;;
    --backend) BACKEND="${2:-}"; shift 2 ;;
    --remove)  ACTION=remove; shift ;;
    --status)  ACTION=status; shift ;;
    --dry-run) DRY=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) say "Unknown option: $1"; usage; exit 2 ;;
  esac
done

case "$PORT" in ''|*[!0-9]*) say "The port must be a number."; exit 2 ;; esac
if [ "$PORT" -lt 1 ] || [ "$PORT" -gt 65535 ]; then say "The port must be 1 to 65535."; exit 2; fi

valid_cidr() {
  printf '%s' "$1" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}/([0-9]|[12][0-9]|3[0-2])$' || return 1
  printf '%s' "${1%/*}" | awk -F. '{ for (i=1;i<=4;i++) if ($i+0 > 255) exit 1 }'
}
private_cidr() { printf '%s' "$1" | grep -Eq '^(10\.|172\.(1[6-9]|2[0-9]|3[01])\.|192\.168\.)'; }

detect_subnet() {
  have ip || return 1
  # the network the default route uses; failing that, any real private network
  DEV="$(ip -o -4 route show default 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')"
  ip -o -4 route show scope link 2>/dev/null | awk -v want="$DEV" '
    $1 ~ /\// {
      dev=""; for(i=1;i<=NF;i++) if($i=="dev") dev=$(i+1)
      if (dev ~ /^(docker|br-|virbr|veth|lo|tun|tap|wg|tailscale|zt)/) next
      if (want != "" && dev == want) print "0 " $1; else print "1 " $1
    }' | sort | awk '{print $2}' | while read -r r; do
    if private_cidr "$r"; then printf '%s\n' "$r"; break; fi
  done
}

if [ "$ACTION" != "status" ] && [ "$ACTION" != "remove" ]; then
  if [ -z "$SUBNET" ]; then SUBNET="$(detect_subnet | head -n 1)"; fi
  if [ -z "$SUBNET" ]; then
    say "Could not work out the office network automatically."
    say "Give it with --subnet, for example:  --subnet 192.168.1.0/24"; exit 2
  fi
  if ! valid_cidr "$SUBNET"; then say "That subnet is not valid: $SUBNET"; exit 2; fi
  if ! private_cidr "$SUBNET"; then
    say "Refusing to open the port to a public range: $SUBNET"
    say "Use a private network such as 192.168.1.0/24."; exit 2
  fi
fi

if [ "$DRY" != 1 ] && [ "$(id -u)" != 0 ]; then say "Run this with sudo."; exit 1; fi

detect_backend() {
  if [ -n "$BACKEND" ]; then printf '%s' "$BACKEND"; return; fi
  if have ufw && ufw status 2>/dev/null | grep -qi 'status: active'; then printf ufw; return; fi
  if have firewall-cmd && firewall-cmd --state >/dev/null 2>&1; then printf firewalld; return; fi
  if have iptables; then printf iptables; return; fi
  if have nft; then printf nft; return; fi
  printf none
}
B="$(detect_backend)"
case "$B" in ufw|firewalld|iptables|nft) ;; none)
  say "No firewall tool found (ufw, firewalld, iptables, nft)."
  say "If this computer has no firewall, nothing needs opening. Port $PORT is reachable on the LAN already."
  exit 0 ;;
  *) say "Unknown backend: $B"; exit 2 ;; esac

say ""
say "  $TAG  -  firewall ($B)"
[ "$ACTION" = "add" ] && say "  Allow TCP $PORT from $SUBNET only"

do_add() {
  case "$B" in
    ufw)
      run ufw allow from "$SUBNET" to any port "$PORT" proto tcp comment "$TAG" ;;
    firewalld)
      run firewall-cmd --permanent --add-rich-rule="rule family=ipv4 source address=$SUBNET port port=$PORT protocol=tcp accept"
      run firewall-cmd --reload ;;
    iptables)
      # a private chain keeps the rules together and makes removal exact
      if [ "$DRY" = 1 ] || ! iptables -nL CARELINK >/dev/null 2>&1; then run iptables -N CARELINK; fi
      run iptables -F CARELINK
      run iptables -A CARELINK -s "$SUBNET" -j ACCEPT
      run iptables -A CARELINK -j DROP
      if [ "$DRY" = 1 ] || ! iptables -C INPUT -p tcp --dport "$PORT" -j CARELINK >/dev/null 2>&1; then
        run iptables -I INPUT -p tcp --dport "$PORT" -j CARELINK
      fi
      say "  Note: iptables rules last until the next restart unless your system saves them" ;;
    nft)
      say "  Note: an nftables rule in its own table can restrict a port but cannot open one"
      say "  that another table drops. If this computer already blocks incoming traffic,"
      say "  add the accept rule to that ruleset as well."
      run nft add table inet carelink
      run nft add chain inet carelink input '{ type filter hook input priority -5 ; policy accept ; }'
      run nft flush chain inet carelink input
      run nft add rule inet carelink input ip saddr "$SUBNET" tcp dport "$PORT" accept
      run nft add rule inet carelink input tcp dport "$PORT" drop ;;
  esac
}

do_remove() {
  case "$B" in
    ufw)
      run ufw delete allow from "${SUBNET:-any}" to any port "$PORT" proto tcp 2>/dev/null || true
      say "  If a rule remains, list it with:  sudo ufw status numbered" ;;
    firewalld)
      if [ -n "$SUBNET" ]; then
        run firewall-cmd --permanent --remove-rich-rule="rule family=ipv4 source address=$SUBNET port port=$PORT protocol=tcp accept"
      else
        say "  Give --subnet to remove the firewalld rule for that subnet."
      fi
      run firewall-cmd --reload ;;
    iptables)
      run iptables -D INPUT -p tcp --dport "$PORT" -j CARELINK
      run iptables -F CARELINK
      run iptables -X CARELINK ;;
    nft)
      run nft delete table inet carelink ;;
  esac
}

do_status() {
  case "$B" in
    ufw)       ufw status 2>/dev/null | grep -i "$PORT" || say "  No rule for port $PORT." ;;
    firewalld) firewall-cmd --list-rich-rules 2>/dev/null | grep "port=\"$PORT\"" || say "  No rule for port $PORT." ;;
    iptables)  iptables -nL CARELINK 2>/dev/null || say "  No CARELINK chain." ;;
    nft)       nft list table inet carelink 2>/dev/null || say "  No carelink table." ;;
  esac
}

case "$ACTION" in
  add)    do_add;    say "  Done. Other devices on $SUBNET can now reach port $PORT." ;;
  remove) do_remove; say "  Done. The CareLink rule is removed." ;;
  status) do_status ;;
esac
