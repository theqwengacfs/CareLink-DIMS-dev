@echo off
rem Remove the CareLink DIMS firewall rule.
cd /d "%~dp0"
set "PORT=8000"
set /p "PORT=   Port to close [8000]:  "
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\tools\firewall.ps1" -Port %PORT% -Remove
echo.
pause
