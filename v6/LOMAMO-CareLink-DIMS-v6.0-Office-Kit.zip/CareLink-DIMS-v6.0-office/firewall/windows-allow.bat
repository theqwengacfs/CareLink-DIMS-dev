@echo off
rem Allow other devices on this network to reach CareLink DIMS.
cd /d "%~dp0"
set "PORT=8000"
set /p "PORT=   Port the server uses [8000]:  "
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\tools\firewall.ps1" -Port %PORT%
echo.
pause
