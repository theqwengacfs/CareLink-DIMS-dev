PUBLISHING THIS BUILD ON LOVABLE OR ANY STATIC HOST
==================================================


WHAT TO UPLOAD
--------------
The application is one self-contained HTML file. Two routes work:

1. Static hosting (simplest, keeps every feature)
   Upload LOMAMO-CareLink-DIMS-v6.0.html (or index.html, which is the
   same file) to any static host. The page opens, the landing page
   appears and the console runs in the browser. Records live in the
   browser on that device.

2. Source import (for further development)
   Import this folder as a project. index.html is the entry point and
   needs no build step. If your host runs a server, server.py can be
   started separately to provide the shared database; it needs Python
   3.9 or later and no packages.


WHAT A STATIC HOST CANNOT DO
----------------------------
A static host cannot run server.py, so it cannot provide the shared
central database, server-side password hashing, the four-office vote
or the audit chain verification endpoint. Use the office host for
those. The interface states which of these it can see; it does not
pretend to be connected when it is not.

Do not describe a static deployment as a production patient record
system. The Data Protection Act, 2019 obligations apply to wherever
the records actually live.


LOVABLE-SPECIFIC NOTES
----------------------
- Lovable edits React/Vite projects. This file is plain HTML, CSS and
  JavaScript by design, because it must open from a USB stick with no
  toolchain. Uploading the built HTML and using the preview is the
  supported route; rewriting it as a React app is a different project
  and has not been done here.
- If Lovable's preview blocks inline scripts or a Content Security
  Policy is added, the application will not run until that policy
  permits inline script and style. That has not been tested on
  Lovable's platform.
- Nothing in this build calls an external service. There is no API
  key, no analytics and no outbound request, so publishing it exposes
  no third party.


CHECK BEFORE SHARING WIDELY
---------------------------
- Open the file once on the target device and complete first-run setup
  yourself, so no half-finished account travels with the link.
- Do not publish a copy that contains records. Export the database,
  keep it, then start a clean copy.
- Read docs/17_V6_RELEASE.md "What has not been verified" before any
  claim is made to a partner or board.
