# network-status.ps1 - what this computer is sharing, in plain words.
$ErrorActionPreference = "SilentlyContinue"
Write-Host ""
Write-Host "  CARELINK DIMS - NETWORK STATUS"
Write-Host "  ------------------------------------------------------------"
$port = 8000
$rules = @(Get-NetFirewallRule -DisplayName "CareLink DIMS*" -ErrorAction SilentlyContinue)
if ($rules.Count -gt 0) {
  Write-Host "  Firewall rule    : present"
  foreach ($r in $rules) {
    $pf = $r | Get-NetFirewallPortFilter | Select-Object -First 1
    $af = $r | Get-NetFirewallAddressFilter | Select-Object -First 1
    Write-Host ("    " + $r.DisplayName + "  profile: " + $r.Profile + "  from: " + $af.RemoteAddress + "  enabled: " + $r.Enabled)
    if ($pf -and $pf.LocalPort) { $port = [int]$pf.LocalPort }
  }
  Write-Host "  Reach            : private and domain networks, local subnet only"
} else {
  Write-Host "  Firewall rule    : not present"
  Write-Host "  Other devices cannot connect until the rule is added."
}
$listen = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
if ($listen) { Write-Host "  Server           : listening on port $port" }
else { Write-Host "  Server           : not running" }
Write-Host ""
Write-Host "  Addresses on this computer:"
Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike "127.*" } | ForEach-Object {
  Write-Host ("    http://{0}:{1}/" -f $_.IPAddress, $port)
}
Write-Host ""
Write-Host "  Rules of the demonstration:"
Write-Host "    - Office Wi-Fi or a private network only."
Write-Host "    - Do not forward this port on a router."
Write-Host "    - Do not run it on a public hotspot."
Write-Host "    - The host computer holds the only authoritative copy."
Write-Host ""
