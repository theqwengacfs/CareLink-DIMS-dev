# serve.ps1 - minimal static file server, used only when Python is absent.
# PowerShell 2.0+ compatible. Read-only, GET and HEAD, no dependencies.
# Binds to all interfaces so tablets on the same Wi-Fi can reach it.
param(
  [int]$Port = 8080,
  [string]$Root = "."
)

$ErrorActionPreference = "Stop"
$Root = (Resolve-Path -LiteralPath $Root).Path
$mime = @{
  ".html" = "text/html; charset=utf-8"; ".htm" = "text/html; charset=utf-8";
  ".txt"  = "text/plain; charset=utf-8"; ".css" = "text/css; charset=utf-8";
  ".js"   = "application/javascript; charset=utf-8";
  ".json" = "application/json; charset=utf-8";
  ".png"  = "image/png";   ".jpg" = "image/jpeg"; ".jpeg" = "image/jpeg";
  ".gif"  = "image/gif";   ".svg" = "image/svg+xml"; ".ico" = "image/x-icon";
  ".pdf"  = "application/pdf"; ".zip" = "application/zip";
  ".md"   = "text/plain; charset=utf-8"; ".csv" = "text/csv; charset=utf-8"
}

$listener = New-Object -TypeName System.Net.Sockets.TcpListener -ArgumentList ([System.Net.IPAddress]::Any), $Port
$listener.Start()

Write-Host ""
Write-Host "  Serving: $Root"
Write-Host "  Port:    $Port"
Write-Host "  Address: http://localhost:$Port/"
Write-Host ""
Write-Host "  Keep this window open. Close it to stop the server."
Write-Host ""

function Send-Bytes($stream, [string]$status, [string]$ctype, [byte[]]$body, [bool]$headOnly) {
  $head = "HTTP/1.1 $status`r`nContent-Type: $ctype`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n"
  $hb = [System.Text.Encoding]::ASCII.GetBytes($head)
  $stream.Write($hb, 0, $hb.Length)
  if (-not $headOnly) { $stream.Write($body, 0, $body.Length) }
  $stream.Flush()
}

while ($true) {
  $client = $listener.AcceptTcpClient()
  try {
    $client.NoDelay = $true
    $stream = $client.GetStream()
    $stream.ReadTimeout  = 8000
    $stream.WriteTimeout = 15000

    $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::ASCII, $false, 4096, $true)
    $requestLine = $reader.ReadLine()
    if ([string]::IsNullOrWhiteSpace($requestLine)) { $client.Close(); continue }

    # discard headers
    $guard = 0
    while ($guard -lt 100) {
      $guard++
      $line = $reader.ReadLine()
      if ($null -eq $line -or $line -eq "") { break }
    }

    $parts = $requestLine -split ' '
    if ($parts.Length -lt 2) { $client.Close(); continue }
    $method = $parts[0].ToUpper()
    $headOnly = ($method -eq "HEAD")

    if ($method -ne "GET" -and $method -ne "HEAD") {
      $body = [System.Text.Encoding]::UTF8.GetBytes("Method not allowed")
      Send-Bytes $stream "405 Method Not Allowed" "text/plain; charset=utf-8" $body $false
      $client.Close(); continue
    }

    $target = $parts[1]
    $q = $target.IndexOf('?'); if ($q -ge 0) { $target = $target.Substring(0, $q) }
    $target = [System.Uri]::UnescapeDataString($target)
    if ($target -eq "/" -or $target -eq "") { $target = "/index.html" }

    $rel  = $target.TrimStart('/').Replace('/', '\')
    $full = [System.IO.Path]::GetFullPath((Join-Path $Root $rel))
    $inside = $full.StartsWith($Root, [System.StringComparison]::OrdinalIgnoreCase)

    if (-not $inside) {
      $body = [System.Text.Encoding]::UTF8.GetBytes("Forbidden")
      Send-Bytes $stream "403 Forbidden" "text/plain; charset=utf-8" $body $headOnly
      $client.Close(); continue
    }

    if (Test-Path -LiteralPath $full -PathType Container) {
      $idx = Join-Path $full "index.html"
      if (Test-Path -LiteralPath $idx -PathType Leaf) { $full = $idx } else { $full = "" }
    }

    if ($full -ne "" -and (Test-Path -LiteralPath $full -PathType Leaf)) {
      $bytes = [System.IO.File]::ReadAllBytes($full)
      $ext = [System.IO.Path]::GetExtension($full).ToLower()
      $ctype = "application/octet-stream"
      if ($mime.ContainsKey($ext)) { $ctype = $mime[$ext] }
      Send-Bytes $stream "200 OK" $ctype $bytes $headOnly
    } else {
      $body = [System.Text.Encoding]::UTF8.GetBytes("Not found")
      Send-Bytes $stream "404 Not Found" "text/plain; charset=utf-8" $body $headOnly
    }

    $client.Close()
  } catch {
    try { $client.Close() } catch { }
  }
}
