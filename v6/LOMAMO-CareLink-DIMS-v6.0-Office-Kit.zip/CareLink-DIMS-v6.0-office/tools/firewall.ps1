# firewall.ps1 - allow the office port for devices on THIS network only.
# The rule is limited to the private and domain profiles (not a cafe or a phone
# hotspot) and to the local subnet (not the whole internet).
#   powershell -File firewall.ps1 -Port 8000          add the rule
#   powershell -File firewall.ps1 -Port 8000 -Remove  take it away again
# Asks for administrator rights if it does not already have them.
param([int]$Port = 8000, [switch]$Remove)

$rule = "CareLink DIMS (port $Port)"
$bat  = Join-Path $env:TEMP "carelink-firewall-$Port.bat"

$lines = @(
  '@echo off',
  "netsh advfirewall firewall delete rule name=`"$rule`" >nul 2>&1"
)
if ($Remove) {
  $lines += @('echo.', "echo   Rule removed: $rule")
} else {
  $lines += @(
    "netsh advfirewall firewall add rule name=`"$rule`" dir=in action=allow protocol=TCP localport=$Port profile=private,domain remoteip=localsubnet",
    'echo.',
    "echo   Rule added: $rule",
    "echo   TCP $Port, private and domain networks, local subnet only."
  )
}
$lines += @('echo   You can close this window.', 'timeout /t 6 >nul')
Set-Content -Path $bat -Value $lines -Encoding ASCII

$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($admin) {
  Start-Process -FilePath $bat -Wait
} else {
  Write-Host "   Asking Windows for permission to change the firewall..."
  Start-Process -FilePath $bat -Verb RunAs -Wait
}
