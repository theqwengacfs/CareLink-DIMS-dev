# lan-ip.ps1 - print this computer's IPv4 addresses, one per line.
# Used by start.bat to show the address to type on a tablet.
$ErrorActionPreference = "SilentlyContinue"

$list = @()
try {
  $list = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
          Where-Object { $_.IPAddress -notmatch '^(127\.|169\.254\.)' } |
          Select-Object -ExpandProperty IPAddress
} catch { $list = @() }

if (-not $list -or $list.Count -eq 0) {
  $list = [System.Net.Dns]::GetHostAddresses([System.Net.Dns]::GetHostName()) |
          Where-Object { $_.AddressFamily -eq 'InterNetwork' } |
          ForEach-Object { $_.IPAddressToString } |
          Where-Object { $_ -notmatch '^(127\.|169\.254\.)' }
}

foreach ($ip in ($list | Sort-Object -Unique)) { Write-Output $ip }
