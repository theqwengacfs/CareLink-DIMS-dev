LOMAMO FOUNDATION - CARELINK DIMS v6.0
Office kit: one host computer, every device on the office Wi-Fi
================================================================


WHAT THIS IS
------------
CareLink DIMS is one file of software. Styles, code and the Foundation
logo are inside that single HTML file. It runs with no internet
connection. When the office server is started it also runs as a shared
database for every tablet and laptop on the same Wi-Fi.

This build carries no demonstration accounts. The first time it is
opened, it asks for the System Administrator account. When that
account is created, the host issues the official accounts for the
Foundation roster and offers a master credentials file, which is the
only copy of those first passwords. It is saved once, at setup, by the
System Administrator. Nothing is emailed and nothing is stored in a
web page.

Every person changes their own password the first time they sign in.


QUICK START - THE HOST COMPUTER (Windows)
-----------------------------------------
1. Right-click start.bat and choose "Run as administrator" (one time,
   so the firewall rule can be created).
2. Choose 2 to start the office server.
3. Note the address it prints, for example  http://192.168.1.24:8080/
4. Leave that window open. It IS the server.
5. On the host, open the address in a browser.
6. Complete the first-run setup: create the System Administrator
   account, then save the master credentials file when it is offered.

The server keeps its database in a file beside the application
(data/carelink-db.json). Back it up by copying that file. Closing the
window stops sharing but loses nothing.


JOINING FROM A TABLET OR LAPTOP
-------------------------------
1. Join the same office Wi-Fi.
2. Open Chrome and type the address exactly, including http:// and
   the port.
3. The landing page appears. Choose "Proceed to My CareLink Console".
4. Sign in with your own username and the password issued to you.
5. Choose a new password when asked. It is yours from then on.

Every device reads the same central database. A change made on the
tablet appears on the host and on every other device within a second
or two, and is written into the audit chain with the account that made
it. There is no "two devices changed the same record" message: the
host reconciles writes and journals each merge.


IF THE TABLET CANNOT REACH THE ADDRESS
--------------------------------------
- Both devices must be on the same network, not one on Wi-Fi and the
  other on a phone hotspot.
- Windows Firewall is the usual cause. Run start.bat as administrator
  once, choose 3 to check, and allow the rule when asked. The rule
  stays after that.
- Some office networks isolate wireless clients from each other
  ("client isolation"). If yours does, ask whoever manages the router
  to switch that off for the office network.
- The firewall folder (see firewall\FIREWALL-RULES.txt) holds the exact
  subnet rules for Windows, macOS and Linux.


WHAT LIVES IN THIS FOLDER
-------------------------
LOMAMO-CareLink-DIMS-v6.0.html   the entire application
index.html                       the same file, for a web server root
server.py                        the office host
start.bat                        Windows launcher and network check
start.sh                         launcher for macOS and Linux
firewall\                        rules for the three platforms
tools\                           small helper scripts
docs\                            release report and prompt audit


FIRST-RUN NOTES THAT MATTER
---------------------------
- The master credentials file is written once. Save it somewhere
  controlled, not in a shared folder.
- Passwords are stored only as salted hashes. No page can show an
  existing password, including to the System Administrator.
- If a password must be recovered, four offices must agree in the
  system: Director, System Administrator, Chief Program Administrator
  and Chief Program Administrator Assistant. Only then may the System
  Administrator overwrite it, and the county administrator for that
  account then sets a new one. Every step is audited.
- An account can be requested from the landing page or the sign-in
  page. The System Administrator approves it, and the applicant
  receives a username and a one-time activation code which are entered
  on the sign-in page together with a password of their own choosing.
- Session idle lock is 900 seconds (15 minutes) by default and is configurable on
  the host with CARELINK_IDLE_SECONDS.


WHAT HAS NOT BEEN TESTED
------------------------
Two physical devices on a real office network, printing, and any
external integration (DHIS2, KHIS, FHIR, laboratory, pharmacy, SMS).
The adapter boundary exists; no connection is claimed. See
docs/17_V6_RELEASE.md for the full list.


================================================================
LOMAMO Foundation Kenya - Love Matters Most
Serving our Neighbours in Love
