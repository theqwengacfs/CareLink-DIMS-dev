#!/bin/sh
# LOMAMO CareLink DIMS 6.0 - launcher for macOS and Linux
cd "$(dirname "$0")" || exit 1
PORT="${CARELINK_PORT:-8000}"

# pick the first free port from 8000, 8080, 8081, 8090
port_free() { ! (command -v nc >/dev/null 2>&1 && nc -z 127.0.0.1 "$1" >/dev/null 2>&1); }
if [ -z "${CARELINK_PORT:-}" ]; then
  for p in 8000 8080 8081 8090; do
    if port_free "$p"; then PORT="$p"; break; fi
  done
fi

# the addresses other devices should type
lan_ips() {
  if command -v hostname >/dev/null 2>&1 && hostname -I >/dev/null 2>&1; then
    hostname -I | tr ' ' '\n' | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | grep -v '^169\.254\.'
  elif command -v ipconfig >/dev/null 2>&1; then
    for i in en0 en1 en2; do ipconfig getifaddr "$i" 2>/dev/null; done
  fi
}

echo ""
echo "  LOMAMO CareLink DIMS 6.0"
echo "  On this computer:  http://localhost:$PORT/"
for ip in $(lan_ips); do echo "  On other devices:  http://$ip:$PORT/   (same Wi-Fi, not guest Wi-Fi)"; done
echo ""
echo "  Other devices cannot connect until the firewall allows port $PORT."
echo "  Linux:  sudo ./firewall/linux-firewall.sh --port $PORT"
echo "  macOS:  sudo ./firewall/macos-firewall.sh --port $PORT"
echo "  See firewall/FIREWALL-RULES.txt.   Ctrl+C stops the server."
echo ""
(
  sleep 1
  if command -v open >/dev/null 2>&1; then
    open "http://localhost:$PORT/"
  elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "http://localhost:$PORT/" >/dev/null 2>&1
  fi
) &
exec python3 server.py --port "$PORT"
