const { isSnapshotRead, conditionalPrimaryRead } = require('./kv-primary-read.cjs');
const {dispatchWithDeviceCookie}=require('./device-cookies.cjs');
const requireCrypto = require('node:crypto');
/* Full reference-master proof using the actual downloadable package. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const { makeCtx } = require('./dom');

let manifest;
const kv = new Map();
let maxKvRequestBytes = 0;
let maxApiResponseBytes = 0;
const kvResponse = (body, status = 200) => ({ ok: status >= 200 && status < 300, status, json: async () => body });
const keyFromPath = (url, prefix) => decodeURIComponent(url.pathname.slice(prefix.length));

globalThis.fetch = async (input, init = {}) => {
  const url = new URL(String(input));
  assert.equal(url.origin, 'https://kv.test');
  assert.equal(init.headers?.Authorization, 'Bearer reference-e2e-token');
  const bodyBytes = init.body ? Buffer.byteLength(String(init.body)) : 0;
  maxKvRequestBytes = Math.max(maxKvRequestBytes, bodyBytes);
  assert.ok(bodyBytes <= 10 * 1024 * 1024, `KV request exceeded 10 MB: ${bodyBytes}`);
  if (url.pathname.startsWith('/get/')) {
    const key = keyFromPath(url, '/get/');
    return kvResponse({ result: kv.has(key) ? kv.get(key) : null });
  }
  if (url.pathname.startsWith('/set/')) {
    const key = keyFromPath(url, '/set/');
    const value = JSON.parse(init.body);
    assert.equal(typeof value, 'string');
    kv.set(key, value);
    return kvResponse({ result: 'OK' });
  }
  if (url.pathname.startsWith('/del/')) {
    const key = keyFromPath(url, '/del/');
    kv.delete(key);
    return kvResponse({ result: 1 });
  }
  if (url.pathname === '/' && init.method === 'POST') {
    const command = JSON.parse(String(init.body || '[]'));
    const [op, ...args] = command;
    if (op === 'SET') {
      const [key, value, ...options] = args;
      if (options.includes('NX') && kv.has(key)) return kvResponse({ result: null });
      kv.set(key, String(value));
      return kvResponse({ result: 'OK' });
    }
    if (op === 'GET') return kvResponse({ result: kv.has(args[0]) ? kv.get(args[0]) : null });
    if (op === 'EVAL') {
      const script = args[0]; const keyCount = Number(args[1]) || 0;
      const key = args[2]; const value = args[2 + keyCount];
      if (isSnapshotRead(script)) return kvResponse({ result: conditionalPrimaryRead(kv, key, value) });
      if (script.includes('redis.sha1hex')) {
        const actual = kv.has(key) ? requireCrypto.createHash('sha1').update(String(kv.get(key))).digest('hex') : 'missing';
        if (actual !== value) return kvResponse({ result: kv.get(key) === String(args[3 + keyCount]) ? 2 : 0 });
        kv.set(key, String(args[3 + keyCount]));
        return kvResponse({ result: 1 });
      }
      if (script === "return redis.call('GET', KEYS[1])") return kvResponse({ result: kv.has(key) ? kv.get(key) : null });
      if (kv.get(key) !== String(value)) return kvResponse({ result: 0 });
      if (/EXPIRE/.test(script)) return kvResponse({ result: 1 });
      if (/DEL/.test(script)) { kv.delete(key); return kvResponse({ result: 1 }); }
    }
    throw new Error(`Unexpected Redis command: ${op}`);
  }
  throw new Error(`Unexpected KV request: ${url.pathname}`);
};
process.env.KV_REST_API_URL = 'https://kv.test';
process.env.KV_REST_API_TOKEN = 'reference-e2e-token';
delete process.env.UPSTASH_REDIS_REST_URL;
delete process.env.UPSTASH_REDIS_REST_TOKEN;

(async () => {
  const {generateReferenceManifest}=await import('../../api/synthetic-reference.mjs');
  manifest=generateReferenceManifest();
  assert.equal(fs.existsSync(path.join(__dirname,'../../public/master/CareLink-Reference-Master-v6.6.json')),false,'no generated dataset may be committed or published statically');
  const encoded = manifest.chunks.join('');
  assert.equal(encoded.length, manifest.base64Length);
  const compressed = Buffer.from(encoded, 'base64');
  assert.equal(compressed.length, manifest.compressedBytes);
  assert.equal(crypto.createHash('sha256').update(compressed).digest('hex'), manifest.compressedDigest);
  const raw = zlib.brotliDecompressSync(compressed).toString('utf8');
  assert.equal(Buffer.byteLength(raw), manifest.rawBytes);
  assert.equal(crypto.createHash('sha256').update(raw).digest('hex'), manifest.digest);
  const payload = JSON.parse(raw);
  assert.equal(payload.db.patients.length, 4000);
  assert.ok(payload.db.users.every((u) => !u.hash && !u.salt), 'public master must not contain credential material');
  assert.equal(payload.quality.passed, true);
  assert.ok(payload.quality.checks.every(c=>c.passed));

  const { default: handler } = await import('../../api/index.js');
  async function apiFetch(url, opts = {}) {
    const headers = { host: 'carelink.test' };
    for (const [key, value] of Object.entries(opts.headers || {})) headers[key.toLowerCase()] = value;
    const req = { url: `/${url}`, method: opts.method || 'GET', headers, body: opts.body || {}, on() {} };
    let status = 0; let rawResponse = '';
    const res = {
      set statusCode(value) { status = value; }, get statusCode() { return status; },
      setHeader() {}, end(value) { rawResponse = value || ''; },
    };
    await dispatchWithDeviceCookie(handler,req,res);
    const bytes = Buffer.byteLength(rawResponse);
    maxApiResponseBytes = Math.max(maxApiResponseBytes, bytes);
    assert.ok(bytes <= 4.5 * 1024 * 1024, `Vercel response exceeded 4.5 MB for ${url}: ${bytes}`);
    return { ok: status >= 200 && status < 300, status, json: async () => rawResponse ? JSON.parse(rawResponse) : {} };
  }
  function client() {
    return makeCtx({
      location: { hash: '', protocol: 'https:', origin: 'https://carelink.test', host: 'carelink.test' },
      navigator: { userAgent: 'reference-master-e2e' },
      performance: { now: () => Date.now() },
      sessionStorage: { getItem() { return null; }, setItem() {}, removeItem() {} },
      fetch: apiFetch,
    });
  }

  const initialPassword = 'Kx9!vQ2#mTz7Lp';
  const privatePassword = 'Private#2027!xQ';
  const pc = client();
  pc.run('SYNC.queue = () => {};');
  const setup = await pc.run(`PROD_SETUP.completeFourStepHostSetup({
    orgNameVal:'Reference E2E Organisation', shortNameVal:'REF', seedMode:'empty',
    chiefUsername:'chief.admin', chiefPassword:${JSON.stringify(initialPassword)}, loginUrl:'https://carelink.test'
  })`);
  assert.equal(setup.cloudVerified, true);
  const chiefLogin = await pc.run(`AUTH.loginOnline('chief.admin', ${JSON.stringify(initialPassword)}, 'pc')`);
  assert.equal(chiefLogin.ok, true, JSON.stringify(chiefLogin));
  pc.run(`__form = { current:${JSON.stringify(initialPassword)}, password:${JSON.stringify(privatePassword)}, password2:${JSON.stringify(privatePassword)} }; AUTH.mustChange = true;`);
  await pc.run('FORMS.mustchange6(new FormData())');
  assert.equal(pc.run('AUTH.mustChange'), false);

  pc.run(`REFERENCE_MASTER.inspect(${JSON.stringify(manifest)}, {name:'CareLink-Reference-Master-v6.6.json'});`);
  const importHtml = pc.run('renderImport(AUTH.user)');
  assert.ok(/4,000/.test(importHtml) && /reference-master-upload/.test(importHtml) && /Automated quality evidence/.test(importHtml));
  await pc.run('REFERENCE_MASTER.upload()');
  assert.equal(pc.run('REFERENCE_MASTER.phase'), 'done', pc.run('REFERENCE_MASTER.error'));
  assert.equal(pc.run('REFERENCE_MASTER.result.quality.patientRegistryCompleteness'), 100);
  assert.equal(pc.run('DB.db.patients.length'), 4000);
  assert.equal(pc.run('DB.db.visits.length'), payload.counts.visits);
  assert.equal(pc.run('DB.db.pdcas.length'), payload.counts.pdcas);
  assert.equal(pc.run('DB.db.settings.org.name'), 'Reference E2E Organisation', 'live organisation settings must be preserved');
  assert.equal(pc.run('WORKFLOW_ENGINE.completionMatrix(AUTH.user).global.pct'), 100);
  assert.equal(pc.run('REPORTS.dataQuality(AUTH.user).length'), 0);
  assert.equal(pc.run('DB.db.meta.referenceMaster.quality.passed'), true);
  assert.ok(![...kv.keys()].some((key) => key.startsWith('carelink_reference_master_v1_')), 'temporary chunks must be removed after commit');
  const storedEnvelope = JSON.parse(kv.get('carelink_cloud_v66'));
  assert.equal(storedEnvelope.format, 'carelink-cloud-gzip-v1', 'large shared state must use compressed KV storage');

  const pack = await pc.run('PROD_SETUP.activateSystemGlobally({})');
  assert.ok(pack && pack.count > 0, 'global activation must follow the completed reference import');
  const staff = pack.rows.find((r) => r.username === 'caregiver.ombeyi');
  assert.ok(staff, 'a scoped ministry-area caregiver must be provisioned');
  const expectedPatients = JSON.parse(pc.run(`JSON.stringify(DB.db.patients.filter(p=>p.countyId==='kisumu' && p.areaId==='ombeyi').map(p=>p.id))`));
  const expectedPatientIds = new Set(expectedPatients);
  const expectedVisitCount = Number(pc.run(`DB.db.visits.filter(v=>${JSON.stringify([...expectedPatientIds])}.includes(String(v.patientId))).length`));
  assert.ok(expectedPatients.length > 0 && expectedPatients.length < 4000, 'test caregiver scope must be a strict subset of the reference master');

  const tablet = client();
  tablet.run('SYNC.queue = () => {}; DB.load();');
  const health = await tablet.run('hostProbe()');
  tablet.run(`APPX.host = ${JSON.stringify(health)}; SYNC.server = APPX.host;`);
  assert.equal(health.globallyActivated, true);
  const tabletLogin = await tablet.run(`AUTH.loginOnline(${JSON.stringify(staff.username)}, ${JSON.stringify(staff.tempPassword)}, 'tablet')`);
  assert.equal(tabletLogin.ok, true, JSON.stringify(tabletLogin));
  tablet.run(`__form={current:${JSON.stringify(staff.tempPassword)},password:'Reference#Private2027!Xy',password2:'Reference#Private2027!Xy'};`);
  await tablet.run('FORMS.mustchange6(new FormData())');
  assert.equal(tablet.run('DB.db.patients.length'), expectedPatients.length, 'fresh tablet receives only its authorized ministry-area patients');
  assert.deepEqual(JSON.parse(tablet.run(`JSON.stringify(DB.db.patients.map(p=>p.id))`)), expectedPatients, 'out-of-area patient records must not be present on the device');
  assert.equal(tablet.run('DB.db.visits.length'), expectedVisitCount, 'fresh tablet receives only visits linked to its authorized patients');
  assert.equal(tablet.run('DB.db.settings.globallyActivated'), true);
  const loginHtml = tablet.run(`(()=>{ AUTH.logout(); APPX.screen='login'; LOGIN6.tab='demo'; return renderLogin6(); })()`);
  assert.ok(!/data-tab="demo"|data-act="load-demo"|First-run online setup|Live host setup/i.test(loginHtml));

  console.log(`reference-master-e2e: actual master file + ${manifest.chunkCount} chunks + PC/tablet paged sync passed`);
  console.log(`  ${payload.counts.patients.toLocaleString('en-GB')} patients · ${payload.counts.visits.toLocaleString('en-GB')} visits · ${payload.counts.pdcas.toLocaleString('en-GB')} PDCAs · 100% workflow QA · 0 data-quality findings`);
  console.log(`  largest API response ${(maxApiResponseBytes / 1048576).toFixed(2)} MiB · largest KV request ${(maxKvRequestBytes / 1048576).toFixed(2)} MiB`);
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
