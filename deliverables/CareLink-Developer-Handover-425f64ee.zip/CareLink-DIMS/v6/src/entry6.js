/* ============================================================
   entry6.js - Front door, Sign-In, Active Demo Hub & Host Onboarding
   LOMAMO Foundation Kenya · LOMAMO C-DIMS v6.1

   Design rules enforced here:
   - Identical front-door Landing Page on PC, Android Tablet, iPad & Mobile.
   - Sign-in screen fits strictly onto one viewport (100dvh, zero scrollbar)
     across all tabs, including interactive Cross-Departmental Teamwork
     photography directly beneath "One Foundation. One Operating System."
   - Justified typography with hyphenation strictly disabled (hyphens:none)
     so words never split awkwardly across lines.
   - Full 4,000-patient & 47-account multi-department dataset active and
     reloadable in one tap on both PC and Tablet.
   ============================================================ */

const ONB = {
  step:1, host:null, org:{ name:'LOMAMO Foundation Kenya', county:'kisumu', shortName:'LOMAMO', emailDomain:'lomamofoundation.org' },
  admin:{ name:'', username:'', password:'', confirm:'' },
  mode:'host', roster:[], issued:null, seed:'empty', autoFeedCloudMaster:false, _pendingCloudAutoFeed:false, busy:false, error:'',
  hostSetup:null, advice:''
};

const LOGIN6 = {
  tab:'signin', error:'', notice:'', busy:false, mustChangeBusy:false, usernameDraft:'', results:null,
  slide:0, demoFilter:'all'
};

const LOGIN_TEAM_SLIDES = [
  {
    key:'analytics_screen',
    tag:'Cross-Department Case Review',
    title:'Clinical, M&E & Field Caregivers Reviewing Household Progress Together',
    dept:'Medical · Field Care · M&E Data'
  },
  {
    key:'puzzle_hands',
    tag:'Interlocking Departmental Unity',
    title:'Every Department Fitting Together Around One Vulnerable Household',
    dept:'Field · Hospital · Finance · Governance'
  },
  {
    key:'united_hands',
    tag:'Orphan Prevention Covenant',
    title:'Standing Shoulder to Shoulder So Children Grow Up With Their Families',
    dept:'Kisumu & Homa Bay · 10 Ministry Areas'
  },
  {
    key:'boardroom_team',
    tag:'Coordinated County Operations',
    title:'Leadership, Finance & Hospital Focal Desks Aligned on One Shared Record',
    dept:'Executive · Finance · JOOTRH Desk'
  }
];

/* ------------------------------------------------------------ helpers */
async function hostProbe(){
  if(typeof SYNC==='undefined' || !SYNC.available()) return null;
  try{
    const r = await SYNC._json('api/health', { skipAuthHeader:true, timeoutMs:8000 });
    return r.ok ? r.body : null;
  }catch(e){ return null; }
}
/* Entry-point state comes from the same health document on every client.  A
   hosted browser with no health answer is pending/fail-closed, never a new
   demo installation. */
function hostedEntryPending(){
  return typeof SYNC !== 'undefined' && SYNC.available && SYNC.available() &&
    !(typeof APPX !== 'undefined' && APPX.host) && !(SYNC.server);
}
function trialEntryActive(){
  const h = (typeof APPX !== 'undefined' && APPX.host) || (typeof SYNC !== 'undefined' && SYNC.server) || null;
  return !!(h && h.trialMode === true && h.mode === 'isolated-synthetic-trial');
}
function commissionedEntryActive(){
  const h = (typeof APPX !== 'undefined' && APPX.host) || (typeof SYNC !== 'undefined' && SYNC.server) || null;
  return !!(h && (h.commissioned === true || (h.setup && (!h.demoMode || trialEntryActive()))));
}
function demoEntryBlocked(){
  /* No anonymous/shared-password demo identity is valid at any lifecycle
     stage. Demo staff accounts must be explicitly issued through an
     authenticated post-commissioning provisioning workflow. */
  return true;
}
function passwordStrength(pw){
  let n = 0;
  if(pw.length>=10) n++;
  if(pw.length>=14) n++;
  if(/[A-Z]/.test(pw) && /[a-z]/.test(pw)) n++;
  if(/[0-9]/.test(pw)) n++;
  if(/[^A-Za-z0-9]/.test(pw)) n++;
  const label = ['Too short','Weak','Fair','Good','Strong','Very strong'][Math.min(5,n)];
  return { n, label, tone: n>=4?'ok':n===3?'warn':'crit' };
}
function orgName(){ return (DB.db && DB.db.settings && DB.db.settings.org && DB.db.settings.org.name) || 'LOMAMO Foundation Kenya'; }

function credMasterText(issued, host){
  const line = '='.repeat(78);
  const rows = issued.map((a,i)=>
    `${String(i+1).padStart(2,' ')}. ${a.name || a.username}\n` +
    `    Role       ${a.role || '-'}\n` +
    `    Username   ${a.username}\n` +
    `    Password   ${a.password}\n` +
    (a.activation ? `    Activation ${a.activation}\n` : '')
  ).join('\n');
  return `${line}\n  LOMAMO FOUNDATION · CARELINK C-DIMS v${APP.version}\n  OFFICIAL ACCOUNT MASTER FILE  -  CONFIDENTIAL\n${line}\n
Generated      ${new Date().toLocaleString('en-GB')}
Organisation   ${orgName()}
Host computer  ${host || 'the computer running server.py'}
Accounts       ${issued.length}

HOW TO USE THIS FILE
  1. Print it, or copy it to a password manager, then delete it from the
     Downloads folder. It is the only copy that contains these passwords.
  2. Give each person their own line. Do not send the whole sheet.
  3. Each person signs in and is required to choose a new password before
     the console opens. Their new password is stored on the host as a
     salted PBKDF2 hash and cannot be read back by anyone.
  4. If a password must be recovered, the four senior offices (Country
     Director, Chief System Administrator, Chief Program Administrator and
     Program Administrator Assistant) must each approve in their own
     console. The system then replaces the password with a new temporary
     one; the old one is never revealed.
  5. Losing this sheet does not lock anyone out: the administrator can
     re-issue a temporary password from Users & accounts.

${line}\n  ACCOUNTS\n${line}\n
${rows}
${line}
Every password above is temporary and must be changed at first sign-in.
This file contains credentials. Store it as you would store a key.
${line}\n`;
}
function downloadText(name, text, mime='text/plain'){
  const b = new Blob([text], {type:mime});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(b); a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(a.href), 4000);
}

/* Activate the synthetic evaluation set only before the host is commissioned.
   A globally activated host is a hard boundary, not merely a hidden button:
   never seed the browser first and then discover that the server refused the
   bootstrap, because that would leave a convincing local demo beside live data. */
async function activateFullDemoDataset(){
  if(!DB.db) DB.load();
  const globallyActivated = () => typeof PROD_SETUP !== 'undefined' && PROD_SETUP.isGloballyActivated && PROD_SETUP.isGloballyActivated();
  if(globallyActivated()) throw new Error('Demonstration data is locked after global activation.');
  if(commissionedEntryActive()) throw new Error('Demonstration data is locked on this commissioned online installation.');

  let host = (typeof APPX !== 'undefined' && APPX.host) || null;
  if(typeof SYNC !== 'undefined' && SYNC.available()){
    /* Probe before touching the local document.  A commissioned host is not an
       evaluation target, even if it has not completed global activation yet. */
    const probed = await hostProbe();
    if(!probed) throw new Error('The shared online source could not be verified; demonstration data was not loaded locally.');
    host = probed; APPX.host = probed; SYNC.server = probed;
    if(host.globallyActivated || host.demoDisabled){
      throw new Error('Demonstration data is locked after global activation.');
    }
    if(host.setup){
      throw new Error('Demonstration bootstrap is locked on this commissioned online installation.');
    }
  }

  const previousRaw = JSON.stringify(DB.db);
  const previousDirty = typeof APPX !== 'undefined' ? APPX.dirty : false;
  try{
    const count = DB.seedSynthetic({ patients:DEMO_REGISTER.patients, mustChange:false });
    if(typeof SYNC !== 'undefined' && SYNC.available()){
      let r;
      try{
        r = await SYNC._json('api/public/demo-bootstrap', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ db: DB.db })
        });
      }catch(e){
        throw new Error('The shared online source could not be reached; demonstration data was not loaded locally.');
      }
      if(!r || !r.ok || (r.body && r.body.skipped)){
        if(r && r.body && r.body.globallyActivated){
          APPX.host = Object.assign({}, host || {}, { globallyActivated:true, demoDisabled:true });
        }
        throw new Error((r && r.body && r.body.error) || 'The online source refused demonstration bootstrap.');
      }
      const refreshed = await hostProbe();
      if(!refreshed || refreshed.demoMode !== true){
        throw new Error('The online demonstration state could not be verified; no local demo success is being claimed.');
      }
      APPX.host = refreshed; SYNC.server = refreshed; SYNC.rev = refreshed.rev || 0;
    }
    return count;
  }catch(e){
    /* Roll back the local seed on a server-side lock/refusal.  The previous
       document may contain real unsynchronised work and must not be lost. */
    try{ DB.db = JSON.parse(previousRaw); Store.set(DB.KEY, previousRaw); }catch(_e){}
    if(typeof APPX !== 'undefined') APPX.dirty = previousDirty;
    throw e;
  }
}

/* Foundation-confirmed organisation display; does not grant RBAC capabilities. */
const MAJOR_DEPARTMENTS = [
  {name:'Administration',detail:'Founder / President / CEO, Co-Founder, Country Director, County Administrators and County Admin Assistants.'},
  {name:'Field Care',detail:'Ministry Area Coordinators, Caregivers, Community Health Promoters and Community Health Volunteers.'},
  {name:'Hospital',detail:'Medical Case Managers, Nurses / Nurse Assistants, Clinical Officers, approved Community Health Promoters and Hospital Liaison.'},
  {name:'Transport',detail:'Drivers who also serve as caregivers; transport staff may hold procurement head/deputy responsibilities. Each duty requires its own authorisation.'},
  {name:'Media & IT',detail:'Media and information technology.'},
  {name:'Homestay',detail:'Homestay care coordination.'},
  {name:'Procurement',detail:'Sourcing materials across the organisation.'},
  {name:'Finance',detail:'Financial records, expenditure and budgets.'},
  {name:'HR & Staff',detail:'Staff administration.'},
  {name:'Welfare Department',detail:'Staff welfare.'},
  {name:'Internal Operations',detail:'Internal operational coordination.'}
];
/* Eight featured departments in a symmetric hub-and-spoke workflow. Red leads the shared
   centre/connections; secondary colours distinguish departments, never status.
   Keep it semantic, self-contained and available in the Chief's inert preview. */
function renderLandingWorkflow6(){
  const nodes=[
    [230,22,'Administration','red'], [324,52,'Field Care','teal'],
    [354,112,'Hospital','red'], [324,172,'Transport','gold'],
    [230,202,'Media & IT','blue'], [136,172,'Homestay','red'],
    [106,112,'Procurement','teal'], [136,52,'Finance','red']
  ];
  return `<svg viewBox="40 0 380 224" class="ld-scene-svg" role="img" aria-labelledby="ld-workflow-title" aria-describedby="ld-workflow-desc" focusable="false">
    <title id="ld-workflow-title">CareLink system workflow</title>
    <desc id="ld-workflow-desc">CareLink is the shared centre connecting Administration, Field Care, Hospital, Transport, Media &amp; IT, Homestay, Procurement and Finance: eight featured teams from 11 Major Departments. Every department coordinates through one shared system.</desc>
    <g class="ld-workflow-orbits" fill="none" aria-hidden="true">
      <circle cx="230" cy="112" r="82" stroke-dasharray="4 5"/>
      <circle cx="230" cy="112" r="55"/>
    </g>
    <g class="ld-workflow-links" aria-hidden="true">
      ${nodes.map(([x,y])=>`<line x1="230" y1="112" x2="${x}" y2="${y}"/>`).join('')}
    </g>
    <circle class="ld-workflow-halo" cx="230" cy="112" r="41" fill="none" aria-hidden="true"/>
    ${nodes.map(([x,y,label,tone])=>`<g class="ld-workflow-node" data-workflow-node="${esc(label)}" data-tone="${tone}" style="--node-fill:var(--entry-relief-${tone}-fill);--node-accent:var(--entry-relief-${tone})">
      <rect x="${x-56}" y="${y-13}" width="112" height="26" rx="13"/>
      <circle cx="${x-44}" cy="${y}" r="2.6" aria-hidden="true"/>
      <text x="${x-34}" y="${y}" dy=".35em" text-anchor="start">${esc(label)}</text>
    </g>`).join('')}
    <g class="ld-workflow-core">
      <circle cx="230" cy="112" r="35"/>
      <text x="230" y="109" text-anchor="middle" class="ld-workflow-core-name">CareLink</text>
      <text x="230" y="122" text-anchor="middle" class="ld-workflow-core-sub">OS · C-DIMS</text>
    </g>
  </svg>`;
}

/* ------------------------------------------------------------ responsive landing */
function renderLanding6(){
  const th = (typeof landingTheme==='function') ? landingTheme() : { id:'clinic', mode:'light', accent:'#EE0000' };
  const isActivated = (typeof PROD_SETUP !== 'undefined' && PROD_SETUP.isGloballyActivated && PROD_SETUP.isGloballyActivated());
  const isCommissioned = isActivated || commissionedEntryActive();
  const setupPending = hostedEntryPending();
  const layout = typeof CLIENT_UI!=='undefined' ? CLIENT_UI.snapshot() : {width:1280};
  const lakeSource = typeof location!=='undefined' && /^https?:$/.test(location.protocol) ? `./media/lake-workspace-${layout.width>=1600?3840:layout.width>=700?1920:960}.webp` : carelinkPhoto('lake_kisumu');
  const facts = [
    { n: Object.keys(CAPS||{}).length, l:'Capabilities' },
    { n: (typeof COUNTIES!=='undefined'?COUNTIES.length:2), l:'County Offices' },
    { n: (typeof COUNTIES!=='undefined'?COUNTIES.reduce((a,c)=>a+c.areas.length,0):10), l:'Ministry Areas' },
    { n: 11, l:'Major Departments' }
  ];

  return `<div class="ld" data-front="1" data-theme="${esc(th.id)}" data-mode="${esc(th.mode||'dark')}" style="${ENTRY_THEME.style(th.id)}">
    <div class="ld-aurora" aria-hidden="true"><i></i><i></i></div>
    <div class="ld-weave" aria-hidden="true"></div>

    <header class="ld-top">
      <div class="row" style="gap:11px">
        <img src="${window.LOGO||''}" alt="LOMAMO Foundation Kenya" class="ld-logo">
        <div>
          <div class="ld-org">CareLink · ${esc(orgName())}</div>
          <div class="xs ld-dim">CareLink C-DIMS · Unified Operating System · v${esc(APP.version)}</div>
        </div>
      </div>
      <nav class="row ld-nav" aria-label="Public and institutional navigation" style="gap:8px;flex-wrap:wrap">
        <button class="btn ld-btn-arch btn-sm" data-act="goto-architecture"><img src="${carelinkPhoto('united_hands')}" alt="" class="ld-arch-thumb"> How CareLink works</button>
        <button class="btn ld-btn-secondary btn-sm" data-act="goto-public">${ic('eye',14)} Public Impact Portal</button>
        ${!isActivated ? `<button class="btn ld-btn-secondary btn-sm" data-act="login-request">${ic('userplus',14)} Request Access</button>` : ''}
      </nav>
    </header>

    <div class="ld-container ld-front-main" style="--landing-lake:url('${lakeSource}')">
      ${trialEntryActive()?`<div class="alert warn" role="status"><b>TEAM TRIAL · SYNTHETIC DATA ONLY</b><span>Shared evaluation environment. Never enter real patient, staff or confidential information.</span></div>`:''}
      <section class="ld-hero ld-hero-tight">
        <div class="ld-hero-copy">
          <div class="ld-eyebrow">${ic('heart',14)} CareLink · LOMAMO Foundation Kenya</div>
          <h1>CareLink.<br><em>Saving lives, preventing orphans.</em></h1>
          <div class="ld-subhead">One Foundation. One Operating System.</div>
          <p class="ld-lede">Coordinate care, support families and connect every department across Kisumu and Homa Bay.</p>
          <div class="row ld-cta-row" style="align-items:center">
            <button class="btn btn-primary ld-cta ld-btn-primary" data-act="goto-login" aria-label="Proceed to My CareLink Console">${ic('lock',17)} Staff sign in ${ic('chevron',16)}</button>
            ${!trialEntryActive() && !isCommissioned && !setupPending ? `<button class="btn ld-btn-secondary" data-act="goto-onboard" aria-label="Begin Chief System Administrator commissioning">${ic('settings',16)} First-run System Commissioning</button>` : ''}
          </div>
          ${isCommissioned ? `<p class="ld-setup-status">System already commissioned. Sign in with your account, or use <button type="button" class="ld-recovery-link" data-act="login-recovery">password recovery</button>.</p>` : setupPending ? `<p class="ld-setup-status">Checking the shared installation before first-run setup can be offered.</p>` : ''}
          <div class="ld-assure">
            <span>${ic('database',14)} Shared live online database</span>
            <span>${ic('wifi',14)} Available across devices</span>
            <span>${ic('shieldcheck',14)} SHA-256 tamper-evident audit</span>
            <span>${ic('sparkles',14)} Role-scoped workflows &amp; QA</span>
          </div>
        </div>

        <div class="ld-hero-art">
          <div class="ld-canvas-card ld-canvas-tight">
            <figure class="ld-workflow" aria-labelledby="ld-workflow-heading">
              <figcaption class="ld-workflow-head">
                <span class="ld-workflow-kicker">11 Major Departments · 8 featured teams</span>
                <h2 id="ld-workflow-heading">One system. Every team connected.</h2>
              </figcaption>
              ${renderLandingWorkflow6()}
              <div class="ld-workflow-path" aria-label="Capture, coordinate and report through one shared record">
                <span>Capture</span>${ic('chevron',12)}<span>Coordinate</span>${ic('chevron',12)}<span>Report</span>
              </div>
            </figure>
            <div class="ld-facts">
              ${facts.map(f=>`<div class="ld-fact"><b>${num(f.n)}</b><span>${esc(f.l)}</span></div>`).join('')}
            </div>
          </div>
        </div>
      </section>
    </div>

    <footer class="ld-foot ld-foot-tight">
      <div class="ld-foot-inner">
        <div class="ld-foot-brand">
          <b>Serving our Neighbours in Love</b> <span class="xs ld-dim">· Kisumu &amp; Homa Bay County Offices</span>
        </div>
        <div class="xs ld-dim">CareLink C-DIMS v${esc(APP.version)} · Schema ${esc(String(APP.schema))} · DPA-2019 Governed</div>
      </div>
    </footer>
  </div>`;
}

/* ------------------------------------------------------------ dedicated architecture & departments page */
function renderArchitecture6(){
  const th = (typeof landingTheme==='function') ? landingTheme() : { id:'clinic', mode:'light', accent:'#EE0000' };
  const departments = MAJOR_DEPARTMENTS.map((d,i)=>({id:'major-'+i,name:d.name,accent:['#b91c3c','#0f655d','#1e40af'][i%3],...d}));
  const dept = d => `<div class="ld-dept" style="--c:${d.accent}">
      <span class="dot"></span><b>${esc(d.name)}</b><span>${esc(d.detail||d.short||'')}</span></div>`;
  const areaCount = (typeof COUNTIES!=='undefined'?COUNTIES.reduce((a,c)=>a+c.areas.length,0):10);
  const step = (icn, badgeTxt, title, body) => `<article class="ld-step">
      <div class="ld-step-top">
        <div class="ld-step-i">${ic(icn,18)}</div>
        <span class="ld-step-tag">${badgeTxt}</span>
      </div>
      <h3>${title}</h3>
      <p>${body}</p></article>`;
  const pillar = (icn, title, body) => `<article class="ld-pillar">
      <div class="ld-pillar-head"><div class="ld-pi">${ic(icn,18)}</div><h3>${title}</h3></div>
      <p>${body}</p></article>`;
  const teamCards = [
    {
      photo:'field_table',
      tag:'Field Care & Case Management',
      title:'Household Caregivers, Coordinators & Case Managers',
      body:'Supporting caregivers walk alongside vulnerable parents across all ten ministry areas with 30-day PDCA reviews, paediatric Weight/BMI/MUAC growth surveillance, nutrition bags, adherence support and early clinical escalation so children remain safely in family care.'
    },
    {
      photo:'roundtable_forms',
      tag:'Clinical, Pharmacy & JOOTRH Desk',
      title:'Hospital Focal Persons, Clinicians & Pharmacy',
      body:'Hospital dispatch requests flow from caregiver assessment to clinical review, SHA verification, transport facilitation and receipt reconciliation without paperwork getting lost between offices.'
    },
    {
      photo:'charts_overhead',
      tag:'M&E, Finance, HR & Leadership',
      title:'Accountable Stewardship & Verified Reporting',
      body:'Finance, procurement, human resources, media governance and executive leadership coordinate from live budget-vs-expenditure boards, pivot tables, regional maps and tamper-evident audit trails.'
    }
  ];

  return `<div class="ld ld-arch-page" data-theme="${esc(th.id)}" data-mode="${esc(th.mode||'dark')}" style="${ENTRY_THEME.style(th.id)}">
    <div class="ld-aurora" aria-hidden="true"><i></i><i></i></div>
    <div class="ld-weave" aria-hidden="true"></div>

    <header class="ld-top" style="position:sticky;top:0;z-index:20">
      <div class="row" style="gap:12px">
        <img src="${window.LOGO||''}" alt="LOMAMO Foundation Kenya" class="ld-logo">
        <div>
          <div class="ld-org">CareLink Architecture &amp; Institutional Overview</div>
          <div class="xs ld-dim">${esc(orgName())} · Platform Architecture, Departments Working Together &amp; Safeguards</div>
        </div>
      </div>
      <nav class="row ld-nav" style="gap:10px;flex-wrap:wrap">
        <button class="btn ld-btn-secondary btn-sm" data-act="goto-landing">${ic('back',14)} Back to CareLink Front Page</button>
        <button class="btn ld-btn-secondary btn-sm" data-act="goto-public">${ic('eye',14)} Public Impact Portal</button>
        <button class="btn btn-primary ld-btn-primary btn-sm" data-act="open-signin">${ic('lock',14)} Sign In to CareLink</button>
      </nav>
    </header>

    <div class="ld-container">
      <section class="ld-band" style="border-top:none">
        <div class="ld-band-head">
          <div>
            <span class="ld-band-kicker">01 · Platform Architecture</span>
            <h2>From Field Capture to Regional Intelligence</h2>
          </div>
          <p class="ld-band-sub">One continuous pipeline connecting household visits, clinical decisions and verified county reporting across PCs and tablets.</p>
        </div>
        <div class="ld-flow">
          ${step('clipboard','Capture','Online & Offline Field Records','Record assessments with instant National ID returning-beneficiary checks, physical hard-copy form digitisations, 30-day PDCA reviews, child Weight/BMI/MUAC curves and hospital dispatches on tablets or PCs.')}
          ${step('chart','Analyse','Live Pivot Tables, Budgets & Maps','Cross-tabulate active caseloads in interactive pivot matrices, track Expenditure Against Budget in real time, inspect Kisumu and Homa Bay ministry-area maps, and generate aligned Monday reports.')}
          ${step('flow','Interoperate','KHIS / DHIS2 Drafts & CareLink AI','Prepare verified Ministry of Health draft summaries, export DHIS2 dataValueSets and FHIR R4 bundles, and run the AI-assisted Intelligent Workflow Engine toward 100% data completion.')}
        </div>
      </section>

      <section class="ld-band">
        <div class="ld-band-head">
          <div>
            <span class="ld-band-kicker">02 · Departments Working Together</span>
            <h2>United Around Every Household to Prevent Orphans</h2>
          </div>
          <p class="ld-band-sub">Every LOMAMO department contributes its distinct discipline on one shared operating system across ${areaCount} ministry areas.</p>
        </div>
        <div class="ld-team-grid">
          ${teamCards.map(tc=>`<article class="ld-team-card">
            <div class="ld-team-img">
              <img src="${carelinkPhoto(tc.photo)}" alt="${esc(tc.title)}" loading="lazy">
              <span class="ld-team-tag">${esc(tc.tag)}</span>
            </div>
            <div class="ld-team-body">
              <h3>${esc(tc.title)}</h3>
              <p>${esc(tc.body)}</p>
            </div>
          </article>`).join('')}
        </div>
        <div class="ld-band-head"><div><h3>11 Major Departments</h3></div><p class="ld-band-sub">The same structure applies in each county. Cross-department duties require their own authorisation.</p></div>
        <div class="ld-strip" aria-label="All 11 major departments">${departments.map(dept).join('')}</div>
      </section>

      <section class="ld-band">
        <div class="ld-band-head">
          <div>
            <span class="ld-band-kicker">03 · Institutional Safeguards</span>
            <h2>Built on Confidentiality, Stewardship &amp; Human Authority</h2>
          </div>
          <p class="ld-band-sub">Grounded in LOMAMO Foundation governance policies and the Kenya Data Protection Act (2019).</p>
        </div>
        <div class="ld-pillars">
          ${pillar('users','Role-Pure Department Consoles','Caregivers, Hospital Focal Persons, Medical Case Managers, Finance, Fleet, Media, HR and Leadership each see exclusively the tools belonging to their office.')}
          ${pillar('shield','Confidentiality in the Data Layer','Clinical diagnoses, HIV/TB status and safeguarding notes are enforced directly in repository queries and governed by recorded consent.')}
          ${pillar('sparkles','C-DIMS Coins & Staff Recognition','Transparent usage scores, data efficiency ratings, tier badges and C-DIMS Coins celebrate timely field documentation across every county office.')}
          ${pillar('route','AI-Assisted Intelligent Workflow Engine','Smart daily priorities and 100% data-quality guidance assist every staff member across personal, departmental, county and global scopes.')}
        </div>
        <div class="ld-policy">
          <div class="ld-policy-h">${ic('book',15)} Institutional Policy Foundation · Kenya Data Protection Act (2019)</div>
          <div class="ld-policy-row">
            <span>CareLink Trial Usage Report (31 Aug 2026)</span>
            <span>Patient Confidentiality &amp; Ethical Storytelling Policy</span>
            <span>Procurement Policy Framework</span>
            <span>Constitution &amp; Bylaws</span>
            <span>Homestay &amp; Care Centre Protocol</span>
            <span>Vehicle, Transport &amp; Logistics Controls</span>
          </div>
        </div>
        <div class="row" style="justify-content:space-between;margin-top:24px;flex-wrap:wrap;gap:12px">
          <button class="btn ld-btn-secondary" data-act="goto-landing">${ic('back',15)} Return to CareLink Front Page</button>
          <button class="btn btn-primary ld-btn-primary" data-act="open-signin">${ic('lock',15)} Proceed to Sign In ${ic('chevron',15)}</button>
        </div>
      </section>
    </div>

    <footer class="ld-foot">
      <div class="ld-foot-inner">
        <div class="ld-foot-brand">
          <img src="${window.LOGO||''}" alt="" class="ld-logo-sm">
          <div><b>${esc(orgName())}</b> · ${esc(APP.full)}</div>
        </div>
        <div class="xs ld-dim">Love Matters Most · Serving our Neighbours in Love · Version ${esc(APP.version)} · Schema ${esc(String(APP.schema))}</div>
      </div>
    </footer>
  </div>`;
}

/* ------------------------------------------------------------ sign-in */
/* A viewport-fitted brand panel and white access card. Compact spacing keeps
   desktop access on one screen; very small/zoomed views may flow, never clip. */
function renderLogin6(){
  const entryTheme=landingTheme();
  const isActivated = (typeof PROD_SETUP !== 'undefined' && PROD_SETUP.isGloballyActivated && PROD_SETUP.isGloballyActivated());
  const isAwaitingAct = (typeof PROD_SETUP !== 'undefined' && PROD_SETUP.isAwaitingGlobalActivation && PROD_SETUP.isAwaitingGlobalActivation());
  const demoBlocked = demoEntryBlocked();
  if(demoBlocked && LOGIN6.tab === 'demo') LOGIN6.tab = 'signin';
  const t = LOGIN6.tab;
  const tabBtn = (id, label) => `<button class="lg-tab ${t===id?'on':''}" aria-pressed="${t===id}" data-act="login-tab" data-tab="${id}" type="button">${label}</button>`;
  const host = APPX.host;
  const pCount = (DB.db && DB.db.patients) ? DB.db.patients.length : 0;
  const uCount = (DB.db && DB.db.users) ? DB.db.users.length : 0;
  const hostLine = trialEntryActive()
    ? `<div class="lg-host warn">${ic('shield',13)}<span>TEAM TRIAL · SYNTHETIC DATA ONLY · Never enter real or confidential information.</span></div>`
    : isActivated
    ? `<div class="lg-host ok">${ic('shieldcheck',13)}<span>Production active · Issued staff accounts only</span></div>`
    : (isAwaitingAct
      ? `<div class="lg-host warn">${ic('key',13)}<span>4-Step Online Setup complete — sign in as Chief System Administrator to change password &amp; <b>Activate System Globally</b></span></div>`
      : (host
        ? `<div class="lg-host ok">${ic('database',13)}<span>Shared online source active · rev ${host.rev} · ${num(pCount)} patients &amp; ${num(uCount)} accounts loaded</span></div>`
        : `<div class="lg-host ${hostedEntryPending()?'warn':'ok'}">${ic(hostedEntryPending()?'refresh':'check',13)}<span>${hostedEntryPending()?'Checking the shared online source — demo and setup remain closed until it answers':`Active dataset ready · ${num(pCount)} patients, ${num(uCount)} staff accounts &amp; 10 ministry areas`}</span></div>`));

  const slideIdx = ((LOGIN6.slide % LOGIN_TEAM_SLIDES.length) + LOGIN_TEAM_SLIDES.length) % LOGIN_TEAM_SLIDES.length;
  const curSlide = LOGIN_TEAM_SLIDES[slideIdx];

  const signIn = `
    <p class="lg-note lg-signin-intro">${isActivated
      ? 'Use your issued username and private password. Choose Recover if you need help.'
      : 'Use your assigned username or confirmed work email and password.'}</p>
    <form data-form="login6" autocomplete="on">
      <div class="field"><label for="lg-u">Username or confirmed work email</label>
        <input class="input" id="lg-u" name="username" value="${esc(LOGIN6.usernameDraft||'')}" autocomplete="username" autocapitalize="none" autocorrect="off" spellcheck="false" placeholder="Assigned username or confirmed work email" required></div>
      <div class="field"><label for="lg-p">Password</label>
        <div class="pw-wrap"><input class="input" id="lg-p" name="password" type="password" autocomplete="current-password" placeholder="Enter your password" required><button type="button" class="pw-eye" data-act="toggle-pw" aria-label="Show password">${ic('eye',15)}</button></div></div>
      <p class="lg-note lg-device-note" id="lg-device-note"><span class="entry-security-badge">Secure access</span> Sign in from your browser with your own account. Access and activity are managed by the shared service.</p>
      <label class="lg-check"><input type="checkbox" name="remember" checked> Keep session active on this device while in active use</label>
      <button class="btn btn-primary btn-block" type="submit" ${LOGIN6.busy?'disabled':''}>${LOGIN6.busy?'Verifying...':'Sign In to CareLink C-DIMS'} ${ic('chevron',16)}</button>
    </form>
    <div class="lg-links">
      <button class="linkbtn" data-act="login-tab" data-tab="request" type="button">Request county account</button>
      <button class="linkbtn" data-act="login-tab" data-tab="forgot" type="button">Forgotten password?</button>
      <button class="linkbtn" data-act="open-dpa-statement" type="button">Kenya DPA (2019) Notice</button>
      ${!trialEntryActive() && !isActivated && !commissionedEntryActive() ? `<button class="linkbtn" data-act="goto-onboard" type="button">First-run online setup</button>` : ''}
      ${!trialEntryActive() && !isActivated && commissionedEntryActive() ? `<button class="linkbtn" data-act="reset-first-run-fresh" type="button">Reset pre-activation setup</button>` : ''}
    </div>`;

  const allUsers = (DB.db && DB.db.users && DB.db.users.length) ? DB.db.users : [];
  const demoGroups = [
    { id:'all', label:'Key Roles' },
    { id:'lead', label:'Leadership' },
    { id:'field', label:'10 Areas' },
    { id:'clinical', label:'Medical' },
    { id:'ops', label:'Depts' },
    { id:'deputy', label:'Deputies/Clerks' }
  ];
  const pickUsers = (() => {
    const f = LOGIN6.demoFilter || 'all';
    const byU = u => allUsers.find(x=>x.username===u);
    if(f==='lead') return ['director','president','chief.admin','program.admin','program.assistant','exec.secretary','kisumu.admin','homabay.admin'].map(byU).filter(Boolean);
    if(f==='field') return ['coord.nyalenda','caregiver.nyalenda','caregiver.nairobird','caregiver.manyatta','caregiver.nyahera','caregiver.chiga','caregiver.ombeyi','caregiver.ahero','caregiver.makongeni','caregiver.shauriyako'].map(byU).filter(Boolean);
    if(f==='clinical') return ['depthead.medical','deputy.medical','mcm.kisumu','mcm.homabay','nurse.kisumu','focal.kisumu','focal.homabay','homestay.kisumu'].map(byU).filter(Boolean);
    if(f==='ops') return ['finance.kisumu','procurement','me.kisumu','auditor','media.head','pr.officer','hr.officer','welfare.officer','vehicle.officer','ict.officer'].map(byU).filter(Boolean);
    if(f==='deputy') return ['exec.secretary','secretary.kisumu','secretary.homabay','deputy.procurement','deputy.finance','deputy.medical','deputy.hr','clerk.records.kisumu','clerk.stores.kisumu','clerk.data.kisumu'].map(byU).filter(Boolean);
    return ['director','chief.admin','program.admin','kisumu.admin','homabay.admin','mcm.kisumu','focal.kisumu','caregiver.nyalenda','finance.kisumu','procurement'].map(byU).filter(Boolean);
  })();



  const activate = `
    <p class="lg-note">Received a WhatsApp temporary password? Simply use the <b>Sign in</b> tab to activate immediately, or redeem a legacy ACT code below.</p>
    <form data-form="activate6">
      <div class="grid g2" style="gap:6px">
        <div class="field"><label for="lg-activate6-username">Username</label><input class="input" id="lg-activate6-username" name="username" required autocomplete="username" autocapitalize="none" autocorrect="off" spellcheck="false" placeholder="e.g. caregiver.nyalenda"></div>
        <div class="field"><label for="lg-activate6-code">Activation code</label><input class="input mono" id="lg-activate6-code" name="code" placeholder="ACT-XXXXXX" required autocapitalize="characters" style="text-transform:uppercase"></div>
        <div class="field"><label for="lg-activate6-password">New password (12+ chars)</label><div class="pw-wrap"><input class="input" id="lg-activate6-password" name="password" type="password" minlength="12" required autocomplete="new-password" placeholder="A-Z, a-z, 0-9 &amp; symbol"><button type="button" class="pw-eye" data-act="toggle-pw" aria-label="Show password">${ic('eye',15)}</button></div></div>
        <div class="field"><label for="lg-activate6-password2">Confirm password</label><div class="pw-wrap"><input class="input" id="lg-activate6-password2" name="password2" type="password" minlength="12" required autocomplete="new-password" placeholder="Repeat password"><button type="button" class="pw-eye" data-act="toggle-pw" aria-label="Show password">${ic('eye',15)}</button></div></div>
      </div>
      <button class="btn btn-primary btn-block" type="submit">Activate My Account</button>
    </form>`;

  const request = `
    <p class="lg-note">Routed <b>urgently</b> to your selected <b>County Office Administrator</b> (Kisumu Head Office or Homa Bay County Office) for verification and credential issuance.</p>
    <form data-form="request6">
      <div class="grid g2" style="gap:6px">
        <div class="field"><label for="lg-request6-name">Full name *</label><input class="input" id="lg-request6-name" name="name" required placeholder="Full staff name"></div>
        <div class="field"><label for="lg-request6-phone">Phone / WhatsApp *</label><input class="input" id="lg-request6-phone" name="phone" required placeholder="07..."></div>
        <div class="field"><label for="lg-request6-jobTitle">Job title / Seat *</label><input class="input" id="lg-request6-jobTitle" name="jobTitle" required placeholder="e.g. Supporting Caregiver"></div>
        <div class="field"><label for="lg-request6-departmentId">Department</label><select class="input" id="lg-request6-departmentId" name="departmentId">${DEPARTMENTS.map(d=>`<option value="${d.id}">${esc(d.name)}</option>`).join('')}</select></div>
        <div class="field"><label for="lg-request6-countyId">County Office Admin *</label><select class="input" id="lg-request6-countyId" name="countyId">${COUNTIES.map(c=>`<option value="${c.id}">${esc(c.name)} Admin</option>`).join('')}</select></div>
        <div class="field"><label for="lg-request6-justification">Area / Reason *</label><input class="input" id="lg-request6-justification" name="justification" required placeholder="Assigned role & area"></div>
      </div>
      <button class="btn btn-primary btn-block" type="submit">${ic('send',14)} Send Urgent Request to County Admin</button>
    </form>`;

  const forgot = `
    <p class="lg-note">Submit an <b>urgent password recovery request</b> directly to your <b>County Office Administrator</b>, or redeem an issued 24-hour emergency code below.</p>
    <form data-form="forgot6" style="margin-bottom:7px">
      <div class="grid g3" style="gap:6px;align-items:flex-end">
        <div class="field" style="margin:0"><label for="lg-forgot6-username">Username / Email *</label><input class="input" id="lg-forgot6-username" name="username" required autocomplete="username" placeholder="Username"></div>
        <div class="field" style="margin:0"><label for="lg-forgot6-countyId">County Office *</label><select class="input" id="lg-forgot6-countyId" name="countyId">${COUNTIES.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></div>
        <button class="btn btn-primary" type="submit" style="white-space:nowrap;padding:7px 10px">Alert County Admin</button>
      </div>
    </form>
    <form data-form="emergency6">
      <div class="grid g3" style="gap:6px">
        <div class="field"><label for="lg-emergency6-code">EMG code</label><input class="input mono" id="lg-emergency6-code" name="code" placeholder="EMG-XXXX" required autocapitalize="characters" style="text-transform:uppercase"></div>
        <div class="field"><label for="lg-emergency6-username">Username</label><input class="input" id="lg-emergency6-username" name="username" required autocapitalize="none" autocorrect="off" spellcheck="false" placeholder="Username"></div>
        <div class="field"><label for="lg-emergency6-password">New password</label><div class="pw-wrap"><input class="input" id="lg-emergency6-password" name="password" type="password" minlength="12" required placeholder="12+ chars"><button type="button" class="pw-eye" data-act="toggle-pw" aria-label="Show password">${ic('eye',15)}</button></div></div>
      </div>
      <button class="btn btn-ghost btn-block" type="submit">Redeem 24h Emergency Code</button>
    </form>`;

  const body = t==='activate' ? activate : t==='request' ? request : t==='forgot' ? forgot : signIn;

  return `<div class="lg6" data-theme="${esc(entryTheme.id)}" data-mode="${esc(entryTheme.mode)}" data-access="${esc(t)}" style="${ENTRY_THEME.style(entryTheme.id)}">
    <aside class="lg6-brand">
      <div class="lg6-brand-top">
        <div class="row" style="gap:11px;margin-bottom:8px">
          <img src="${window.LOGO||''}" alt="LOMAMO Foundation" class="lg6-logo" style="margin:0">
          <div>
            <div class="xs bold" style="letter-spacing:.11em;text-transform:uppercase;color:#F2F2F2">CareLink Operating System · LOMAMO Foundation</div>
            <div class="xs" style="color:#CCCCCC">Orphan Prevention, Clinical Care &amp; Partner Governance</div>
          </div>
        </div>
        <h1>CareLink.<br><em>Saving lives, preventing orphans.</em></h1>
        <div class="xs bold" style="color:#E5E5E5;margin:-4px 0 7px">One Foundation. One Operating System.</div>

        <figure class="lg6-showcase">
          <div class="lg6-photo-frame">
            <img class="lg6-photo-bg" src="${carelinkPhoto(curSlide.key)}" alt="" aria-hidden="true">
            <img class="lg6-photo-main" src="${carelinkPhoto(curSlide.key)}" alt="${esc(curSlide.title)}">
            <div class="lg6-photo-overlay">
              <span class="lg6-photo-tag">${esc(curSlide.tag)}</span>
              <b>${esc(curSlide.title)}</b>
              <span>${esc(curSlide.dept)}</span>
            </div>
          </div>
          <div class="lg6-thumbs" role="group" aria-label="Department teamwork gallery">
            ${LOGIN_TEAM_SLIDES.map((s, idx)=>`<button type="button" class="lg6-thumb ${idx===slideIdx?'on':''}" data-act="login-slide" data-idx="${idx}" aria-pressed="${idx===slideIdx}" aria-label="${esc(s.tag)}" title="${esc(s.tag)}">
              <img src="${carelinkPhoto(s.key)}" alt="">
              <span>${esc(s.tag.split(' ')[0])}</span>
            </button>`).join('')}
          </div>
        </figure>

        <p class="lg6-copy">Care teams, family support and stewardship — connected on one governed source across computers, tablets and field clients.</p>
      </div>
      <div class="lg6-brand-foot">
        <div><b>${esc(APP.full)}</b> · v${esc(APP.version)}</div>
        <div class="xs">Love Matters Most · Serving our Neighbours in Love · Saving Lives, Preventing Orphans</div>
      </div>
    </aside>

    <main class="lg6-panel">
      <div class="lg6-mobile-hero">
        <img src="${window.LOGO||''}" alt="LOMAMO Foundation">
        <div class="lg6-mobile-hero-txt">
          <div class="xs bold" style="color:#B7192B;text-transform:uppercase;letter-spacing:.08em">LOMAMO Foundation</div>
          <b>CareLink. <em>Saving lives, preventing orphans.</em></b>
        </div>
      </div>
      <div class="lg6-card">
        <div class="lg6-head">
          <img src="${window.LOGO||''}" alt="" class="lg6-mark">
          <div style="flex:1">
            <div class="lg6-kicker">${esc(orgName())}</div>
            <h2>${(!demoBlocked && t==='demo')?'Active Demo Accounts':t==='activate'?'Activate Account':t==='request'?'Urgent County Account Request':t==='forgot'?'Urgent Password Recovery':trialEntryActive()?'Team Trial Sign In':'Official Staff Sign In'}</h2>
          </div>
          <button class="btn btn-xs btn-ghost" data-act="goto-landing" type="button">Front page</button>
        </div>
        ${hostLine}
        ${LOGIN6.error?(()=>{
          const isKvUnavailable = /refused the (read|write)|could not be read|not configured/i.test(LOGIN6.error) && !/WRONGTYPE/i.test(LOGIN6.error);
          const showResetBtn = !trialEntryActive() && !isActivated && !isKvUnavailable && (commissionedEntryActive() || (host && host.setup) || /invalid online database|malformed JSON|WRONGTYPE|corrupted|KV/i.test(LOGIN6.error));
          const showOfflineBtn = isKvUnavailable && !isActivated && !demoBlocked;
          return `<div class="alert crit lg6-alert">${ic('alert',15)}<div style="flex:1"><span>${esc(LOGIN6.error)}</span><div class="row" style="margin-top:6px;gap:6px;flex-wrap:wrap">${isKvUnavailable ? `<button class="btn btn-xs btn-primary" type="button" data-act="login-retry-kv">${ic('refresh',12)} Retry Cloud KV Connection</button>` : ''}${showOfflineBtn ? `<button class="btn btn-xs btn-ghost" type="button" data-act="login-offline-device-mode" style="background:#FFFFFF;color:#0F172A;border:1px solid #94A3B8;font-weight:700">${ic('laptop',12)} Open Offline Console on This Device</button>` : ''}${showResetBtn ? `<button class="btn btn-xs btn-primary" type="button" data-act="reset-first-run-fresh">${ic('refresh',12)} Reset 4-Step Setup &amp; Set Fresh Password</button>` : ''}</div></div></div>`;
        })():''}
        ${LOGIN6.notice?`<div class="alert ok lg6-alert">${ic('check',15)}<span>${esc(LOGIN6.notice)}</span></div>`:''}
        <div class="lg-tabs" role="group" aria-label="Account access">
          ${tabBtn('signin','Sign in')}
          ${tabBtn('activate','Activate')}
          ${tabBtn('request','Request')}
          ${tabBtn('forgot','Recover')}
        </div>
        <div class="lg6-body">${body}</div>
        <div class="lg6-foot">
          <span>CareLink C-DIMS v${esc(APP.version)} · Schema ${esc(String(APP.schema))}</span>
          <span>Data Protection Act, 2019</span>
        </div>
      </div>
    </main>
  </div>`;
}

/* ------------------------------------------------------------ forced change */
function renderMustChange(){
  const u = AUTH.user;
  const isChiefPreActivation = Boolean(
    u && u.roleId === 'chief' &&
    typeof PROD_SETUP !== 'undefined' && !PROD_SETUP.isGloballyActivated() &&
    ((DB.db && Array.isArray(DB.db.patients) ? DB.db.patients.length : 0) < DEMO_REGISTER.patients)
  );
  return `<div class="lg6 one">
    <main class="lg6-panel">
      <div class="lg6-card">
        <div class="lg6-head"><img src="${window.LOGO||''}" alt="" class="lg6-mark">
          <div><div class="lg6-kicker">First Sign-In · Data Protection Act, 2019</div><h2>Create your private password</h2></div></div>
        <p class="lg-note">You signed in with a one-time SMS password issued during commissioning. Set your personal password below — it must be at least <b>12 characters</b> with uppercase, lowercase, digit and symbol, and is stored only as a salted one-way hash so <b>not even the Chief System Administrator knows your password</b>.</p>
        <div class="lg6-id"><span class="avatar">${initials(u.name)}</span>
          <div><b>${esc(u.name)}</b><div class="xs muted">${esc((roleObj(u.roleId)||{}).name||'')} · ${esc(u.username)}</div></div></div>
        ${LOGIN6.error?`<div class="alert crit lg6-alert">${ic('alert',15)}<span>${esc(LOGIN6.error)}</span></div>`:''}
        <form data-form="mustchange6">
          <div class="field"><label>Current (one-time SMS) password</label><div class="pw-wrap"><input class="input" type="password" name="current" required autocomplete="current-password"><button type="button" class="pw-eye" data-act="toggle-pw" aria-label="Show password">${ic('eye',15)}</button></div></div>
          <div class="field"><label>New private password (12+ chars)</label><div class="pw-wrap"><input class="input" type="password" name="password" minlength="12" required autocomplete="new-password"><button type="button" class="pw-eye" data-act="toggle-pw" aria-label="Show password">${ic('eye',15)}</button></div>
            <div class="hint">Minimum 12 characters including uppercase (A–Z), lowercase (a–z), number (0–9) and symbol (@ # % &amp; * ! ?).</div></div>
          <div class="field"><label>Repeat your new private password</label><div class="pw-wrap"><input class="input" type="password" name="password2" minlength="12" required autocomplete="new-password"><button type="button" class="pw-eye" data-act="toggle-pw" aria-label="Show password">${ic('eye',15)}</button></div></div>
          ${isChiefPreActivation ? `<label class="lg-check" style="margin:8px 0 12px;align-items:flex-start;gap:8px;padding:10px 12px;border-radius:9px;border:1.5px solid var(--brand);background:var(--brand-soft,rgba(15,118,110,.06))">
            <input type="checkbox" name="autoFeedCloudMaster" value="1" style="margin-top:2px">
            <span><b>Evaluation only: load ${num(DEMO_REGISTER.patients)} synthetic patients</b> into this isolated evaluation database. Leave unchecked for production; never use on an existing live register.</span>
          </label>` : ''}
          <button class="btn btn-primary btn-block" type="submit" ${LOGIN6.mustChangeBusy?'disabled':''}>${LOGIN6.mustChangeBusy?'Saving password &amp; loading Cloud Dataset...':'Save private password &amp; open my console'}</button>
        </form>
        <div class="lg6-foot"><button class="linkbtn" data-act="logout" type="button">Sign out instead</button></div>
      </div>
    </main></div>`;
}

/* ------------------------------------------------------------ first run */
function renderOnboarding6(){
  const isActivated = typeof PROD_SETUP !== 'undefined' && PROD_SETUP.isGloballyActivated && PROD_SETUP.isGloballyActivated();
  const demoBlocked = demoEntryBlocked();
  const hostedSetup = typeof SYNC !== 'undefined' && SYNC.available && SYNC.available();
  /* Deep links and stale rendered actions must not bypass the same lock used by
     the Sign-In screen.  After activation there is no host-setup/demo screen. */
  if(isActivated){
    APPX.screen = 'login';
    LOGIN6.tab = 'signin';
    return renderLogin6();
  }
  if(hostedEntryPending()){
    return `<div class="lg6 one"><main class="lg6-panel"><div class="lg6-card"><div class="lg6-head"><div><div class="lg6-kicker">CareLink Online Setup</div><h2>Checking the shared online source</h2></div></div><p class="lg-note">This browser is checking the existing Vercel/KV installation before offering any setup or demonstration action. No device-local installation will be created.</p><button class="btn btn-primary" data-act="ob-retry-host" type="button" ${ONB.busy?'disabled':''}>${ONB.busy?'Checking…':'Check again'}</button></div></main></div>`;
  }
  /* The full synthetic register is roughly 70 MB as JSON and cannot fit in a
     Vercel Function request/response. Live commissioning is therefore always
     an empty register; the complete reference master is a separate, chunked
     post-setup import before global activation. */
  if(hostedSetup) ONB.seed = 'empty';
  ONB.host = APPX.host || ONB.host || null;
  const host = ONB.host;
  if(host && host.setup && !ONB.hostSetup){ ONB.hostSetup = host; ONB.step = 3; }
  const step = ONB.step;
  const dots = [1,2,3,4].map(i=>`<span class="ob-dot ${step>=i?'on':''}"></span>`).join('');
  const head = `<div class="ob-head">
      <img src="${window.LOGO||''}" alt="" class="lg6-mark">
      <div><div class="lg6-kicker">First-Run Production Setup · CareLink C-DIMS v${APP.version}</div>
        <h2>Commission Chief System Administrator &amp; SMS Credentials</h2></div>
      <div class="ob-dots">${dots}</div></div>`;

  let body = '';
  if(step===1){
    body = `<p class="lg-note">Run the <b>4-Step Online Setup</b> to establish CareLink's institutional host &amp; organogram structure. Upon completion you return to the <b>Official Sign-In screen</b>, sign in as Chief System Administrator, change your password, and click <b>Activate System Globally</b> to generate the Team WhatsApp Credential Sheet.</p>
      <div class="grid g2" style="gap:10px">
        <div class="field"><label>Organisation name</label><input class="input" id="ob-org" value="${esc(ONB.org.name)}"></div>
        <div class="field"><label>Official staff email domain</label><input class="input mono" id="ob-domain" value="${esc(OFFICIAL_EMAIL_DOMAIN)}" readonly><div class="hint">Fixed for the Foundation: every account alias is <code>username@${esc(OFFICIAL_EMAIL_DOMAIN)}</code>. No mailbox is provisioned and CareLink does not send email.</div></div>
      </div>
      <div class="grid g2" style="gap:10px">
        <div class="field"><label>Short name</label><input class="input" id="ob-short" value="${esc(ONB.org.shortName)}"></div>
        <div class="field"><label>Primary county office (Head Office)</label><select class="input" id="ob-county">${COUNTIES.map(c=>`<option value="${c.id}" ${ONB.org.county===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select></div>
      </div>
      <div class="ob-host ${host?'ok':'info'}">
        ${host ? `${ic('database',16)}<div><b>Unified Online Site Database connected at this address</b>
            <span>Revision ${host.rev}. Completing Steps 1–4 establishes global user structures and prepares Official Sign-In.</span></div>`
              : `${ic('database',16)}<div><b>4-Step Live Host Commissioning Ready</b>
            <span>Establishes global organogram accounts (including applicable Secretaries, Deputies &amp; Clerks), returns to Official Sign-In for Chief Admin password change, then enables <b>Activate System Globally</b>.</span></div>`}
      </div>`;
  }
  if(step===2){
    body = `<p class="lg-note">Establish the <b>Chief System Administrator</b> commissioning account and initial setup password. Immediately after Step 4 returns you to the <b>Official Sign-In screen</b>, you will sign in with this initial setup password and be prompted to set your private personal password before clicking <b>Activate System Globally</b>.</p>
      <div class="grid g2" style="gap:10px">
        <div class="field"><label>Chief System Administrator full name</label><input class="input" id="ob-name" value="${esc(ONB.admin.name||'Chief System Administrator')}" placeholder="e.g. Chief System Administrator"></div>
        <div class="field"><label>Username</label><input class="input" id="ob-user" value="${esc(ONB.admin.username||'system.admin')}" placeholder="system.admin"><div class="hint">Both <b>system.admin</b> and <b>chief.admin</b> are accepted for Chief System Administrator sign-in.</div></div>
      </div>
      <div class="grid g2" style="gap:10px">
        <div class="field"><label>Initial Commissioning Setup Password (12+ chars)</label><input class="input" id="ob-pw" type="password" minlength="12" value="${esc(ONB.admin.password||'')}" autocomplete="new-password" oninput="(function(v){var el=document.getElementById('ob-strength');if(!el)return;var u={name:(document.getElementById('ob-name')||{}).value||'',username:(document.getElementById('ob-user')||{}).value||''};var err=(typeof PROD_SETUP!=='undefined')?PROD_SETUP.validatePrivacyPassword(v,u):(v.length<12?'At least 12 characters required.':'');el.textContent=err?err:'Strong commissioning password ready ('+v.length+' chars).';el.style.color=err?'var(--crit)':'var(--ok)';})(this.value)">
          <div class="hint" id="ob-strength">At least 12 characters with uppercase, lowercase, digit &amp; symbol. You will replace this on Official Sign-In.</div></div>
        <div class="field"><label>Repeat initial setup password</label><input class="input" id="ob-pw2" type="password" minlength="12" value="${esc(ONB.admin.confirm||'')}" autocomplete="new-password"></div>
      </div>`;
  }
  if(step===3){
    const roster = OFFICIAL_ROSTER;
    const hs = ONB.hostSetup;
    body = hs? `<div class="ob-host-setup">
        <div class="ob-hs-h">${ic('database',17)}<div><b>This host already holds an installation</b>
          <span>The shared online installation at ${esc(hs.host||'this address')} answered that it is already set up${hs.accounts?` and holds ${num(hs.accounts)} provisioned account${hs.accounts===1?'':'s'}`:''}. First-run setup commissions a <i>fresh</i> online installation; it never overwrites a live one, and it cannot create a second administrator on an installation that already has one.</span></div></div>
        <p class="lg-note">This is not a fault and you are not stuck. Choose one of the three ways forward below - the wizard continues from whichever you choose.</p>
        <div class="ob-hs-opts">
          <button class="ob-choice on" type="button" data-act="ob-attach-signin">
            <b>1 · I already have an account - sign me in</b>
            <span>The normal path for a tablet or a second office computer. The installation stays exactly as the administrator left it.</span></button>
          <button class="ob-choice" type="button" data-act="ob-attach-request">
            <b>2 · Ask the administrator for an account</b>
            <span>Writes a request to the host. ${esc(hs.admins&&hs.admins.length? 'The senior offices who can approve it: '+hs.admins.join(', ')+'.':'The Chief Administrator approves it from Users & accounts.')}</span></button>
          <button class="ob-choice" type="button" data-act="ob-attach-device">
            <b>3 · Continue on this device only</b>
            <span>Keeps working offline on this device with its own record. It does not touch the host installation, and it can be joined to it later from Settings.</span></button>
          ${!isActivated ? `<button class="ob-choice" type="button" data-act="reset-first-run-fresh">
            <b>4 · Reset unfinished setup &amp; start a fresh 4-Step Commissioning</b>
            <span>Clears an unactivated or interrupted pre-activation setup in Cloud KV and restarts at Step 1 of 4. Permanently disabled once Global System Activation is locked.</span></button>` : ''}
        </div>
        ${ONB.advice?`<div class="alert info lg6-alert">${ic('info',15)}<span>${esc(ONB.advice)}</span></div>`:''}
      </div>`
    : `<p class="lg-note">The official roster of ${roster.length} leadership, county, clinical, departmental and ministry-area accounts will be provisioned. On a live host, unique temporary passwords are saved once into your confidential master sheet.</p>
      <div class="ob-roster">
        ${roster.slice(0,10).map(r=>`<div class="ob-r"><b>${esc(r.name)}</b><span>${esc(r.username)}</span><i>${esc((ROLE(r.roleId)||{}).name||r.roleId)}</i></div>`).join('')}
        <div class="ob-r more">plus ${roster.length-10} additional accounts across Kisumu &amp; Homa Bay</div>
      </div>`;
  }
  if(step===4){
    body = `${hostedSetup
      ? `<p class="lg-note">Live Vercel commissioning starts with an <b>empty production register</b>. After these four steps, the Chief can open <b>Master data import</b> before global activation to download and upload the complete reference master in verified chunks. The large package is deliberately not part of this initial request because of Vercel's 4.5 MB Function request limit.</p>`
      : `<p class="lg-note">Choose whether to start with the full ${num(DEMO_REGISTER.patients)}-patient synthetic reference register across all 10 ministry areas and 11 major departments, or an empty production register ready for live intake.</p>`}
      <div class="alert info" style="margin-bottom:12px">${ic('info',16)}<div>
        <b>Staff credential downloads follow global activation</b>
        <span class="small">Finish setup, sign in as Chief System Administrator and change your password. After you activate the system globally, download the confidential SMS CSV or text pack from the activation screen.</span>
      </div></div>
      ${hostedSetup ? '' : `<div class="ob-choice ${ONB.seed==='reference'?'on':''}" data-act="ob-seed" data-seed="reference">
        <b>Load full ${num(DEMO_REGISTER.patients)}-patient &amp; full-department dataset</b>
        <span>95% between 45 and 240 days, 5% between 241 and 330 days, plus clinical, hospital, pharmacy, finance, HR, fleet, media, library and 122-item equipment registers.</span>
      </div>`}
      <div class="ob-choice ${ONB.seed==='empty'?'on':''}" data-act="ob-seed" data-seed="empty">
        <b>Start with an empty patient register</b>
        <span>For live clinical intake or master workbook import.</span>
      </div>
      ${hostedSetup ? `<div class="ob-choice ${ONB.autoFeedCloudMaster===true?'on':''}" data-act="ob-toggle-autofeed" style="margin-top:8px">
        <b>${ONB.autoFeedCloudMaster===true?'✓ ':''}Evaluation only: explicitly load ${num(DEMO_REGISTER.patients)} synthetic patients after Chief Sign-In</b>
        <span>Off by default. Enable only for an isolated evaluation installation, never a live register. The server generates the synthetic reference at runtime, including related visits, PDCAs, conditions and documents; no real workbook is used.</span>
      </div>` : ''}`;
  }
  const footer = `<div class="ob-actions">
      <div class="row" style="gap:8px;flex-wrap:wrap">
        ${step>1?`<button class="btn btn-ghost" data-act="ob-back" type="button">Back</button>`
                :`<button class="btn btn-ghost" data-act="goto-landing" type="button">Front page</button>`}
      </div>
      ${step===3 && ONB.hostSetup
        ? `<button class="btn btn-primary" data-act="ob-attach-signin" type="button">Go to sign-in ${ic('chevron',15)}</button>`
        : `<button class="btn btn-primary" data-act="ob-next" type="button" ${ONB.busy?'disabled':''}>
        ${step===3?(host?'Issue credentials & continue':'Continue'):step===4?'Finish setup':'Continue'} ${ic('chevron',15)}</button>`}
    </div>`;

  return `<div class="lg6 one ob-scroll"><main class="lg6-panel wide"><div class="lg6-card ob-card">
      ${head}
      ${ONB.error?`<div class="alert crit lg6-alert">${ic('alert',15)}<span>${esc(ONB.error)}</span></div>`:''}
      <div class="ob-body">${body}</div>
      ${footer}
      <div class="lg6-foot"><span>Step ${step} of 4</span><span>v${APP.version} · schema ${APP.schema}</span></div>
    </div></main></div>`;
}

/* ------------------------------------------------------------ actions */
Object.assign(ACTIONS, {
  'login-tab': d => {
    const lockedDemo = d.tab === 'demo' && demoEntryBlocked();
    LOGIN6.tab = lockedDemo ? 'signin' : d.tab;
    LOGIN6.error=''; LOGIN6.notice=''; render();
  },
  'login-slide': d => { LOGIN6.slide = Number(d.idx)||0; render(); },
  'demo-filter': d => { LOGIN6.demoFilter = d.f || 'all'; render(); },
  'login-request': () => { LOGIN6.tab='request'; APPX.screen='login'; LOGIN6.error=''; render(); },
  'login-recovery': () => { LOGIN6.tab='forgot'; APPX.screen='login'; LOGIN6.error=''; LOGIN6.notice=''; render(); },
  'goto-login': () => { APPX.screen='login'; LOGIN6.tab='signin'; LOGIN6.error=''; LOGIN6.notice=''; render(); },
  'open-signin': () => { APPX.screen='login'; LOGIN6.tab='signin'; LOGIN6.error=''; LOGIN6.notice=''; render(); window.scrollTo({top:0}); },
  'goto-landing': () => { APPX.screen='landing'; LOGIN6.error=''; render(); window.scrollTo({top:0}); },
  'goto-architecture': () => { APPX.screen='architecture'; LOGIN6.error=''; render(); window.scrollTo({top:0}); },
  'goto-onboard': () => {
    if ((typeof PROD_SETUP !== 'undefined' && PROD_SETUP.isGloballyActivated && PROD_SETUP.isGloballyActivated()) || commissionedEntryActive()) {
      APPX.screen='login'; LOGIN6.tab='signin';
      LOGIN6.notice = 'This shared online installation is already commissioned. Sign in with your issued account; first-run setup is not available on this client.';
      return render();
    }
    APPX.screen='onboard'; ONB.step=1; ONB.error='';
    if(typeof SYNC !== 'undefined' && SYNC.available && SYNC.available()) ONB.seed='empty';
    render(); window.scrollTo({top:0});
  },

  /* Works everywhere (PC, Tablet, Onboarding, Sign-In, Settings) in one tap */
  'load-demo': () => {
    LOGIN6.busy = false; ONB.busy = false; LOGIN6.tab = 'signin';
    APPX.screen = 'login';
    toast('Demonstration accounts unavailable', 'The Chief System Administrator must commission this installation before any role accounts are issued.', 'info');
    render();
  },

  'ob-seed': d => {
    if(typeof SYNC !== 'undefined' && SYNC.available && SYNC.available() && d.seed !== 'empty'){
      ONB.seed = 'empty';
      toast('Live production register', 'Complete the four steps with an empty register, then use Master data import before global activation to upload the full reference master in verified chunks.', 'warn');
      return render();
    }
    ONB.seed = d.seed === 'reference' ? 'reference' : 'empty';
    render();
  },
  /* --- the host is already set up: three honest ways forward --- */
  'ob-attach-signin': () => {
    ONB.error=''; ONB.hostSetup = ONB.hostSetup || { host:(ONB.host&&ONB.host.host)||location.host };
    APPX.screen='login'; LOGIN6.tab='signin'; LOGIN6.busy=false; ONB.busy=false;
    LOGIN6.notice = 'This host is already set up, so nothing was changed on it. Sign in with the account the administrator issued. If you do not have one yet, choose "Request an account".';
    render(); window.scrollTo({top:0});
  },
  'ob-attach-request': () => {
    ONB.error=''; APPX.screen='login'; LOGIN6.tab='request'; LOGIN6.busy=false; ONB.busy=false;
    LOGIN6.notice = 'Ask for an account on this host. The Chief Administrator, the County Office Administrator, the Country Director or the Chief Program Administrator approves it from Users & accounts, and your temporary password is issued there - never by email.';
    render(); window.scrollTo({top:0});
  },
  'ob-attach-device': () => {
    ONB.error=''; ONB.mode='device'; ONB.hostSetup=null; ONB.host=null; ONB.step=4; ONB.busy=false;
    ONB.advice='This device will keep its own record. It is not joined to the host installation, and joining it later is a merge, not an overwrite.';
    render(); window.scrollTo({top:0});
  },
  'ob-device': () => { ONB.mode='device'; ONB.step=2; render(); },
  'ob-toggle-autofeed': () => { ONB.autoFeedCloudMaster = ONB.autoFeedCloudMaster === false ? true : false; render(); },
  'reset-first-run-fresh': async () => {
    if (typeof PROD_SETUP !== 'undefined' && PROD_SETUP.isGloballyActivated && PROD_SETUP.isGloballyActivated()) {
      return toast('Reset Locked', 'This installation is globally activated and permanently locked.', 'warn');
    }
    ONB.busy = true; LOGIN6.busy = true; ONB.error = ''; LOGIN6.error = ''; render();
    try {
      if (typeof SYNC !== 'undefined' && SYNC.available && SYNC.available()) {
        clearTimeout(SYNC._timer);
        if (SYNC.stopPolling) SYNC.stopPolling();
        if (SYNC.storeToken) SYNC.storeToken(null);
        const res = await SYNC._json('api/setup/reset-first-run', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ confirm: 'RESET-FIRST-RUN' }),
          skipAuthHeader: true,
          timeoutMs: 15000
        });
        if (!res.ok || !res.body || !res.body.ok) {
          throw new Error((res.body && res.body.error) || 'Could not reset pre-activation Cloud KV setup.');
        }
      }
      try {
        localStorage.removeItem(DB.KEY);
        sessionStorage.removeItem('carelink.session');
        sessionStorage.removeItem('carelink.lastUser');
        sessionStorage.removeItem('carelink.pendingCloudAutoFeed');
      } catch (_e) {}
      if (typeof AUTH !== 'undefined' && AUTH.logout) AUTH.logout();
      if (typeof SYNC !== 'undefined') clearTimeout(SYNC._timer);
      DB.db = DB.blank();
      APPX.dirty = false;
      ONB.hostSetup = null;
      ONB.advice = '';
      ONB.step = 1;
      ONB.seed = 'empty';
      ONB.autoFeedCloudMaster = false;
      ONB._pendingCloudAutoFeed = false;
      let freshHealth = null;
      for (const ms of [0, 200, 450, 900]) {
        if (ms > 0) await new Promise(r => setTimeout(r, ms));
        freshHealth = await hostProbe();
        if (freshHealth && !freshHealth.setup) break;
      }
      APPX.host = freshHealth;
      ONB.host = freshHealth;
      if (typeof SYNC !== 'undefined') SYNC.server = freshHealth;
      ONB.busy = false; LOGIN6.busy = false;
      APPX.screen = 'onboard';
      toast('Fresh First-Run Setup Ready', 'Pre-activation KV state cleared. Complete Steps 1–4 cleanly below.', 'ok');
      render();
      if (typeof window !== 'undefined' && window.scrollTo) window.scrollTo({ top: 0 });
    } catch (e) {
      ONB.busy = false; LOGIN6.busy = false;
      const msg = e.message || 'Could not reset First-Run setup.';
      ONB.error = msg; LOGIN6.error = msg;
      toast('Reset Failed', msg, 'err');
      render();
    }
  },
  'sync-retry': async () => {
    closeModal();
    if (typeof SYNC !== 'undefined') SYNC.resetKvBackoff();
    if (typeof SYNC !== 'undefined' && SYNC.deviceOnlyOverride) {
      SYNC.deviceOnlyOverride = false;
      const diag = SYNC._json ? await SYNC._json('api/kv-diagnostics', { skipAuthHeader: true, timeoutMs: 10000 }) : null;
      if (diag && diag.ok && diag.body && diag.body.ok) {
        toast('Cloud KV Reachable', 'Online KV store is now responding. Sign out and sign back in to sync live with Cloud KV.', 'ok');
        await SYNC.start();
      } else {
        SYNC.deviceOnlyOverride = true;
        SYNC.state = 'device';
        SYNC.message = 'Offline/static mode — local records only';
        SYNC.bump();
        const errMsg = (diag && diag.body && diag.body.error) || 'Cloud KV is still unavailable; staying in Offline Device Mode.';
        toast('Cloud KV Still Unavailable', errMsg, 'err');
      }
      return;
    }
    if (typeof SYNC !== 'undefined') await SYNC.start();
  },
  'login-retry-kv': async () => {
    if (typeof SYNC !== 'undefined') { SYNC.deviceOnlyOverride = false; SYNC.resetKvBackoff(); }
    LOGIN6.busy = true; LOGIN6.error = ''; LOGIN6.notice = ''; render();
    try {
      const diag = (typeof SYNC !== 'undefined' && SYNC._json)
        ? await SYNC._json('api/kv-diagnostics', { skipAuthHeader: true, timeoutMs: 10000 })
        : null;
      if (diag && diag.ok && diag.body && diag.body.ok) {
        const health = await hostProbe();
        if (health) { APPX.host = health; ONB.host = health; if (typeof SYNC !== 'undefined') SYNC.server = health; }
        LOGIN6.busy = false;
        LOGIN6.notice = 'Cloud KV store is online and healthy. You can sign in now.';
        toast('Cloud KV Connected', 'Online database read verified.', 'ok');
        return render();
      }
      LOGIN6.busy = false;
      const errMsg = (diag && diag.body && diag.body.error) || 'The mandatory CareLink KV store is still refusing reads. Check Upstash database status/quota and Vercel KV environment variables.';
      LOGIN6.error = errMsg;
      toast('Cloud KV Unavailable', errMsg, 'err');
      render();
    } catch (e) {
      LOGIN6.busy = false;
      LOGIN6.error = (e && e.message) || 'Could not reach Cloud KV diagnostics.';
      toast('Cloud KV Unavailable', LOGIN6.error, 'err');
      render();
    }
  },
  'login-offline-device-mode': async () => {
    if (demoEntryBlocked()) {
      return toast('Offline Evaluation Locked', 'This installation is globally activated and requires the shared online KV store.', 'err');
    }
    const typedUser = String((($('#lg-u') || {}).value) || LOGIN6.usernameDraft || 'director').trim().toLowerCase();
    if (typeof SYNC !== 'undefined') {
      clearTimeout(SYNC._timer);
      if (SYNC.stopPolling) SYNC.stopPolling();
      if (SYNC.storeToken) SYNC.storeToken(null);
      SYNC.deviceOnlyOverride = true;
      SYNC.state = 'device';
      SYNC.message = 'Offline/static mode — local records only';
      SYNC.bump();
    }
    if (!(DB.db && Array.isArray(DB.db.patients) && DB.db.patients.length >= 100)) {
      DB.seedSynthetic({ patients: DEMO_REGISTER.patients, mustChange: false });
    } else if (DB.db && Array.isArray(DB.db.users)) {
      DB.db.users.forEach(u => {
        if (u && !u.hash) {
          u.salt = u.salt || newSalt();
          u.hash = strongHash('LOMAMO2026', u.salt);
          u.status = 'active';
          u.active = true;
          u.mustChange = false;
        }
      });
    }
    const users = (DB.db && Array.isArray(DB.db.users)) ? DB.db.users : [];
    const target = users.find(u =>
      String(u.username || '').toLowerCase() === typedUser ||
      String(u.email || '').toLowerCase() === typedUser ||
      String(u.roleId || '').toLowerCase() === typedUser
    ) || users.find(u => u.username === 'director') || users[0];
    if (!target) {
      return toast('No Local Account Found', 'Could not provision local evaluation accounts.', 'err');
    }
    if (!target.hash || !target.salt) {
      target.salt = newSalt();
      target.hash = strongHash('LOMAMO2026', target.salt);
    }
    target.mustChange = false;
    target.mustChangePassword = false;
    target.status = 'active';
    target.active = true;
    const localRes = AUTH.login(target.username, 'LOMAMO2026');
    if (!localRes.ok) {
      LOGIN6.error = '';
      LOGIN6.notice = `Switched this tab to Offline Device Mode (${num(DEMO_REGISTER.patients)} patients). Sign in with demonstration password LOMAMO2026 (e.g. ${target.username}).`;
      return render();
    }
    LOGIN6.error = '';
    LOGIN6.busy = false;
    APPX.screen = 'app';
    SESSION.start();
    NAVH.reset(); NAVH.push('home', {}); APPX.view = 'home'; APPX.params = {};
    render();
    toast('Offline Device Console Opened', `Signed in as ${target.jobTitle || target.name} on this device only while Cloud KV is offline.`, 'warn');
  },
  'ob-retry-host': async () => {
    ONB.busy = true; ONB.error = ''; render();
    const health = await hostProbe();
    ONB.busy = false;
    if(health){ APPX.host = health; ONB.host = health; SYNC.server = health; }
    else ONB.error = 'The shared online source is still unavailable. No device-local setup was started.';
    render();
  },
  'ob-back': () => {
    if(ONB.step===2){
      ONB.admin = {
        name: (($('#ob-name')||{}).value || ONB.admin.name || '').trim(),
        username: (($('#ob-user')||{}).value || ONB.admin.username || '').trim().toLowerCase(),
        password: ($('#ob-pw')||{}).value || ONB.admin.password || '',
        confirm: ($('#ob-pw2')||{}).value || ONB.admin.confirm || ''
      };
    }
    ONB.step = Math.max(1, ONB.step-1); ONB.error=''; render();
  },
  'ob-next': async () => {
    ONB.error='';
    const step = ONB.step;
    if(step===1){
      const name = ($('#ob-org')||{}).value || ONB.org.name;
      const short = ($('#ob-short')||{}).value || 'LOMAMO';
      const county = ($('#ob-county')||{}).value || 'kisumu';
      const emailDomain = (($('#ob-domain')||{}).value || ONB.org.emailDomain || 'lomamofoundation.org').replace(/^@+/,'').trim().toLowerCase();
      ONB.org = {name:name.trim(), shortName:short.trim(), county, emailDomain};
      if(typeof SYNC !== 'undefined' && SYNC.available()){
        ONB.busy = true; render();
        const health = await hostProbe();
        ONB.busy = false;
        if(!health){ ONB.error = 'The shared online source could not be verified. Setup was not started on this device.'; return render(); }
        APPX.host = health; ONB.host = health;
        if(health.globallyActivated){ APPX.screen='login'; LOGIN6.tab='signin'; return render(); }
        if(health.setup){ ONB.hostSetup = health; ONB.step = 3; return render(); }
      }
      ONB.step = 2; return render();
    }
    if(step===2){
      const name = (($('#ob-name')||{}).value||'').trim();
      const username = (($('#ob-user')||{}).value||'').trim().toLowerCase();
      const pw = ($('#ob-pw')||{}).value||'';
      const pw2 = ($('#ob-pw2')||{}).value||'';
      if(!name) return toast('A name is required','Enter the administrator full name.','err');
      if(!/^[a-z0-9][a-z0-9._-]{2,40}$/.test(username)) return toast('Choose a username','3 to 40 characters: letters, digits, dot, dash or underscore.','err');
      const policyErr = (typeof PROD_SETUP!=='undefined') ? PROD_SETUP.validatePrivacyPassword(pw, {name, username}) : (pw.length<12?'At least 12 characters required.':'');
      if(policyErr) return toast('Strengthen password', policyErr, 'err');
      if(pw!==pw2) return toast('The passwords do not match','Re-type the same password in both boxes.','err');
      ONB.admin = {name, username, password:pw, confirm:pw2};
      ONB.step = 3; return render();
    }
    if(step===3){
      ONB.step = 4; return render();
    }
    if(step===4){
      ONB.busy = true; render();
      try{
        const res = await PROD_SETUP.completeFourStepHostSetup({
          orgNameVal: ONB.org.name,
          shortNameVal: ONB.org.shortName,
          emailDomain: ONB.org.emailDomain || 'lomamofoundation.org',
          loginUrl: (typeof location !== 'undefined' && location.origin && location.origin !== 'null') ? location.origin : 'https://carelink.lomamo.org',
          primaryCounty: ONB.org.county || 'kisumu',
          chiefName: ONB.admin.name || 'Chief System Administrator',
          chiefUsername: ONB.admin.username || 'chief.admin',
          chiefPassword: ONB.admin.password,
          seedMode: ONB.seed
        });
        APPX.showMustChange = false;
        ONB.busy = false;
        if (ONB.autoFeedCloudMaster === true) {
          ONB._pendingCloudAutoFeed = true;
          try { sessionStorage.setItem('carelink.pendingCloudAutoFeed', '1'); } catch (_e) {}
        } else {
          ONB._pendingCloudAutoFeed = false;
          try { sessionStorage.removeItem('carelink.pendingCloudAutoFeed'); } catch (_e) {}
        }
        APPX.screen = 'login';
        LOGIN6.tab = 'signin';
        LOGIN6.error = '';
        LOGIN6.notice = `4-Step Online Setup complete and verified in the shared online source. Sign in below as ${res.chiefUsername}${res.chiefEmail?' ('+res.chiefEmail+')':''} and set your private personal password${ONB.autoFeedCloudMaster === true ? ' — the synthetic evaluation dataset will be generated and loaded because you explicitly selected it' : ''}, then click "Activate System Globally".`;
        toast('Online Setup Complete', 'Sign in as Chief System Administrator to set your private password and Activate System Globally.', 'ok');
        render();
      }catch(e){ ONB.busy=false; ONB.error='Could not finish host setup: '+e.message; render(); }
      return;
    }
  }
});

Object.assign(ACTIONS, {
  'msg-open': d => {
    const other = (DB.db.users||[]).find(u=>u.id===d.u);
    if(!other) return toast('Not found','That account no longer exists.','err');
    if(!MESSAGING.inReach(AUTH.user, other)){
      go('messages', { thread:'global:all', mode:'global', focusChat:'1' });
      setTimeout(()=>{ const el=document.querySelector('#msgComposeInput'); if(el) el.focus(); }, 30);
      return toast('Opened Global Broadcast Channel', `${other.name.replace(/^Demo - /,'')} is in ${countyName(other.countyId)}; coordinate via the Global Foundation Channel.`, 'info');
    }
    const dmThread = 'dm:' + [AUTH.user.id, other.id].sort().join(':');
    go('messages', { thread:dmThread, to:other.id, focusChat:'1' });
    setTimeout(()=>{ const el=document.querySelector('#msgComposeInput'); if(el) el.focus(); }, 30);
  },
  'msg-save-draft': d => {
    const inp = document.querySelector('#msgComposeInput');
    const txt = inp ? String(inp.value||'').trim() : '';
    if(!txt) return toast('Write a message first','Type your coordination note before saving it to Workspace Drafts.','warn');
    DB.db.workspaceDrafts = DB.db.workspaceDrafts || [];
    DB.db.workspaceDrafts.unshift({
      id: uid('wdr'), kind:'message',
      title: `Draft Message — ${d.title || d.thread || 'Coordination'}`,
      ownerId: AUTH.user.id, countyId: AUTH.user.countyId || 'kisumu', dept: AUTH.user.departmentId || 'ministry',
      targetView:'messages', targetParams:{ thread:d.thread||'global:all', draftText:txt, focusChat:'1' },
      summary: txt.slice(0, 140),
      payload:{ thread:d.thread||'global:all', text:txt },
      updatedAt: todayISO(), status:'draft'
    });
    DB.save();
    if(inp) inp.value = '';
    toast('Saved to Workspace Drafts','Open Workspace Drafts in the left navigation at any time to review or send.','ok');
    render();
  },
  'mj-load': async () => {
    SYNC.journal = await SYNC.mergeJournal();
    render();
  }
});

Object.assign(FORMS, {
  login6: async (d, f) => {
    if(LOGIN6.busy) return;
    const rawUser = d && typeof d.get === 'function' ? d.get('username') : '';
    const domUser = f && typeof f.querySelector === 'function' ? (f.querySelector('[name="username"]')||{}).value : '';
    const username = String(rawUser || domUser || LOGIN6.usernameDraft || '').trim().toLowerCase();
    const rawPass = d && typeof d.get === 'function' ? d.get('password') : '';
    const domPass = f && typeof f.querySelector === 'function' ? (f.querySelector('[name="password"]')||{}).value : '';
    const password = String(rawPass || domPass || '');
    LOGIN6.usernameDraft = username;
    if(!username || !password){
      LOGIN6.error = 'Enter both your username (or official email) and password.';
      return render();
    }
    LOGIN6.error=''; LOGIN6.notice=''; LOGIN6.busy=true; render();
    try{
      const hosted = typeof SYNC !== 'undefined' && SYNC.available && SYNC.available();
      if(!AUTH.user && typeof SYNC !== 'undefined'){
        clearTimeout(SYNC._timer);
        if(SYNC.stopPolling) SYNC.stopPolling();
        if(SYNC.storeToken) SYNC.storeToken(null);
      }
      // Device admission is tied to the server-issued cookie and approval code,
      // not a label typed at sign-in. Do not require staff to name their device.
      let res = await AUTH.loginOnline(username, password, CLIENT_UI.snapshot());
      if(!res.ok && !hosted){
        /* Local PBKDF2/hash sign-in is exclusively an offline/static-file
           feature.  A Vercel client never turns a failed server login into a
           device-local account or an automatic demo installation. */
        const hostUnprovisioned = !APPX.host || !APPX.host.setup;
        const isGloballyActive = (typeof PROD_SETUP !== 'undefined' && PROD_SETUP.isGloballyActivated && PROD_SETUP.isGloballyActivated());
        const localCandidate = (DB.db && Array.isArray(DB.db.users))
          ? DB.db.users.find(x => x.username.toLowerCase()===username || String(x.email||'').toLowerCase()===username || ((username==='system.admin'||username==='chief.admin') && x.roleId==='chief'))
          : null;
        if((localCandidate && localCandidate.hash && localCandidate.salt) || res.code==='offline' || res.code==='failed' || res.status===0 || hostUnprovisioned){
          const local = AUTH.login(username, password);
          res = local.ok
            ? { ok:true, user:local.user, mustChange:Boolean(local.user.mustChange || local.user.mustChangePassword) }
            : { ok:false, error: local.msg };
        }
      }
      LOGIN6.busy = false;
      if(res.ok){
        LOGIN6.usernameDraft = '';
        if(typeof ACCOUNT_SWITCHER !== 'undefined' && ACCOUNT_SWITCHER.rememberUsername && AUTH.user){
          ACCOUNT_SWITCHER.rememberUsername(AUTH.user.username);
        }
        APPX.screen='app';
        try{ sessionStorage.setItem('carelink.lastUser', AUTH.user.username); }catch(e){}
        if(AUTH.mustChange || res.mustChange || (AUTH.user && (AUTH.user.mustChange || AUTH.user.mustChangePassword))){
          AUTH.mustChange = true;
          applyTheme();
          render();
          return;
        }
        SESSION.start();
        applyTheme();
        NAVH.reset(); NAVH.push('home',{}); APPX.view='home'; APPX.params={};
        render();
        if(typeof SYNC!=='undefined' && SYNC.sessionToken) SYNC.startPolling();
      } else {
        LOGIN6.error = res.error || res.msg || 'That username and password were not accepted.';
        render();
      }
    }catch(e){
      AUTH.user = null;
      AUTH.mustChange = false;
      LOGIN6.busy = false;
      LOGIN6.error = 'Sign-in could not complete: ' + (e && e.message ? e.message : String(e));
      render();
    }finally{
      if(LOGIN6.busy){
        LOGIN6.busy = false;
        try{ render(); }catch(_e){}
      }
    }
  },

  mustchange6: async (d) => {
    const current = String(d.get('current')||''), next = String(d.get('password')||''), again = String(d.get('password2')||'');
    LOGIN6.error = '';
    if(!current){ LOGIN6.error = 'Enter your current temporary password.'; return render(); }
    if(next !== again){ LOGIN6.error = 'The new passwords do not match.'; toast('The passwords do not match','Re-type the same new password.','err'); return render(); }
    let uRec = AUTH.user ? ((DB.db && Array.isArray(DB.db.users) && DB.db.users.find(x => x.id===AUTH.user.id || x.username===AUTH.user.username)) || AUTH.user) : null;
    const policyErr = (typeof PROD_SETUP!=='undefined') ? PROD_SETUP.validatePrivacyPassword(next, AUTH.user, current) : '';
    if(policyErr){ LOGIN6.error = policyErr; toast('Privacy password requirement', policyErr, 'err'); return render(); }
    const strength = passwordStrength(next);
    if(strength.n < 2){ LOGIN6.error = 'Use at least 12 characters with uppercase, lowercase, digits and a symbol.'; return render(); }
    LOGIN6.mustChangeBusy = true;
    render();
    try{
      let r = {ok:false};
      const hosted = typeof SYNC !== 'undefined' && SYNC.available && SYNC.available();
      if(hosted){
        if(!SYNC.sessionToken){
          LOGIN6.mustChangeBusy = false;
          LOGIN6.error = 'The shared online session is not available. Sign in again; the password was not changed locally.';
          return render();
        }
        try { r = await AUTH.changeOnServer(current, next); }
        catch(_e) { r = {ok:false, error:'The shared online source could not be reached.'}; }
        if(!r.ok){
          LOGIN6.mustChangeBusy = false;
          LOGIN6.error = r.error || 'The shared online source refused the password change. No local password change was made.';
          return render();
        }
        /* The first-login gate intentionally withheld the workspace. Replace
           it only with a fresh authorised snapshot after the password commits. */
        if(SYNC._passwordBeforeWorkspace){
          clearTimeout(SYNC._timer); APPX.dirty = false;
          const pulled = await SYNC.pullFull({minRev:r.rev || 0});
          if(!pulled){
            await SYNC.logout(); AUTH.logout(); LOGIN6.mustChangeBusy = false;
            APPX.screen='login'; LOGIN6.error='Your private password was saved, but the workspace could not load. Sign in again with your new password.';
            return render();
          }
          AUTH.user = (DB.db.users||[]).find(u=>u.username===AUTH.user.username) || AUTH.user;
          uRec = AUTH.user; SYNC._passwordBeforeWorkspace = false;
        }
      } else if(!r.ok){
        const currentValid = (AUTH._pw && current === AUTH._pw) || (uRec && uRec.salt && uRec.hash && strongHash(current, uRec.salt) === uRec.hash);
        if(!currentValid){
          LOGIN6.mustChangeBusy = false;
          LOGIN6.error = 'Current temporary password is incorrect.';
          toast('Incorrect current password','Enter the one-time setup or WhatsApp password you signed in with.','err');
          return render();
        }
        const local = AUTH.setPassword(next);
        if(local && local.ok === false){ LOGIN6.mustChangeBusy = false; LOGIN6.error = local.msg; return render(); }
      }
      if(AUTH.user){
        const markActive = target => {
          if(!target) return;
          target.status = 'active';
          target.active = true;
          target.activatedAt = todayISO();
          target.mustChange = false;
          target.mustChangePassword = false;
          target.dpaFirstLoginRequired = false;
          target.passwordSetAt = todayISO();
          target.failedLogins = 0;
        };
        markActive(AUTH.user);
        if(uRec && uRec !== AUTH.user) markActive(uRec);
        if(typeof AUTH._rememberVerifier === 'function') AUTH._rememberVerifier(AUTH.user, next);
        AUDIT.append({ actor:AUTH.user.id, action:'account.self_activated', entity:'user', entityId:AUTH.user.id, detail:`${AUTH.user.username} completed first-login password change & self-activated account.` });
        DB.save();
      }
      AUTH.mustChange = false;
      LOGIN6.error='';
      SESSION.start();
      if(typeof SYNC!=='undefined' && SYNC.sessionToken) SYNC.startPolling();
      NAVH.reset(); NAVH.push('home',{}); APPX.view='home'; APPX.params={};
      if(AUTH.user && AUTH.user.roleId==='chief' && typeof PROD_SETUP!=='undefined' && !PROD_SETUP.isGloballyActivated()){
        let shouldAutoFeed = Boolean(ONB._pendingCloudAutoFeed || (d && d.get && d.get('autoFeedCloudMaster')));
        try {
          if (sessionStorage.getItem('carelink.pendingCloudAutoFeed') === '1') shouldAutoFeed = true;
          sessionStorage.removeItem('carelink.pendingCloudAutoFeed');
        } catch (_e) {}
        ONB._pendingCloudAutoFeed = false;
        const currentPatients = (DB.db && Array.isArray(DB.db.patients)) ? DB.db.patients.length : 0;
        if (shouldAutoFeed && currentPatients < DEMO_REGISTER.patients && typeof REFERENCE_MASTER !== 'undefined' && typeof REFERENCE_MASTER.autoFeedFromCloud === 'function') {
          /* Flush any queued account/audit patch first so PUT /api/state never
             races concurrently against POST /api/master-import/auto-seed. */
          if (hosted && typeof SYNC !== 'undefined') {
            clearTimeout(SYNC._timer);
            if (APPX.dirty && SYNC.push) await SYNC.push();
          }
          render();
          const fed = await REFERENCE_MASTER.autoFeedFromCloud({ silent: true });
          if (fed && fed.ok) {
            toast(`Password Saved & ${num(DEMO_REGISTER.patients)}-Patient Dataset Loaded`, `All ${num(DEMO_REGISTER.patients)} complete patients and their visits & PDCAs are now live in Cloud KV. Click "Activate System Globally" at the top of your console.`, 'ok');
          } else {
            toast('Password Updated - Ready for Global Activation', `Click "Auto-Feed ${num(DEMO_REGISTER.patients)}-Patient Dataset" or "Activate System Globally" at the top of your console.`, 'warn');
          }
        } else {
          toast('Password Updated - Ready for Global Activation','Click "Activate System Globally" at the top of your console to generate the Team WhatsApp Credential Sheet.','ok');
        }
      } else {
        toast('Account Activated & Private Password Saved','Your console is now open with your personal encrypted password known only to you.','ok');
      }
      LOGIN6.mustChangeBusy = false;
      render();
    }finally{
      if(LOGIN6.mustChangeBusy){
        LOGIN6.mustChangeBusy = false;
        try{ render(); }catch(_e){}
      }
    }
  },

  activate6: async (d) => {
    const rawUser = String(d.get('username')||'').trim().toLowerCase();
    const code = String(d.get('code')||'').trim().toUpperCase();
    const pw = String(d.get('password')||''), pw2 = String(d.get('password2')||'');
    if(pw!==pw2){ LOGIN6.error = 'The passwords do not match.'; return render(), toast('The passwords do not match','Re-type the same password.','err'); }
    const policyErr = (typeof PROD_SETUP!=='undefined' && PROD_SETUP.validatePrivacyPassword) ? PROD_SETUP.validatePrivacyPassword(pw, { username: rawUser }) : '';
    if(policyErr){ LOGIN6.error = policyErr; render(); return toast('Privacy password requirement', policyErr, 'err'); }
    if(passwordStrength(pw).n < 2) return toast('Choose a stronger password','At least 12 characters with uppercase, lowercase, digits and a symbol.','err');
    let r = { ok:false };
    try {
      if(typeof SYNC !== 'undefined' && SYNC._json){
        r = await SYNC._json('api/public/activate', {method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({username:rawUser, code, password: pw})});
      }
    } catch(_e) { r = { ok:false }; }
    if(r && r.ok){
      LOGIN6.tab='signin'; LOGIN6.error=''; LOGIN6.notice='Account activated. Sign in with your new password.';
      return render();
    }
    if(typeof SYNC !== 'undefined' && SYNC.available && SYNC.available()){
      LOGIN6.error = (r && r.body && r.body.error) || 'The shared online source could not activate this account. No device-local activation was made.';
      return render();
    }
    const usr = (DB.db.users||[]).find(u=>u.username.toLowerCase()===rawUser || String(u.email||'').toLowerCase()===rawUser);
    const uname = usr ? usr.username.toLowerCase() : rawUser;
    const act = (DB.db.pendingActivations||[]).find(a=>String(a.username||'').toLowerCase()===uname && a.code===code && !a.used && new Date(a.expiresAt)>new Date());
    if(act && usr){
      act.used = true; act.usedAt = new Date().toISOString();
      usr.salt = newSalt(); usr.hash = strongHash(pw, usr.salt); usr.active = true; usr.status = 'active';
      usr.mustChange = false; usr.mustChangePassword = false; usr.dpaFirstLoginRequired = false; usr.failedLogins = 0;
      AUDIT.append({ actor:usr.id, action:'account.activated', entity:'user', entityId:usr.id, detail:`Activated via code ${code}` });
      DB.save();
      LOGIN6.tab='signin'; LOGIN6.error=''; LOGIN6.notice='Account activated. Sign in now with your chosen password.';
      return render();
    }
    LOGIN6.error = (r && r.body && r.body.error) || 'Invalid or expired activation code for that username.';
    render();
  },

  request6: async (d) => {
    const body = {};
    ['name','jobTitle','departmentId','countyId','phone','justification'].forEach(k=>body[k]=String(d.get(k)||'').trim());
    if(!body.name || !body.phone){ LOGIN6.error = 'Enter your full name and phone/WhatsApp number.'; return render(); }
    const cId = body.countyId || 'kisumu';
    const assignedAdminUsername = cId === 'homabay' ? 'homabay.admin' : 'kisumu.admin';
    const countyLabel = countyName(cId);
    const payload = { ...body, countyId:cId, assignedCountyId:cId, assignedAdminUsername, urgent:true, priority:'urgent' };
    let r = { ok:false };
    try {
      if(typeof SYNC !== 'undefined' && SYNC._json){
        r = await SYNC._json('api/public/account-request', {method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify(payload)});
      }
    } catch(_e) { r = { ok:false }; }
    if(typeof SYNC !== 'undefined' && SYNC.available && SYNC.available() && (!r || !r.ok)){
      LOGIN6.error = (r && r.body && r.body.error) || 'The shared online source could not receive the account request. It was not saved only on this device.';
      return render();
    }
    const ref = (r && r.ok && r.body && r.body.ref) ? r.body.ref : ('REQ-' + Math.floor(100000 + Math.random()*900000));
    DB.db.accountRequests = DB.db.accountRequests || [];
    DB.db.accountRequests.unshift({
      id:uid('arq'), ref, ...payload, contact:body.phone, reason:body.justification,
      status:'open', at:new Date().toISOString(), submittedAt:new Date().toISOString()
    });
    AUDIT.append({ actor:'public', action:'account.requested.county_urgent', entity:'accountRequest', entityId:ref,
      detail:`URGENT -> ${assignedAdminUsername} (${countyLabel}): ${body.name} (${body.jobTitle})` });
    DB.save();
    LOGIN6.tab='signin'; LOGIN6.error='';
    LOGIN6.notice = `Urgent request ${ref} routed directly to the ${countyLabel} County Office Administrator (${assignedAdminUsername}) for immediate verification & credential issuance.`;
    render();
  },

  forgot6: async (d) => {
    const rawId = String(d.get('username')||'').trim().toLowerCase();
    if(!rawId){ LOGIN6.error = 'Enter your username or official email.'; return render(); }
    const matchedUser = (DB.db && DB.db.users || []).find(u => String(u.username||'').toLowerCase()===rawId || String(u.email||'').toLowerCase()===rawId);
    const cId = String(d.get('countyId') || (matchedUser && matchedUser.countyId) || 'kisumu').trim();
    const assignedAdminUsername = cId === 'homabay' ? 'homabay.admin' : 'kisumu.admin';
    const countyLabel = countyName(cId);
    const username = matchedUser ? matchedUser.username : rawId;
    const payload = { username, identifier:rawId, countyId:cId, assignedCountyId:cId, assignedAdminUsername, urgent:true, priority:'urgent' };
    let r = { ok:false };
    try {
      if(typeof SYNC !== 'undefined' && SYNC._json){
        r = await SYNC._json('api/auth/forgot', {method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify(payload)});
      }
    } catch(_e) { r = { ok:false }; }
    if(typeof SYNC !== 'undefined' && SYNC.available && SYNC.available() && (!r || !r.ok)){
      LOGIN6.error = (r && r.body && r.body.error) || 'The shared online source could not receive the recovery request. It was not saved only on this device.';
      return render();
    }
    const ref = (r && r.ok && r.body && r.body.reference) ? r.body.reference : ('REC-' + Math.floor(10000 + Math.random()*90000));
    DB.db.recoveryRequests = DB.db.recoveryRequests || [];
    DB.db.recoveryRequests.unshift({
      id:uid('rec'), reference:ref, ...payload, at:new Date().toISOString(), status:'open'
    });
    AUDIT.append({ actor:username||'unknown', action:'auth.recovery_requested.county_urgent', entity:'user', entityId:username,
      detail:`URGENT -> ${assignedAdminUsername} (${countyLabel}) · Reference ${ref}` });
    DB.save();
    LOGIN6.error='';
    LOGIN6.notice = `Urgent recovery request ${ref} routed directly to your ${countyLabel} County Office Administrator (${assignedAdminUsername}), who can issue an immediate reset or 24-hour EMG code.`;
    LOGIN6.tab='forgot';
    render();
  },

  emergency6: async (d) => {
    const rawUser = String(d.get('username')||'').trim().toLowerCase();
    const code = String(d.get('code')||'').trim().toUpperCase();
    const password = String(d.get('password')||'');
    const policyErr = (typeof PROD_SETUP!=='undefined' && PROD_SETUP.validatePrivacyPassword) ? PROD_SETUP.validatePrivacyPassword(password, { username: rawUser }) : '';
    if(policyErr){ LOGIN6.error = policyErr; render(); return toast('Privacy password requirement', policyErr, 'err'); }
    if(passwordStrength(password).n < 2) return toast('Choose a stronger password','Use at least 12 characters with uppercase, lowercase, digits and a symbol.','err');
    let r = { ok:false };
    try {
      if(typeof SYNC !== 'undefined' && SYNC._json){
        r = await SYNC._json('api/auth/emergency', {method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({username:rawUser, code, password})});
      }
    } catch(_e) { r = { ok:false }; }
    if(r && r.ok){
      LOGIN6.tab='signin'; LOGIN6.notice='Password reset with emergency code. Sign in now.'; LOGIN6.error='';
      return render();
    }
    if(typeof SYNC !== 'undefined' && SYNC.available && SYNC.available()){
      LOGIN6.error = (r && r.body && r.body.error) || 'The shared online source could not reset this password. No device-local reset was made.';
      return render();
    }
    const usr = (DB.db.users||[]).find(u=>u.username.toLowerCase()===rawUser || String(u.email||'').toLowerCase()===rawUser);
    const uname = usr ? usr.username.toLowerCase() : rawUser;
    const emg = (DB.db.emergencyCodes||[]).find(e=>String(e.username||'').toLowerCase()===uname && e.code===code && !e.used && new Date(e.expiresAt)>new Date());
    if(emg && usr){
      emg.used = true; emg.usedAt = new Date().toISOString();
      usr.salt = newSalt(); usr.hash = strongHash(password, usr.salt);
      usr.mustChange = false; usr.mustChangePassword = false; usr.dpaFirstLoginRequired = false;
      usr.failedLogins = 0; usr.status = 'active'; usr.active = true;
      AUDIT.append({ actor:usr.id, action:'auth.emergency_reset', entity:'user', entityId:usr.id, detail:'Reset via 24h emergency code' });
      DB.save();
      LOGIN6.tab='signin'; LOGIN6.notice='Password reset with emergency code. Sign in now.'; LOGIN6.error='';
      return render();
    }
    LOGIN6.error = (r && r.body && r.body.error) || 'Invalid or expired emergency code.';
    render();
  }
});
