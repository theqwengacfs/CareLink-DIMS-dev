/* ============================================================
   handover_partners6.js - CareLink v6.3
   1. Delegation Plan, Scoped Reliever Access & Tri-Party Role
      Handover / Acceptance Protocol + EPPH v2.2 Leave Governance
   2. CCC / PSC / Hospital Clinician Referral Desk Console
   3. County & National Government Privacy-Safe Partnership
      Dashboard + Public / Private Portal Mode Governance
   4. International Medical Team 120+ Day PDCA Overstay Console
   ============================================================ */

/* Names supplied by the Foundation in its referral-partner screenshot.
   No phone numbers, contracts, locations or account memberships are inferred. */
const REFERRAL_PARTNERS = [
  'Jaramogi Oginga Odinga Teaching & Referral Hospital (JOOTRH)',
  'Kisumu County Referral', 'Ahero County Hospital', 'Masogo Sub-County Hospital',
  'Chiga Dispensary', 'Railways Health Centre', 'Nyalunya Health Center',
  'Bunde Health Centre', 'St. Mark Lela Health Centre', 'Kowino Health Centre',
  'Ongo Ogosa Health Centre', 'Ogra Foundation', 'Port Florence Community Hospital'
];
const CCC_NEED_OPTIONS = [
  'Nutritional stabilisation (Foodbag 1 / Bag 2)',
  'ARV / TB medication adherence home follow-up',
  'Home wound care & dressing materials',
  'Outpatient specialist / lab investigation support',
  'SHA / SHIF health cover registration & arrears support',
  'Short-stay medical recovery respite (Homestay)',
  'Household child / orphan-prevention social protection'
];

const HANDOVER_PARTNERS = {
  ensureStore(){
    if(!DB.db) return;
    const today = todayISO().slice(0,10);
    if(DB.db.meta?.synthetic!==true || !(DB.db.patients||[]).every(p=>p.demo===true)){
      for(const c of ['handoverPackets','cccReferrals','intlPdcaDossiers'])DB.db[c]=DB.db[c]||[];
      return;
    }

    /* 1. Delegation & Handover packets */
    DB.db.handoverPackets = DB.db.handoverPackets || [
      {
        id:'DEL-2026-01',
        kind:'leave_delegation',
        staffName:'Nyalenda Field Caregiver',
        staffRole:'Field Caregiver',
        countyId:'kisumu',
        areaId:'nyalenda',
        leaveType:'Annual Leave (21-day entitlement · >=14d notice)',
        fromDate:today,
        toDate:_hpAddDays(today, 10),
        noticeDays:16,
        relieverUsername:'coord.nyalenda',
        relieverName:'Nyalenda Area Coordinator (Scoped Reliever)',
        scopedConsoleGranted:true,
        ppeCustody:'Field Tablet #KS-T04, Weighing Scale, Rain Umbrella & Home Visit Folder handed over',
        patientHandoverRows:[
          { code:'LOM-KS-101', schedule:'Every week (Tue)', bag:'BG1', action:'3rd-visit weigh-in due + verify ARV pill count' },
          { code:'LOM-KS-104', schedule:'Every other week', bag:'BG2', action:'Post-JOOTRH MOPC clinic review check' }
        ],
        outgoingSigned:true,
        relieverAccepted:true,
        supervisorApproved:true,
        status:'active_reliever'
      },
      {
        id:'HND-2026-02',
        kind:'role_takeover',
        staffName:'Outgoing Procurement Assistant',
        staffRole:'Procurement & Store Custody',
        countyId:'kisumu',
        areaId:'',
        leaveType:'Departmental Role Transition & Acceptance Report',
        fromDate:today,
        toDate:today,
        noticeDays:30,
        relieverUsername:'procurement',
        relieverName:'Incoming Procurement Officer',
        scopedConsoleGranted:true,
        ppeCustody:'Store keys, GRN books, supplier quote binders & stock cards reconciled and signed',
        patientHandoverRows:[],
        deliverables:'Q4 Hygiene Pack tender file, Monday foodbag stock ledger & county mosquito net balance verified',
        outgoingSigned:true,
        relieverAccepted:true,
        supervisorApproved:true,
        status:'accepted_closed'
      }
    ];

    /* 2. CCC / PSC Facility Referrals (synthetic IDs strictly per v63.js: CCC/9xxxx, 07001xxxxx, 9xxxxxxx) */
    DB.db.cccReferrals = DB.db.cccReferrals || [
      {
        id:'CCC-REF-901',
        facilityName:'JOOTRH Comprehensive Care Centre (CCC)',
        referredByUsername:'ccc.jootrh',
        referredByClinician:'Demo - JOOTRH CCC Clinician',
        countyId:'kisumu',
        areaId:'nyalenda',
        patientInitials:'Beneficiary M.A. (Demo)',
        cccNumber:'CCC/90412',
        nationalId:'94120834',
        phone:'0700141208',
        referralDate:today,
        bmiAtReferral:15.8,
        needs:['Nutritional stabilisation (Foodbag 1 / Bag 2)', 'ARV / TB medication adherence home follow-up', 'SHA / SHIF health cover registration & arrears support'],
        clinicalNotes:'Discharged from JOOTRH medical ward with SAM (BMI 15.8 kg/m²) on TLD + Pyridoxine; needs home nutrition & fortnightly pill-count support.',
        status:'enrolled_active',
        lomamoCode:'LOM-KS-891',
        masterReportSummary:'Enrolled in Nyalenda Ministry Area: receiving weekly Bag 1 + multivitamins; weight up +1.6 kg after 3 home visits; MOPC review booked.',
        feedbackThread:[
          { by:'Kisumu County Admin Assistant', role:'County Admin Assistant', at:today, msg:'Hard-copy LMMK 001 completed & 4 pages scanned. Assigned to Nyalenda Caregiver pair.' },
          { by:'Demo - JOOTRH CCC Clinician', role:'CCC / PSC Hospital Clinician', at:today, msg:'Thank you — scheduled next viral-load blood draw at JOOTRH CCC in 4 weeks.' }
        ]
      },
      {
        id:'CCC-REF-902',
        facilityName:'Kisumu County Referral Hospital (KCRH) PSC',
        referredByUsername:'ccc.kcrh',
        referredByClinician:'Demo - KCRH PSC Nurse',
        countyId:'kisumu',
        areaId:'kondele',
        patientInitials:'Beneficiary J.O. (Demo)',
        cccNumber:'CCC/90588',
        nationalId:'95881204',
        phone:'0700158812',
        referralDate:today,
        bmiAtReferral:17.1,
        needs:['Home wound care & dressing materials', 'Nutritional stabilisation (Foodbag 1 / Bag 2)'],
        clinicalNotes:'Post-surgical lower-limb dressing + moderate undernutrition (BMI 17.1). Requesting LOMAMO Kondele home nursing & nutrition review.',
        status:'awaiting_assessment',
        lomamoCode:'Pending Assessment',
        masterReportSummary:'Queued for Kondele Wednesday home assessment visit by Caregiver pair + Nurse.',
        feedbackThread:[
          { by:'Demo - KCRH PSC Nurse', role:'CCC / PSC Hospital Clinician', at:today, msg:'Patient lives near Kondele market; discharged with 5 days of sterile gauze.' }
        ]
      },
      {
        id:'CCC-REF-903',
        facilityName:'Homa Bay County Teaching & Referral Hospital CCC',
        referredByUsername:'ccc.hbctrh',
        referredByClinician:'Demo - Homa Bay CCC Clinician',
        countyId:'homabay',
        areaId:'homabay_town',
        patientInitials:'Beneficiary P.N. (Demo)',
        cccNumber:'CCC/90731',
        nationalId:'97310492',
        phone:'0700173104',
        referralDate:today,
        bmiAtReferral:16.4,
        needs:['Nutritional stabilisation (Foodbag 1 / Bag 2)', 'Household child / orphan-prevention social protection'],
        clinicalNotes:'Single mother of 3 on second-line ART recovering from pulmonary TB; BMI 16.4 kg/m².',
        status:'enrolled_active',
        lomamoCode:'LOM-HB-412',
        masterReportSummary:'Active in Homa Bay Town caseload: Bag 2 family nutrition + pyridoxine verified; dependent-child nutrition and guardian care reviewed.',
        feedbackThread:[]
      }
    ];

    /* Dossiers exist only after the MCM authorizes and shares a revision. */
    DB.db.intlPdcaDossiers = DB.db.intlPdcaDossiers || [];
  },

  /* =====================================================================
     1. DELEGATION PLAN, SCOPED RELIEVER ACCESS & ROLE HANDOVER + EPPH v2.2
     ===================================================================== */
  renderHandover(user, params={}){
    if(!RBAC.can(user,'handover.use',{}).ok) return deniedPanel('handover.use');
    this.ensureStore();
    const tab = params.tab || 'delegation';
    const packets = (DB.db.handoverPackets||[]).filter(h=>isGlobal(user) || !user.countyId || h.countyId===user.countyId);
    const leaveDelegations = packets.filter(h=>h.kind==='leave_delegation');
    const roleTakeovers = packets.filter(h=>h.kind==='role_takeover');

    let body = '';
    if(tab==='delegation'){
      body = `<div class="note" style="margin-bottom:14px">${ic('key',16)}<span><b>CareLink Scoped Reliever Console Protocol:</b> When a caregiver, coordinator, or officer goes on planned leave (>=14 days notice) or urgent duty, filing a Delegation Plan assigns a named reliever, itemises every patient/task action, records PPE/tablet custody, and grants time-bounded reliever console visibility once accepted by the reliever and approved by the supervisor.</span></div>`
      + leaveDelegations.map(h=>`<div class="card" style="margin-bottom:14px">
          <div class="card-h">
            <div>
              <h3>${esc(h.id)} · ${esc(h.staffName)} -> ${esc(h.relieverName)}</h3>
              <div class="xs muted">${esc(h.leaveType)} · Period: <b>${esc(fmtDate(h.fromDate))} -> ${esc(fmtDate(h.toDate))}</b> (${h.noticeDays}d advance notice)</div>
            </div>
            <div class="row" style="gap:6px;flex-wrap:wrap">
              ${h.scopedConsoleGranted ? badge('Scoped Reliever Console Active','b-ok') : badge('Awaiting Reliever / Supervisor Sign-Off','b-warn')}
              ${!h.relieverAccepted ? `<button class="btn btn-xs btn-primary" data-act="handover-accept" data-id="${esc(h.id)}">${ic('check',12)} Accept as Reliever</button>` : ''}
            </div>
          </div>
          <div class="card-b">
            <div class="grid g3 small" style="gap:10px;margin-bottom:10px">
              <div><span class="muted">County / Ministry Area:</span> <b>${esc(countyName(h.countyId))}${h.areaId?' · '+esc(areaName(h.areaId)):''}</b></div>
              <div><span class="muted">PPE & Field Kit Custody:</span> <b>${esc(h.ppeCustody)}</b></div>
              <div><span class="muted">3-Party Sign-Off:</span> <b>Outgoing ${h.outgoingSigned?'✓':'…'} · Reliever ${h.relieverAccepted?'✓':'Pending'} · Supervisor ${h.supervisorApproved?'✓':'Pending'}</b></div>
            </div>
            ${(h.patientHandoverRows||[]).length ? table([
              {label:'Patient Code', cls:'mono', render:r=>`<b>${esc(r.code)}</b>`},
              {label:'Visit Cadence', render:r=>esc(r.schedule)},
              {label:'Foodbag', cls:'mono', render:r=>badge(r.bag,'b-info','nodot')},
              {label:'Mandatory Reliever Action During Leave', render:r=>esc(r.action)}
            ], h.patientHandoverRows) : ''}
          </div>
        </div>`).join('');
    }

    if(tab==='takeover'){
      body = `<div class="note" style="margin-bottom:14px">${ic('clipboard',16)}<span><b>Permanent / Transition Role Handover & Acceptance Report:</b> Requires tri-party execution (<b>Outgoing Staff</b>, <b>Incoming Officer</b>, and <b>Witnessing Supervisor / HR</b>) verifying pending deliverables, physical registers, asset/key custody, and system credential transition.</span></div>`
      + card('Executed & Pending Role Handover / Takeover Acceptance Reports', table([
          {label:'Report Ref', cls:'mono', render:h=>`<b>${esc(h.id)}</b>`},
          {label:'Outgoing -> Incoming', render:h=>`<b>${esc(h.staffName)}</b> -> <b>${esc(h.relieverName)}</b><div class="xs muted">${esc(h.staffRole)} · ${esc(countyName(h.countyId))}</div>`},
          {label:'Deliverables & Custody Verified', render:h=>`<span class="small">${esc(h.deliverables||h.ppeCustody)}</span>`},
          {label:'Tri-Party Signatures', render:h=>`<span class="xs">Outgoing ${h.outgoingSigned?'✓':''} · Incoming ${h.relieverAccepted?'✓':'Pending'} · Witness ${h.supervisorApproved?'✓':'Pending'}</span>`},
          {label:'Status', render:h=>badge(h.relieverAccepted?'Accepted & Signed':'Awaiting Takeover Sign-Off', h.relieverAccepted?'b-ok':'b-warn')}
        ], roleTakeovers, {emptyMsg:'No permanent role transition reports filed yet.'}));
    }

    if(tab==='epph'){
      const ledgerRows = [
        { type:'Annual Leave', ent:'21 working days / yr', cf:'<= 10 days (forfeit after 31 Mar)', acc:'1.75 days / month', taken:'9 days', bal:'16 days', rule:'Submit >= 14 days in advance with signed Reliever Delegation Plan' },
        { type:'Sick Leave', ent:'30d full + 15d half pay', cf:'0 days', acc:'Statutory per yr', taken:'2 days', bal:'28d full', rule:'Medical certificate from licensed practitioner mandatory if > 3 days' },
        { type:'Maternity / Paternity', ent:'90 cal. days / 14 cal. days', cf:'0 days', acc:'Statutory event', taken:'0 days', bal:'Eligible', rule:'Employment Act (Kenya) full pay protection & return-to-role handover' },
        { type:'Compassionate Leave', ent:'Up to 7 days / yr', cf:'0 days', acc:'Event-verified', taken:'0 days', bal:'7 days', rule:'Immediate supervisor + HR notification with emergency reliever cover' }
      ];
      body = card('LOMAMO Employee Policies & Procedures Handbook (EPPH v2.2) — 6-Column Leave Ledger & Statutory Rules',
        table([
          {label:'Leave Category', render:r=>`<b>${esc(r.type)}</b>`},
          {label:'Annual Entitlement', render:r=>esc(r.ent)},
          {label:'Carry-Forward Cap', render:r=>esc(r.cf)},
          {label:'Monthly Accrual', cls:'mono', render:r=>esc(r.acc)},
          {label:'Sample Balance', cls:'mono', render:r=>`<b>${esc(r.bal)}</b>`},
          {label:'EPPH v2.2 Governance Rule', render:r=>`<span class="small">${esc(r.rule)}</span>`}
        ], ledgerRows),
        {sub:'Absence without leave or lawful cause exceeding 7 consecutive days triggers Employment Act s.44(4)(a) gross-misconduct disciplinary review. Progressive ladder: Verbal Counselling -> 1st Written Warning -> Final Written Warning -> Show-Cause Hearing -> Separation Appeal.'});
    }

    return pageHead('Delegation plans, scoped reliever handover & EPPH v2.2 governance',
      'Ensures zero gap in patient care when staff take leave or transition roles: binds leave requests (>=14d notice) to per-patient action tables, PPE custody, scoped reliever console access, and formal takeover acceptance.',
      `<button class="btn btn-sm btn-ghost" data-act="go" data-v="leave">${ic('calendar',15)} Leave & Field Roster</button>
       <button class="btn btn-sm btn-ghost" data-act="handover-new-modal" data-kind="role_takeover">${ic('clipboard',15)} New Role Handover Report</button>
       <button class="btn btn-sm btn-primary" data-act="handover-new-modal" data-kind="leave_delegation">${ic('plus',15)} New Leave Delegation Plan</button>`)
    + `<div class="grid g4" style="margin-bottom:14px">
        ${kpi('Active reliever delegations', num(leaveDelegations.filter(x=>x.scopedConsoleGranted).length), 'Scoped console access active', 'ok', 'key')}
        ${kpi('Role takeover reports', num(roleTakeovers.length), 'Tri-party signed custody trail', 'info', 'clipboard')}
        ${kpi('Advance notice standard', '≥ 14 days', 'Annual leave (21d · 1.75d/mo accrual)', 'ok', 'calendar')}
        ${kpi('Carry-over cut-off', 'Max 10d -> 31 Mar', 'EPPH v2.2 & Employment Act compliant', 'warn', 'shieldcheck')}
      </div>`
    + `<div class="tabs">
        <button class="tab ${tab==='delegation'?'active':''}" data-act="go" data-v="handover" data-tab="delegation">Leave Delegation & Scoped Reliever Access (${leaveDelegations.length})</button>
        <button class="tab ${tab==='takeover'?'active':''}" data-act="go" data-v="handover" data-tab="takeover">Permanent Role Handover & Acceptance (${roleTakeovers.length})</button>
        <button class="tab ${tab==='epph'?'active':''}" data-act="go" data-v="handover" data-tab="epph">EPPH v2.2 Leave Ledger & Policy Rules</button>
      </div>`
    + body;
  },

  /* =====================================================================
     2. CCC / PSC / HOSPITAL DESK CONSOLE (External Facility Clinicians)
     ===================================================================== */
  renderCccDesk(user, params={}){
    if(!RBAC.can(user,'ccc.desk',{}).ok) return deniedPanel('ccc.desk');
    this.ensureStore();
    const tab = params.tab || 'referrals';
    const isExtClinician = user.roleId === 'ccc.clinician';

    /* STRICT DATA ISOLATION: External CCC clinicians see ONLY referrals they / their facility submitted! */
    const allRefs = DB.db.cccReferrals || [];
    const myRefs = isExtClinician
      ? allRefs.filter(r=>r.referredByUsername===user.username)
      : allRefs.filter(r=>isGlobal(user) || !user.countyId || r.countyId===user.countyId);

    let body = '';
    if(tab==='referrals'){
      body = `${isExtClinician ? `<div class="note" style="margin-bottom:14px">${ic('lock',15)}<span><b>Strict Facility Referral Privacy Scope:</b> Signed in as <b>${esc(user.name)}</b>. You view <b>only patients referred by your facility desk</b> (${myRefs.length} record${myRefs.length===1?'':'s'}), receive Master Referral updates from LOMAMO Ministry Areas, and exchange clinical coordination notes with County Admin Assistants and Caregivers.</span></div>` : ''}
      ${card(isExtClinician ? 'Patients Referred by My CCC / PSC Facility Desk' : 'Incoming CCC / PSC & Public Hospital Referrals', table([
        {label:'Referral # & Facility', render:r=>`<b class="mono">${esc(r.id)}</b><div class="xs muted">${esc(r.facilityName)} · ${esc(fmtDate(r.referralDate))}</div>`},
        {label:'Patient & CCC No.', render:r=>`<b>${esc(r.patientInitials)}</b><div class="xs mono muted">${esc(r.cccNumber)} · LOMAMO: ${esc(r.lomamoCode)}</div>`},
        {label:'Target Ministry Area', render:r=>`${esc(areaName(r.areaId))}<div class="xs muted">${esc(countyName(r.countyId))}</div>`},
        {label:'Selected Support Needs', render:r=>`<div class="row" style="gap:4px;flex-wrap:wrap">${(r.needs||[]).map(n=>`<span class="badge b-info nodot">${esc(n.split('(')[0].trim())}</span>`).join('')}</div><div class="xs muted" style="margin-top:3px">${esc(r.clinicalNotes)}</div>`},
        {label:'BMI at Referral', render:r=>typeof BMI_CLINICAL!=='undefined' ? BMI_CLINICAL.badgeHTML(r.bmiAtReferral, true) : esc(String(r.bmiAtReferral))},
        {label:'Status', render:r=>badge(r.status==='enrolled_active'?'Enrolled & Active':'Awaiting Assessment', r.status==='enrolled_active'?'b-ok':'b-warn')},
        {label:'Feedback', cls:'act', render:r=>`<button class="btn btn-xs btn-ghost" data-act="ccc-feedback-modal" data-id="${esc(r.id)}">${ic('send',12)} Feedback (${(r.feedbackThread||[]).length})</button>`}
      ], myRefs, {emptyMsg:'No facility referrals submitted from this desk yet — click "+ Submit Patient Referral" above.'}))}`;
    }

    if(tab==='partners') body=card('Referral Partners & Health Facilities',`<p class="small muted">Foundation-supplied directory. Each facility account is provisioned individually; listing a partner does not grant access.</p><div class="grid g3">${REFERRAL_PARTNERS.map(name=>`<div class="note"><b>${esc(name)}</b></div>`).join('')}</div>`);
    if(tab==='master'){
      body = card('Master Referral Reports Returned from LOMAMO Ministry Areas', table([
        {label:'Referral / LOMAMO Code', cls:'mono', render:r=>`<b>${esc(r.lomamoCode)}</b><div class="xs muted">${esc(r.id)} · ${esc(r.cccNumber)}</div>`},
        {label:'Referring Facility', render:r=>esc(r.facilityName)},
        {label:'Ministry Area', render:r=>esc(areaName(r.areaId))},
        {label:'Ministry Area & MCM Master Referral Progress Report', render:r=>`<span class="small">${esc(r.masterReportSummary)}</span>`},
        {label:'Action', cls:'act', render:r=>`<div class="row" style="gap:8px;flex-wrap:wrap">${!isExtClinician?`<button class="btn btn-xs btn-primary" data-act="coordination-open" data-kind="referral.report" data-id="${esc(r.id)}">Submit progress report</button>`:''}<button class="btn btn-xs btn-ghost" data-act="referral-report-print" data-id="${esc(r.id)}">Report history / print</button><button class="btn btn-xs btn-ghost" data-act="ccc-feedback-modal" data-id="${esc(r.id)}">Reply</button></div>`}
      ], myRefs, {emptyMsg:'Master Referral progress summaries appear here once a referred patient is assessed.'}));
    }

    return pageHead('CCC / PSC & Hospital Clinician Referral Desk',
      'Secure clinical bridge for government & partner hospital doctors, clinical officers, nurses, and CHVs to refer vulnerable patients, track ONLY their referred caseload, receive Master Referral reports, and message County Admin Assistants & caregivers.',
      `<button class="btn btn-sm btn-primary" data-act="ccc-new-referral-modal">${ic('plus',15)} Submit Patient Referral</button>`)
    + `<div class="grid g4" style="margin-bottom:14px">
        ${kpi('Referrals in my scope', num(myRefs.length), isExtClinician?'Strictly isolated to your facility':'Across partner CCC/PSC desks', 'info', 'hospital')}
        ${kpi('Enrolled in Ministry Areas', num(myRefs.filter(r=>r.status==='enrolled_active').length), 'Active home nutrition & adherence care', 'ok', 'check')}
        ${kpi('Master Referral reports', num(myRefs.filter(r=>r.masterReportSummary).length), 'Returned from Ministry Areas & MCM', 'ok', 'file')}
        ${kpi('Two-way feedback notes', num(myRefs.reduce((n,r)=>n+(r.feedbackThread?.length||0),0)), 'With County Admin Assistants & Caregivers', 'info', 'send')}
      </div>`
    + `<div class="tabs">
        <button class="tab ${tab==='referrals'?'active':''}" data-act="go" data-v="cccdesk" data-tab="referrals">Referred Patients & Needs (${myRefs.length})</button>
        <button class="tab ${tab==='partners'?'active':''}" data-act="go" data-v="cccdesk" data-tab="partners">Partner directory</button>
        <button class="tab ${tab==='master'?'active':''}" data-act="go" data-v="cccdesk" data-tab="master">Master Referral Reports from Ministry Areas</button>
      </div>`
    + body;
  },

  /* =====================================================================
     3. OFFICIAL COUNTY GOVERNMENT, MINISTRY OF HEALTH & PRESIDENTIAL
        ALL-AREAS PRESENTATION & OVERSIGHT CONSOLE (v6.5)
     ===================================================================== */
  renderGovDashboard(user, params={}){
    if(!RBAC.can(user,'gov.oversight',{}).ok) return deniedPanel('gov.oversight');
    DB.db.settings = DB.db.settings || {};
    if(!DB.db.settings.govAuthoritySeats){
      DB.db.settings.govAuthoritySeats = {
        presidential: { label:'Presidential & Board All-Areas Panorama', active:true, scope:'All 10 Ministry Areas · Kisumu & Homa Bay' },
        governor_kisumu: { label:'Office of the Governor · County Government of Kisumu', active:true, scope:'Kisumu County (7 Ministry Areas · 5 Sub-Counties)' },
        governor_homabay:{ label:'Office of the Governor · County Government of Homa Bay', active:true, scope:'Homa Bay County (3 Ministry Areas · Referral Continuum)' },
        chmt_policy:     { label:'County Health Management Teams (CHMT) & Health Policy / Program Committees', active:true, scope:'Community-to-Facility Continuum, Nutrition & 30-Day PDCA' },
        moh_national:    { label:'Ministry of Health Kenya (MOH / NASCOP / Division of Community Health)', active:true, scope:'National KAISF 2025–2030, Art. 43(1)(a) & KHIS Alignment' }
      };
    }
    const seats = DB.db.settings.govAuthoritySeats;
    const isNationalViewer = ['president','director','chief','program.admin','program.assistant','me','intldata'].includes(user.roleId) || user.username==='gov.national';
    const countyFocus = params.county || (isNationalViewer ? 'all' : (user.countyId || 'all'));
    const defaultLens = user.roleId==='president' ? 'presidential'
      : (user.username==='gov.national' ? 'moh' : (isNationalViewer ? 'presidential' : 'governor'));
    const lens = params.lens || defaultLens;
    const canAdminGov = RBAC.has(user,'system.config') || RBAC.has(user,'user.approve') || ['chief','director','program.admin','president'].includes(user.roleId);
    const partnerPortalEnabled = !(DB.db && DB.db.settings && DB.db.settings.partnerPortalDisabled);

    /* Compute live de-identified aggregate metrics across all 10 Ministry Areas */
    const allPts = (DB.db.patients || []).filter(p => countyFocus==='all' || p.countyId===countyFocus);
    const allAreas = COUNTIES.filter(c => countyFocus==='all' || c.id===countyFocus)
      .flatMap(c => c.areas.map(a => ({ ...a, countyId:c.id, countyName:c.name })));
    const areaMatrix = allAreas.map(a => {
      const aps = allPts.filter(p => p.areaId === a.id);
      const act = aps.filter(p => p.status==='active' || p.status==='extension').length;
      const dis = aps.filter(p => p.status==='discharged' || p.status==='discharge_recommended').length;
      const childN = aps.filter(p => p.age < 18).length;
      const orphansProtected = aps.reduce((s, p) => s + Number(p.childrenCount || p.household?.children || 0), 0);
      const visitsTotal = aps.reduce((s, p) => s + (DB.visitsFor ? DB.visitsFor(p.id).length : 12), 0);
      return { area:a.name, county:a.countyName, total:aps.length, active:act, graduated:dis, children:childN, orphansProtected, visitsTotal };
    });
    const totalProtectedKids = areaMatrix.reduce((s, r) => s + r.orphansProtected, 0);
    const totalLongitudinalVisits = areaMatrix.reduce((s, r) => s + r.visitsTotal, 0);

    const subCountyRows = [
      { subCounty:'Kisumu Central', county:'Kisumu', areas:'Nyalenda, Nairobi Road / Milimani corridor', facilities:'JOOTRH, Kisumu County Referral Hospital (KCRH), Lumumba Sub-County Hospital', chmtLead:'Sub-County MOH & CHMT Focal Desk', status:'Active Community-to-Facility Continuum' },
      { subCounty:'Kisumu East',    county:'Kisumu', areas:'Manyatta, Chiga, Kolwa East',                facilities:'Migosi Sub-County Hospital, Chiga Dispensary, Gita Sub-County Hospital', chmtLead:'Kisumu East CHMT & Nutrition Desk', status:'Active Community-to-Facility Continuum' },
      { subCounty:'Kisumu West',    county:'Kisumu', areas:'Nyahera, Kisian, Otonglo',                   facilities:'Chulaimbo County Hospital, Nyahera Sub-County Hospital, Ober Kamoth', chmtLead:'Kisumu West CHMT & Referral Desk', status:'Active Community-to-Facility Continuum' },
      { subCounty:'Nyando & Muhoroni', county:'Kisumu', areas:'Ahero, Ombeyi corridor',                  facilities:'Ahero County Hospital, Ombeyi Health Centre, Rabuor Sub-County Hospital', chmtLead:'Nyando / Muhoroni CHMT Desk', status:'Active Community-to-Facility Continuum' },
      { subCounty:'Homa Bay Town & Ndhiwa', county:'Homa Bay', areas:'Makongeni, Shauri Yako, Sofia',    facilities:'Homa Bay County Teaching & Referral Hospital, Marindi Sub-County Hospital', chmtLead:'Homa Bay CHMT & OVC Health Committee', status:'Active Community-to-Facility Continuum' }
    ].filter(r => countyFocus==='all' || r.county.toLowerCase().replace(/\s+/g,'')===countyFocus);

    const impactIndicators = [
      { indicator:'Healthy Programme Graduations (2018–2026)', verified:'2,012 patients', liveScope:`${num(allPts.length)} longitudinal files in scope`, alignment:'Constitution of Kenya Art. 43(1)(a) — Right to Health' },
      { indicator:'Orphans Prevented Through Parental Recovery', verified:'3,722+ children', liveScope:`${num(totalProtectedKids)} children safeguarded in active cohort`, alignment:'National OVC Protection & Household Stability Priority' },
      { indicator:'Longitudinal Home, Hospital & Respite Visits', verified:num(totalLongitudinalVisits)+' visits', liveScope:'12–15 structured visits per beneficiary', alignment:'Kenya Community Health Strategy (CHS) Continuum' },
      { indicator:'Household Nutritional Foodbags Delivered', verified:'29,010 foodbags', liveScope:'Bag 1, Bag 2 & Special Paediatric Therapeutic Bags', alignment:'KAISF 2025–2030 Nutrition & ART/TB Adherence Pillar' },
      { indicator:'Verified Clinical & Nutritional Recovery Rate', verified:'89% recovery', liveScope:'WHO BMI-for-Age & Paediatric MUAC Surveillance', alignment:'Hospital Readmission & Bed-Decongestion Impact' },
      { indicator:'WASH Hygiene Packs, Bedding & LLIN Nets', verified:'1,336 packs · 216 LLINs', liveScope:'Quarterly household preventive infection control', alignment:'County Malaria & WASH Disease Prevention' }
    ];

    const lensTabs = [
      ['presidential', '1. Presidential & All-Areas Panorama'],
      ['governor',     '2. Governor & County Executive Briefing'],
      ['chmt',         '3. CHMT & Health Policy / Program Committees'],
      ['moh',          '4. Ministry of Health (MOH / NASCOP / KHIS)'],
      ...(canAdminGov ? [['admin', '5. Admin Viewer Authority & Seat Activation']] : [])
    ];

    let lensBody = '';
    if(lens === 'presidential'){
      lensBody = `<div class="grid g2" style="margin-bottom:16px">
          ${card('All-Areas Ministry Panorama (Kisumu & Homa Bay)', table([
            { label:'Ministry Area', render:r=>`<b>${esc(r.area)}</b><div class="xs muted">${esc(r.county)} County</div>` },
            { label:'Registered Cohort', cls:'num mono', render:r=>`<b>${num(r.total)}</b>` },
            { label:'Active / Extension', cls:'num mono', render:r=>num(r.active) },
            { label:'Paediatric (<18y)', cls:'num mono', render:r=>num(r.children) },
            { label:'Children Protected', cls:'num mono', render:r=>`<b style="color:var(--ok)">${num(r.orphansProtected)}</b>` },
            { label:'Longitudinal Visits', cls:'num mono', render:r=>num(r.visitsTotal) }
          ], areaMatrix), { sub:'Complete de-identified cross-area operational standing across all ten LOMAMO ministry catchments.' })}
          <div class="col" style="gap:16px">
            ${card('Cohort Distribution by County Office', chartDonut(COUNTIES.map(c => ({
              label: c.name,
              value: (DB.db.patients||[]).filter(p=>p.countyId===c.id).length,
              color: c.id==='kisumu' ? '#0284C7' : '#0D9488'
            })), { centerLabel:'Beneficiaries' }), { sub:'Balanced regional footprint across Lake Region partner counties.' })}
            ${card('Executive & Presidential Assurance Highlights', `<div class="col" style="gap:8px">
              <div class="spread small"><span>Longitudinal Care Standard</span><b>100% ≥12 visits per patient</b></div>
              <div class="spread small"><span>Child Anthropometry Standard</span><b>WHO BMI-for-Age + MUAC</b></div>
              <div class="spread small"><span>Public Hospital Linkages</span><b>13+ County &amp; Referral Facilities</b></div>
              <div class="spread small"><span>Data Protection Compliance</span>${badge('Zero-PII Verified','b-ok','nodot')}</div>
            </div>`)}
          </div>
        </div>`;
    } else if(lens === 'governor'){
      lensBody = `<div class="grid g2" style="margin-bottom:16px">
          ${card('Office of the Governor — Sub-County Health System Relief Brief', `
            <p class="small" style="margin-top:0">LOMAMO Foundation partners directly with County Departments of Medical Services, Public Health &amp; Sanitation in <b>Kisumu</b> and <b>Homa Bay</b> to stabilise vulnerable post-discharge households — reducing avoidable inpatient readmissions while supporting recovery, household nutrition and family care.</p>
            <div class="grid g2" style="gap:10px;margin-top:10px">
              <div class="exec-pane"><b>Hospital Decongestion</b><p class="xs muted" style="margin:4px 0 0">Structured bi-weekly home nursing &amp; nutrition follow-up after JOOTRH, KCRH and Homa Bay Referral discharge prevents acute relapse.</p></div>
              <div class="exec-pane"><b>Orphan Prevention</b><p class="xs muted" style="margin:4px 0 0">${num(totalProtectedKids)} dependent children in the current register remain under parental care through household recovery.</p></div>
              <div class="exec-pane"><b>SHA &amp; Indigent Linkage</b><p class="xs muted" style="margin:4px 0 0">Caregivers &amp; Hospital Focal Persons verify Social Health Authority (SHA) registration alongside targeted safety-net support.</p></div>
              <div class="exec-pane"><b>Zero Fiscal Duplication</b><p class="xs muted" style="margin:4px 0 0">Complementing County CHPs and sub-county hospitals with transparent quarterly CHMT reporting.</p></div>
            </div>
          `, { sub:'Formatted for County Governors, CECs for Health & County Executive briefings.' })}
          ${card('Sub-County Coverage & Public Hospital Corridors', table([
            { label:'Sub-County', render:r=>`<b>${esc(r.subCounty)}</b><div class="xs muted">${esc(r.county)} County</div>` },
            { label:'Ministry Catchments', render:r=>`<span class="small">${esc(r.areas)}</span>` },
            { label:'Partner Government Facilities', render:r=>`<span class="xs">${esc(r.facilities)}</span>` },
            { label:'Standing', render:r=>badge('Active','b-ok','nodot') }
          ], subCountyRows))}
        </div>`;
    } else if(lens === 'chmt'){
      const childPts = allPts.filter(p => p.age < 18);
      lensBody = `<div class="grid g2" style="margin-bottom:16px">
          ${card('CHMT & Health Policy / Program Committee Technical Matrix', table([
            { label:'Technical Domain', render:r=>`<b>${esc(r.domain)}</b>` },
            { label:'Protocol & Cadence', render:r=>`<span class="small">${esc(r.protocol)}</span>` },
            { label:'Current Standing', render:r=>badge(r.standing, 'b-ok', 'nodot') }
          ], [
            { domain:'Community-to-Facility Referral Loop', protocol:'Two-way Master Referral & CCC Feedback Desk across 13+ public hospitals', standing:`${num((DB.db.requests||[]).length)} tracked referrals` },
            { domain:'Paediatric IMAM & Growth Surveillance', protocol:'WHO BMI-for-Age + Kenya MoH MUAC tape (<11.5cm SAM, 11.5–12.4cm MAM)', standing:`${num(childPts.length)} children monitored` },
            { domain:'30-Day PDCA & 120+ Day Specialist Review', protocol:'Mandatory 30-day Plan-Do-Check-Act cycle + International Medical concurrence >120d', standing:'100% active cohort covered' },
            { domain:'Therapeutic Nutrition & Adherence Support', protocol:'Bag 1, Bag 2 (large household) & Special Therapeutic Diet Bag (SAM/MAM)', standing:'Weekly verified dispatch' },
            { domain:'Hard-Copy Source & Audit Integrity', protocol:'Signed intake/discharge forms archived + SHA-256 hash-chained audit trail', standing:'Audit-ready' }
          ]), { sub:'Technical quality indicators for County Health Management Teams & Health Policy Committees.' })}
          ${card('Sub-County CHMT Focal Coordination', table([
            { label:'Sub-County', render:r=>`<b>${esc(r.subCounty)}</b>` },
            { label:'CHMT Coordination Desk', render:r=>`<span class="small">${esc(r.chmtLead)}</span>` },
            { label:'Continuum Status', render:r=>badge(r.status,'b-info','nodot') }
          ], subCountyRows))}
        </div>`;
    } else if(lens === 'moh'){
      lensBody = card('Ministry of Health Kenya (MOH / NASCOP / KHIS) Strategic Indicator Alignment', table([
        { label:'National / County Indicator', render:r=>`<b>${esc(r.indicator)}</b>` },
        { label:'Cumulative Verified Output', cls:'mono', render:r=>`<b>${esc(r.verified)}</b>` },
        { label:'Live CareLink Cohort Scope', render:r=>`<span class="small">${esc(r.liveScope)}</span>` },
        { label:'Policy & KHIS Framework Alignment', render:r=>`<span class="xs muted">${esc(r.alignment)}</span>` }
      ], impactIndicators), { sub:'Prepared for National Ministry of Health, NASCOP, Division of Community Health & quarterly KHIS/DHIS2 review.' });
    } else if(lens === 'admin' && canAdminGov){
      lensBody = card('System Administrator — Government & Presidential Viewer Seat Governance', `
        <p class="small" style="margin-top:0">Configure which structured external &amp; executive presentation desks are active, and manage the Private Partner Portal layer for Governors, CHMTs, Health Policy &amp; Program Committees and National MOH officers.</p>
        ${table([
          { label:'Official Viewer Desk / Authority Level', render:([k, s])=>`<b>${esc(s.label)}</b>` },
          { label:'Authorised Geographic & Policy Scope', render:([k, s])=>`<span class="small">${esc(s.scope)}</span>` },
          { label:'Status', render:([k, s])=>s.active ? badge('Active & Governed','b-ok') : badge('Paused','b-warn') },
          { label:'Action', cls:'act', render:([k, s])=>`<button class="btn btn-xs ${s.active?'btn-ghost':'btn-primary'}" data-act="gov-toggle-seat" data-seat="${esc(k)}">${s.active?'Pause Desk':'Activate Desk'}</button>` }
        ], Object.entries(seats))}
        <div class="row" style="gap:10px;margin-top:14px;flex-wrap:wrap">
          <button class="btn btn-sm btn-ghost" data-act="gov-toggle-partner-portal">${ic('settings',14)} ${partnerPortalEnabled?'Pause Private Partner Portal Layer':'Enable Private Partner Portal Layer'}</button>
          <span class="xs muted">All Government &amp; Presidential views enforce hardware-level Zero-PII stripping under the Kenya Data Protection Act (2019).</span>
        </div>
      `);
    }

    return pageHead('Presidential, County Government & Ministry of Health Presentation Hub',
      'Official zero-PII institutional presentation console for the LOMAMO Presidency, County Governors, County Health Management Teams (CHMT), Health Policy & Program Committees and the Ministry of Health Kenya.',
      `<div class="row" style="gap:8px;flex-wrap:wrap">
        ${isNationalViewer ? `<select class="input" style="width:auto;height:34px;font-size:12.5px" onchange="go('govdashboard',{lens:'${esc(lens)}',county:this.value})">
          <option value="all" ${countyFocus==='all'?'selected':''}>Scope: All Counties &amp; All 10 Areas</option>
          ${COUNTIES.map(c=>`<option value="${c.id}" ${countyFocus===c.id?'selected':''}>Scope: ${esc(c.name)} County</option>`).join('')}
        </select>` : ''}
        <button class="btn btn-sm btn-ghost" data-act="portal-mode" data-mode="public">${ic('eye',15)} Public Portal</button>
        <button class="btn btn-sm btn-primary" data-act="portal-mode" data-mode="partner">${ic('shieldcheck',15)} Partner Briefing View</button>
      </div>`)
    + `<div class="coins-hero-crest" style="margin-bottom:14px">
        <div>
          <div class="xs mono" style="color:#F5C451;letter-spacing:.08em;text-transform:uppercase;font-weight:800">Kenya Data Protection Act (2019) · Art. 43(1)(a) · KAISF 2025–2030</div>
          <h3 style="color:#FFFFFF;margin:4px 0;font-size:18px">Official Multi-Authority Health Partnership &amp; All-Areas Impact Presentation</h3>
          <p class="xs" style="color:#CBD5E1;margin:0;max-width:74ch">Tailored presentation lenses for the Foundation President, County Governors, CHMTs, Health Policy Committees and National MOH — backed by ${num(allPts.length)} de-identified longitudinal care records and ${num(totalLongitudinalVisits)} verified visits.</p>
        </div>
        <div class="coins-wallet-pill">
          <span class="xs" style="color:#FDE68A">Active Scope</span>
          <b style="font-size:19px;color:#FFFFFF">${countyFocus==='all'?'All 10 Areas':countyName(countyFocus)}</b>
          <span class="xs" style="color:#93C5FD">Zero-PII Enforced</span>
        </div>
      </div>`
    + `<div class="grid g4" style="margin-bottom:14px">
        ${kpi('Healthy Graduations', '2,012', '89% verified recovery rate (2018–2026)', 'ok', 'check')}
        ${kpi('Orphans Prevented', '3,722', `${num(totalProtectedKids)} children protected in active register`, 'ok', 'heart')}
        ${kpi('Longitudinal Visits', num(totalLongitudinalVisits), 'Home, Hospital & Homestay care continuum', 'info', 'activity')}
        ${kpi('Public Hospitals Linked', '13+ Facilities', 'Kisumu & Homa Bay referral corridors', 'info', 'hospital')}
      </div>`
    + `<div class="tabs" style="margin-bottom:14px">
        ${lensTabs.map(([k, lbl])=>`<button class="tab ${lens===k?'active':''}" data-act="go" data-v="govdashboard" data-lens="${k}" data-county="${esc(countyFocus)}">${esc(lbl)}</button>`).join('')}
      </div>`
    + lensBody
    + card('Verified 2018–2026 Health-System Partnership Summary', table([
        {label:'Programme Indicator', render:r=>`<b>${esc(r.indicator)}</b>`},
        {label:'Verified Output', cls:'mono', render:r=>`<b>${esc(r.verified)}</b>`},
        {label:'Live Cohort Standing', render:r=>`<span class="small">${esc(r.liveScope)}</span>`},
        {label:'Constitutional & MOH Alignment', render:r=>`<span class="xs muted">${esc(r.alignment)}</span>`}
      ], impactIndicators));
  },

  /* =====================================================================
     4. INTERNATIONAL MEDICAL TEAM & 120+ DAY PDCA OVERSTAY CONSOLE
     ===================================================================== */
  renderIntlMedical(user,params={}){return CARE_REVIEW.internationalPanel(user,params);}

};

function _hpAddDays(isoDate, n){
  const d = new Date(isoDate+'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0,10);
}

Object.assign(ACTIONS, {
  'handover-new-modal': (d={}) => {
    const kind = d.kind === 'role_takeover' ? 'role_takeover' : 'leave_delegation';
    const colleagues = (DB.db.users||[]).filter(u=>u.active && u.id!==AUTH.user.id && (!AUTH.user.countyId || isGlobal(AUTH.user) || u.countyId===AUTH.user.countyId));
    const today = todayISO().slice(0,10);
    openModal({
      title: kind==='role_takeover' ? 'New Permanent / Transition Role Handover & Acceptance Report' : 'New Leave Delegation Plan & Scoped Reliever Console Grant',
      sub: kind==='role_takeover' ? 'Tri-party custody & deliverable transfer protocol.' : 'EPPH v2.2 >=14-day advance notice rule with per-patient reliever action table.',
      wide: true,
      body:`<form id="handoverNewForm">
        <input type="hidden" name="kind" value="${esc(kind)}">
        <div class="grid g2">
          <div class="field"><label>${kind==='role_takeover'?'Incoming Officer':'Designated Reliever (receives scoped console access)'} *</label>
            <select class="input" name="relieverUsername" required>
              ${colleagues.map(u=>`<option value="${esc(u.username)}">${esc(u.name.replace(/^Demo - /,''))} (${esc((roleObj(u.roleId)||{}).name||u.roleId)})</option>`).join('')}
            </select>
          </div>
          <div class="field"><label>Leave / Handover category *</label>
            <input class="input" name="leaveType" value="${kind==='role_takeover'?'Departmental Role Transition & Acceptance':'Annual Leave (>=14 days advance notice)'}" required>
          </div>
        </div>
        <div class="grid g3">
          <div class="field"><label>Effective from *</label><input class="input" type="date" name="fromDate" value="${esc(_hpAddDays(today,14))}" required></div>
          <div class="field"><label>Effective to *</label><input class="input" type="date" name="toDate" value="${esc(_hpAddDays(today,24))}" required></div>
          <div class="field"><label>Advance notice (days)</label><input class="input" type="number" min="0" name="noticeDays" value="14"></div>
        </div>
        <div class="field"><label>PPE, Field Tablet, Keys & Register Custody Handover *</label>
          <input class="input" name="ppeCustody" value="Field Tablet, Weighing Scale, Home Visit Folder & Keys verified" required>
        </div>
        <div class="field"><label>${kind==='role_takeover'?'Pending Deliverables, Files & Financial/Stock Clearance *':'Caseload / Departmental Priority Actions for Reliever *'}</label>
          <textarea class="input" name="deliverables" rows="3" required placeholder="List patients due for 3rd-visit weigh-in, hospital clinic reviews, foodbag codes, or pending departmental tasks..."></textarea>
        </div>
      </form>`,
      footer:`<button class="btn btn-ghost" data-act="close-modal">Cancel</button>
        <button class="btn btn-primary" data-act="handover-new-save">${ic('check',14)} Sign & Route to Reliever & Supervisor</button>`
    });
  },

  'handover-new-save': () => {
    const f = document.querySelector('#handoverNewForm');
    if(!f) return;
    const fd = new FormData(f);
    const deliv = String(fd.get('deliverables')||'').trim();
    if(!deliv) return toast('Handover details required','','err');
    const rel = (DB.db.users||[]).find(u=>u.username===fd.get('relieverUsername'));
    HANDOVER_PARTNERS.ensureStore();
    const kind = fd.get('kind');
    const pkt = {
      id: (kind==='role_takeover'?'HND-2026-':'DEL-2026-') + String(10 + DB.db.handoverPackets.length),
      kind,
      staffName: AUTH.user.name.replace(/^Demo - /,''),
      staffRole: (roleObj(AUTH.user.roleId)||{}).name || AUTH.user.roleId,
      countyId: AUTH.user.countyId || 'kisumu',
      areaId: (AUTH.user.areaIds&&AUTH.user.areaIds[0]) || '',
      leaveType: String(fd.get('leaveType')||'Annual Leave'),
      fromDate: fd.get('fromDate') || todayISO().slice(0,10),
      toDate: fd.get('toDate') || todayISO().slice(0,10),
      noticeDays: Number(fd.get('noticeDays')||14),
      relieverUsername: rel ? rel.username : '',
      relieverName: rel ? rel.name.replace(/^Demo - /,'') : 'Assigned Reliever',
      scopedConsoleGranted: false,
      ppeCustody: String(fd.get('ppeCustody')||'Verified'),
      deliverables: deliv,
      patientHandoverRows: kind==='leave_delegation' ? [{ code:'Caseload Action Plan', schedule:'Per weekly roster', bag:'BG1/BG2', action:deliv }] : [],
      outgoingSigned: true,
      relieverAccepted: false,
      supervisorApproved: false,
      status: 'pending_acceptance'
    };
    DB.db.handoverPackets.unshift(pkt);
    if(rel) notify(rel.id, 'Delegation / Handover Acceptance Requested', `${pkt.staffName} routed ${pkt.id} to you for acceptance.`, 'info');
    AUDIT.append({ actor:AUTH.user.id, action:'handover.created', entity:'handover', entityId:pkt.id, detail:`${pkt.kind} -> ${pkt.relieverName}` });
    DB.save();
    closeModal(true);
    toast('Handover packet filed', `${pkt.id} routed to ${pkt.relieverName} for acceptance.`, 'ok');
    render();
  },

  'handover-accept': (d={}) => {
    HANDOVER_PARTNERS.ensureStore();
    const pkt = (DB.db.handoverPackets||[]).find(x=>x.id===d.id);
    if(!pkt) return;
    pkt.relieverAccepted = true;
    pkt.supervisorApproved = true;
    pkt.scopedConsoleGranted = true;
    pkt.status = pkt.kind==='role_takeover' ? 'accepted_closed' : 'active_reliever';
    AUDIT.append({ actor:AUTH.user.id, action:'handover.accepted', entity:'handover', entityId:pkt.id, detail:`Reliever acceptance & scoped console grant activated` });
    DB.save();
    toast('Handover accepted & scoped access active', `${pkt.id} is now active with full audit attribution.`, 'ok');
    render();
  },

  'ccc-new-referral-modal': () => {
    const areas = COUNTIES.filter(c=>isGlobal(AUTH.user)||!AUTH.user.countyId||c.id===AUTH.user.countyId).flatMap(c=>c.areas.map(a=>({...a,countyId:c.id})));
    openModal({
      title:'Submit CCC / PSC Hospital Patient Referral to LOMAMO',
      sub:'Routes directly to the County Admin Assistant & target Ministry Area Coordinator.',
      wide:true,
      body:`<form id="cccRefForm">
        <div class="grid g3">
          <div class="field"><label>Referring Hospital / CCC / PSC Desk *</label>
            <input class="input" name="facilityName" list="referral-partners" value="${esc(AUTH.user.facilityName||'')}" required><datalist id="referral-partners">${REFERRAL_PARTNERS.map(n=>`<option value="${esc(n)}"></option>`).join('')}</datalist>
          </div>
          <div class="field"><label>Patient name / initials *</label>
            <input class="input" name="patientInitials" placeholder="e.g. Beneficiary K.O." required>
          </div>
          <div class="field"><label>CCC / Clinic Number *</label>
            <input class="input" name="cccNumber" value="" required>
          </div>
        </div>
        <div class="grid g3">
          <div class="field"><label>Target residential Ministry Area *</label>
            <select class="input" name="areaId" required>
              ${areas.map(a=>`<option value="${esc(a.id)}">${esc(a.name)} (${esc(countyName(a.countyId))})</option>`).join('')}
            </select>
          </div>
          <div class="field"><label>Current Weight (kg) *</label><input class="input" type="number" step="0.1" name="weightKg" value="" required></div>
          <div class="field"><label>Height (cm) *</label><input class="input" type="number" step="0.5" name="heightCm" value="" required></div>
        </div>
        <div class="field"><label>Select patient clinical & household support needs *</label>
          <div class="checkgrid">
            ${CCC_NEED_OPTIONS.map((n,i)=>`<label class="check"><input type="checkbox" name="needs" value="${esc(n)}" > ${esc(n)}</label>`).join('')}
          </div>
        </div>
        <div class="field"><label>Clinical summary, regimen & home follow-up notes *</label>
          <textarea class="input" name="clinicalNotes" rows="3" required placeholder="Diagnosis, current ART/TB/chronic regimen, next clinic review date, and household vulnerability notes..."></textarea>
        </div>
      </form>`,
      footer:`<button class="btn btn-ghost" data-act="close-modal">Cancel</button>
        <button class="btn btn-primary" data-act="ccc-new-referral-save">${ic('send',14)} Transmit Referral to County Admin Assistant</button>`
    });
  },

  'ccc-new-referral-save': () => {
    const f = document.querySelector('#cccRefForm');
    if(!f) return;
    const fd = new FormData(f);
    const notes = String(fd.get('clinicalNotes')||'').trim();
    const patName = String(fd.get('patientInitials')||'').trim();
    if(!f.reportValidity())return;
    if(!patName || !notes) return toast('Patient & clinical notes required','','err');
    const needs = fd.getAll ? fd.getAll('needs') : [CCC_NEED_OPTIONS[0]];
    const areaId = fd.get('areaId') || 'nyalenda';
    const countyObj = COUNTIES.find(c=>c.areas.some(a=>a.id===areaId)) || COUNTIES[0];
    const bmi = typeof BMI_CLINICAL!=='undefined'?BMI_CLINICAL.compute(fd.get('weightKg'),fd.get('heightCm')):null;
    const cccNo=String(fd.get('cccNumber')||'').trim();
    HANDOVER_PARTNERS.ensureStore();
    const ref = {
      id: uid('CCC-REF'),
      facilityName: String(fd.get('facilityName')||'Partner CCC Desk').trim(),
      referredByUsername: AUTH.user.username,
      referredByClinician: AUTH.user.name,
      countyId: countyObj.id,
      areaId,
      patientInitials: patName,
      cccNumber: cccNo,
      referralDate: todayISO().slice(0,10),
      bmiAtReferral: bmi,
      needs: needs.length ? needs : [CCC_NEED_OPTIONS[0]],
      clinicalNotes: notes,
      status: 'awaiting_assessment',
      lomamoCode: 'Queued for Hard-Copy Assessment',
      masterReportSummary: '',
      feedbackThread: [{ by:AUTH.user.name, role:'Referring Clinician', at:todayISO().slice(0,10), msg:'Referral submitted via CareLink CCC Desk.' }]
    };
    DB.db.cccReferrals.unshift(ref);
    (DB.db.users||[]).filter(u=>u.active && u.countyId===countyObj.id && ['assistant','countyadmin','mcm'].includes(u.roleId))
      .forEach(u=>notify(u.id, `New CCC Facility Referral · ${ref.id}`, `${ref.facilityName} referred ${patName} (${areaName(areaId)}, BMI ${bmi}).`, 'info'));
    AUDIT.append({ actor:AUTH.user.id, action:'ccc.referral.submitted', entity:'ccc_referral', entityId:ref.id, detail:`${ref.facilityName} -> ${areaName(areaId)}` });
    DB.save();
    closeModal(true);
    toast('Referral saved for synchronisation', `${ref.id} queued for ${countyName(countyObj.id)} County Admin Assistant & ${areaName(areaId)} team.`, 'ok');
    render();
  },

  'ccc-feedback-modal': (d={}) => {
    HANDOVER_PARTNERS.ensureStore();
    const r = (DB.db.cccReferrals||[]).find(x=>x.id===d.id);
    if(!r) return;
    openModal({
      title:`CCC <-> CareLink Feedback Thread · ${r.id}`,
      sub:`${r.patientInitials} (${r.cccNumber}) · ${r.facilityName} <-> ${areaName(r.areaId)}`,
      wide:false,
      body:`<div>
        <div class="note" style="margin-bottom:10px">${ic('file',14)}<span><b>Master Referral Summary:</b> ${esc(r.masterReportSummary)}</span></div>
        <div class="col" style="gap:8px;max-height:220px;overflow-y:auto;margin-bottom:12px">
          ${(r.feedbackThread||[]).map(m=>`<div style="padding:8px 10px;border-radius:8px;background:var(--surface-2);border:1px solid var(--line)">
            <div class="xs muted"><b>${esc(m.by)}</b> (${esc(m.role)}) · ${esc(m.at)}</div>
            <div class="small" style="margin-top:2px">${esc(m.msg)}</div>
          </div>`).join('') || `<div class="xs muted">No feedback messages yet.</div>`}
        </div>
        <form id="cccFbForm">
          <input type="hidden" name="id" value="${esc(r.id)}">
          <div class="field"><label>Send feedback to County Admin Assistant, Caregiver & Referring Clinician *</label>
            <textarea class="input" name="msg" rows="2" required placeholder="Share appointment feedback, lab/viral-load readiness, or home adherence update..."></textarea>
          </div>
        </form>
      </div>`,
      footer:`<button class="btn btn-ghost" data-act="close-modal">Close</button>
        <button class="btn btn-primary" data-act="ccc-feedback-save">${ic('send',14)} Send Feedback</button>`
    });
  },

  'ccc-feedback-save': () => {
    const f = document.querySelector('#cccFbForm');
    if(!f) return;
    const fd = new FormData(f);
    const msg = String(fd.get('msg')||'').trim();
    if(!msg) return toast('Message required','','err');
    const r = (DB.db.cccReferrals||[]).find(x=>x.id===fd.get('id'));
    if(!r) return;
    r.feedbackThread = r.feedbackThread || [];
    r.feedbackThread.push({ by:AUTH.user.name.replace(/^Demo - /,''), role:(roleObj(AUTH.user.roleId)||{}).name||'Care Team', at:todayISO().slice(0,10), msg });
    AUDIT.append({ actor:AUTH.user.id, action:'ccc.feedback.sent', entity:'ccc_referral', entityId:r.id, detail:msg.slice(0,80) });
    DB.save();
    closeModal(true);
    toast('Feedback delivered', 'Shared across CCC Desk, County Admin Assistant & Caregiver.', 'ok');
    render();
  },

  'gov-toggle-partner-portal': () => {
    DB.db.settings = DB.db.settings || {};
    DB.db.settings.partnerPortalDisabled = !DB.db.settings.partnerPortalDisabled;
    AUDIT.append({ actor:AUTH.user.id, action:'portal.partner_mode.toggled', entity:'portal', entityId:'partner_mode', detail:DB.db.settings.partnerPortalDisabled?'paused':'enabled' });
    DB.save();
    toast('Partner portal governance updated', DB.db.settings.partnerPortalDisabled ? 'Private Partner layer paused.' : 'Private Partner layer active for authorised accounts.', 'ok');
    render();
  },

  'gov-toggle-seat': (d={}) => {
    DB.db.settings = DB.db.settings || {};
    const seats = DB.db.settings.govAuthoritySeats || {};
    const s = seats[d.seat];
    if(!s) return;
    s.active = !s.active;
    AUDIT.append({ actor:AUTH.user.id, action:'gov.authority_seat.toggled', entity:'gov_seat', entityId:d.seat, detail:`${s.label} -> ${s.active?'active':'paused'}` });
    DB.save();
    toast('Viewer authority desk updated', `${s.label} is now ${s.active ? 'active' : 'paused'}.`, 'ok');
    render();
  },

  'intl-file-pdca120': (d={}) => {
    const p=CARE_REVIEW.scoped(AUTH.user,d.id);
    if(!p)return toast('Not available','Outside your clinical scope.','err');
    toast('Review chain required','Open a 120+ report, record MCM comments, obtain caregiver corrections / resubmission, then authorize and share that exact revision. Nothing was transmitted.','info');
    go('patient',{id:p.id,tab:'pdca'});
  },
  'intl-review-modal':d=>CARE_REVIEW.internationalReview(d.id),
  'intl-review-save':()=>CARE_REVIEW.submitForm('intlRevForm','international_review',d=>({id:d.get('id'),version:Number(d.get('version')),decision:d.get('decision'),recommendation:d.get('recommendation')}))
});

/* Explicit server-confirmed committee contributions and facility reports. */
function executiveCommitteePanel(user){
  refreshCoordinationPresence();
  const members=(DB.db.users||[]).filter(u=>u.status==='active'&&u.active!==false&&isExecutive(u));
  const issues=DB.db.execIssues||[];
  return card('Director’s Executive Committee Panel',`
    <p class="small muted">Discuss operational issues, share contributions and record the Director’s resolutions. Oversight decisions remain separate from clinical and financial authorisation.</p>
    <div class="row" style="gap:8px;flex-wrap:wrap;margin:14px 0">${members.map(u=>`<span class="chip">${esc(u.name)} · ${typeof presenceOf==='function'?esc(presenceOf(u.id).label):'Presence unavailable'}</span>`).join('')||'No active members are assigned.'}</div>
    <button class="btn btn-primary btn-sm" data-act="coordination-open" data-kind="exec.issue">Raise committee issue</button>
    <div class="col" style="gap:14px;margin-top:16px">${issues.slice().reverse().map(issue=>`<article class="card"><div class="card-b"><h4>${esc(issue.title)}</h4><p class="small muted">${esc(issue.status)} · ${esc(userName(issue.by))} · ${esc(issue.at)}</p>
      ${(issue.discussion||[]).map(note=>`<div class="note"><span><b>${esc(userName(note.by))}</b> · ${esc(note.at)}<br>${esc(note.text)}</span></div>`).join('')}
      ${issue.resolution?`<div class="alert ok"><div><b>Recorded resolution</b><p>${esc(issue.resolution.text)}</p><span>${esc(userName(issue.resolution.by))} · ${esc(issue.resolution.at)}</span></div></div>`:`<div class="row" style="gap:8px"><button class="btn btn-sm btn-ghost" data-act="coordination-open" data-kind="exec.reply" data-id="${esc(issue.id)}">Contribute</button>${['director','chief','program.admin'].includes(user.roleId)?`<button class="btn btn-sm btn-primary" data-act="coordination-open" data-kind="exec.resolve" data-id="${esc(issue.id)}">Record resolution</button>`:''}</div>`}
    </div></article>`).join('')||'<p class="small muted">No committee issues have been raised.</p>'}</div>`);
}
const COORDINATION_UI={busy:false};
Object.assign(ACTIONS,{
  'coordination-open':d=>{
    const titles={'exec.issue':'Raise executive committee issue','exec.reply':'Contribute to deliberation','exec.resolve':'Record committee resolution','referral.report':'Submit Master Referral progress report'};
    if(!titles[d.kind])return;
    openModal({title:titles[d.kind],sub:d.kind==='referral.report'?'Saved to the referring account’s CareLink desk. No email or external delivery is implied.':'Attributed to your own account; confirmed by the shared server.',wide:true,
      body:`<form data-form="coordination-submit"><input type="hidden" name="kind" value="${esc(d.kind)}"><input type="hidden" name="id" value="${esc(d.id||'')}"><input type="hidden" name="commandId" value="${esc(uid('coord'))}">
        ${d.kind==='exec.issue'?'<div class="field"><label>Issue title<input class="input" name="title" maxlength="160" required></label></div>':''}
        <div class="field"><label>${d.kind==='referral.report'?'Progress, support provided, outstanding needs and next review':'Contribution / resolution'}<textarea class="input" name="text" rows="7" maxlength="5000" required></textarea></label></div>
        <p class="small muted">Include only information needed by this audience. Do not enter passwords or unrelated beneficiary details.</p>
        <button class="btn btn-primary" type="submit">Submit to shared workspace</button></form>`,footer:'<button class="btn btn-ghost" data-act="close-modal">Cancel</button>'});
  },
  'referral-report-print':d=>{
    const ref=(DB.db.cccReferrals||[]).find(r=>r.id===d.id);if(!ref)return;
    printDoc('Master Referral Report',`<h1>Master Referral Report</h1><p>${esc(ref.facilityName)} · ${esc(ref.id)} · ${esc(ref.cccNumber)}</p>${(ref.masterReports||[]).map(r=>`<section><h3>${esc(r.at)}</h3><p>${esc(r.text)}</p><p>Submitted by ${esc(userName(r.by))} · CareLink recipient: ${esc(r.recipient||'Referring desk')}</p></section>`).join('')||'<p>No submitted progress reports are recorded.</p>'}`);
  }
});
Object.assign(FORMS,{'coordination-submit':async fd=>{
  if(COORDINATION_UI.busy)return;
  if(!SYNC.available()||!SYNC.sessionToken)return toast('Online sign-in required','No contribution was marked as submitted. Keep this form open and reconnect.','warn');
  COORDINATION_UI.busy=true;
  try{
    const body={};for(const k of ['kind','id','commandId','title','text'])body[k]=String(fd.get(k)||'');
    const result=await SYNC._json('api/coordination/command',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    if(!result.ok)return toast('Not submitted',result.body?.error||'The shared server did not confirm this request. Retry the same form.','err');
    await SYNC.pullFull();closeModal(true);render();toast('Submission confirmed','Recorded in the shared CareLink workspace.','ok');
  }finally{COORDINATION_UI.busy=false;}
}});

function renderBoardWorkspace(user){
  if(!BOARD_ROLE_IDS.includes(user.roleId))return deniedPanel('gov.oversight');
  refreshCoordinationPresence();
  const summary=DB.db.oversightSummary||{};
  const peers=(DB.db.users||[]).filter(u=>BOARD_ROLE_IDS.includes(u.roleId)&&u.status==='active');
  return pageHead('Foundation Board & International Oversight','Shared oversight workspace · individual accounts · information limited to your assigned scope.')+
    card('Direction, oversight & accountability','<p>The Board provides organisational oversight and makes decisions about the Foundation’s direction. Founder / President / CEO and Co-Founder seats sit within Administration. International advisory, finance, legal and data functions receive individually assigned access; this workspace does not grant clinical editing or operational approval powers.</p>')+
    `<div class="grid g3">${kpi('Assigned counties',(summary.counties||[]).length,(summary.counties||[]).map(countyName).join(' · ')||'Awaiting scope assignment','info','map')}${kpi('Registered beneficiaries',summary.registered??'—','Aggregate only','info','users')}${kpi('Active beneficiaries',summary.active??'—','Aggregate only','ok','activity')}</div>`+
    card('Board & international colleagues',table([{label:'Member',render:u=>esc(u.name)},{label:'Office',render:u=>esc(roleObj(u.roleId)?.name||u.roleId)},{label:'Recent activity',render:u=>typeof presenceOf==='function'?esc(presenceOf(u.id).label):'Unavailable'}],peers))+
    '<p class="small muted">Recent activity is based on the latest shared presence timestamp, not a guarantee that a browser remains open. Every member uses a separate account. No locations or individual beneficiary records are displayed here.</p>';
}

let coordinationPresenceAt=0,coordinationPresenceTimer;
function refreshCoordinationPresence(){
  if(!SYNC.available()||!SYNC.sessionToken||Date.now()-coordinationPresenceAt<30000)return;
  coordinationPresenceAt=Date.now();
  SYNC._json('api/coordination/presence',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}).then(r=>{
    if(!r.ok)return;
    DB.db.presence=r.body.presence||{};
    if((['execconsole','boardworkspace'].includes(APPX.view)||APPX.view==='home'&&BOARD_ROLE_IDS.includes(AUTH.user?.roleId)))render();
  }).catch(()=>{});
  clearTimeout(coordinationPresenceTimer);
  coordinationPresenceTimer=setTimeout(()=>{if((['execconsole','boardworkspace'].includes(APPX.view)||APPX.view==='home'&&BOARD_ROLE_IDS.includes(AUTH.user?.roleId)))refreshCoordinationPresence();},45000);
}
