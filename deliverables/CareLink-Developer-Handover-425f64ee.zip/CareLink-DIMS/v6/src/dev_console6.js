/* ============================================================
   dev_console6.js — CareLink Development Console, Production
   First-Run SMS Credential Provisioning, DPA First-Login Privacy
   Password Enforcement & Audited Chief Admin Silent Override (v6.4)
   ============================================================ */

/* ---------------- 1. Production Setup & DPA Password Policy ---------------- */
const PROD_SETUP = {
  lastPack: null, /* One-time in-memory credential pack for immediate SMS/WhatsApp export; never stored in DB */
  lastWhatsappSheet: '',

  isGloballyActivated() {
    /* The host flag is authoritative for the online entry point.  Keep the
       local flags as a fail-closed backstop for offline/already-synchronised
       sessions, but never require a demo record to be present locally. */
    if (typeof APPX !== 'undefined' && APPX.host && (APPX.host.globallyActivated || APPX.host.demoDisabled)) return true;
    if (typeof SYNC !== 'undefined' && SYNC.server && (SYNC.server.globallyActivated || SYNC.server.demoDisabled)) return true;
    if (DB.db && DB.db.settings && DB.db.settings.globallyActivated) return true;
    if (DB.db && DB.db.meta && (DB.db.meta.globallyActivated || DB.db.meta.demoDisabled)) return true;
    return false;
  },

  isAwaitingGlobalActivation() {
    if (this.isGloballyActivated()) return false;
    return Boolean(DB.db && DB.db.settings && DB.db.settings.awaitingGlobalActivation);
  },

  defaultPortalUrl() {
    try {
      if (DB.db && DB.db.settings && DB.db.settings.org && DB.db.settings.org.loginUrl) return DB.db.settings.org.loginUrl;
      if (typeof location !== 'undefined' && location.origin && location.origin !== 'null') return location.origin;
    } catch (_e) {}
    return 'https://carelink.lomamo.org';
  },

  defaultEmailDomain() {
    const cfg = DB.db && DB.db.settings && DB.db.settings.org && DB.db.settings.org.emailDomain;
    return String(cfg || OFFICIAL_EMAIL_DOMAIN).replace(/^@+/, '').trim().toLowerCase() || OFFICIAL_EMAIL_DOMAIN;
  },

  ownsCredentialPack(actor = (typeof AUTH !== 'undefined' ? AUTH.user : null)) {
    const pack = this.lastPack;
    return Boolean(actor && actor.roleId === 'chief' && pack &&
      String(actor.username || '').toLowerCase() === String(pack.chiefUsername || '').toLowerCase());
  },

  requireCredentialPackAccess() {
    if (this.ownsCredentialPack()) return true;
    toast('Confidential credentials restricted', 'Only the Chief System Administrator who generated this pack may view, copy or export it.', 'err');
    return false;
  },

  clearCredentialPack() {
    this.lastPack = null;
    this.lastWhatsappSheet = '';
  },

  /* Step 4 completion of 4-Step Online Setup:
     Establishes system & global organogram structures, configures Chief System Admin
     with mandatory password change on Official Sign-In, and enables "Activate System Globally". */
  async completeFourStepHostSetup({ orgNameVal, orgName, shortNameVal, shortName, emailDomain, loginUrl, portalUrl, primaryCounty, chiefName, chiefUsername, chiefPassword, chiefTempPassword, seedMode }) {
    if(this.isGloballyActivated()) throw new Error('First-run setup is locked after global activation.');
    const hosted = typeof SYNC !== 'undefined' && SYNC.available && SYNC.available();
    if(hosted && seedMode !== 'empty'){
      throw new Error('Live Vercel setup must start with an empty patient register. After setup, use Master data import before global activation to upload the complete reference master in verified chunks; the full package exceeds Vercel\'s 4.5 MB Function request limit.');
    }
    const domain = OFFICIAL_EMAIL_DOMAIN;
    const portal = String(loginUrl || portalUrl || this.defaultPortalUrl()).trim();
    const chiefUser = String(chiefUsername || 'chief.admin').trim().toLowerCase();
    const chiefFull = String(chiefName || 'Chief System Administrator').trim();
    const effectivePw = chiefPassword || chiefTempPassword || 'TempSetup#2026!';
    const effectiveOrg = orgNameVal || orgName || 'LOMAMO Foundation Kenya';
    const effectiveShort = shortNameVal || shortName || 'LOMAMO';
    const previousRaw = JSON.stringify(DB.db || DB.blank());
    const previousHost = typeof APPX !== 'undefined' ? APPX.host : null;
    const previousServer = typeof SYNC !== 'undefined' ? SYNC.server : null;
    const previousDirty = typeof APPX !== 'undefined' ? APPX.dirty : false;
    const rollback = () => {
      try{ DB.db = JSON.parse(previousRaw); DB.migrate(); Store.set(DB.KEY, previousRaw); }catch(_e){}
      if(typeof APPX !== 'undefined'){ APPX.host = previousHost; APPX.dirty = previousDirty; }
      if(typeof SYNC !== 'undefined') SYNC.server = previousServer;
    };

    DB.reset();
    const now = new Date();
    seedOfficial(DB.db, now, { patients: seedMode === 'empty' ? 0 : DEMO_REGISTER.patients, mustChange: true });

    let admin = (DB.db.users || []).find(u => u.username === chiefUser || u.roleId === 'chief');
    const cSalt = newSalt();
    const cHash = strongHash(effectivePw, cSalt);
    if (!admin) {
      admin = {
        id: 'u-chief', username: chiefUser, name: chiefFull, roleId: 'chief',
        departmentId: 'exec', countyId: primaryCounty || 'kisumu', areaIds: []
      };
      DB.db.users.unshift(admin);
    }
    admin.name = chiefFull;
    admin.username = chiefUser;
    admin.email = hosted ? '' : `${chiefUser}@lomamo.example`; // no mailbox is inferred
    admin.salt = cSalt;
    admin.hash = cHash;
    admin.status = 'pending_activation';
    admin.active = true;
    /* Chief System Administrator MUST change password right after signing in on Official Sign-In */
    admin.mustChange = true;
    admin.mustChangePassword = true;
    admin.dpaFirstLoginRequired = true;
    admin.demo = false;
    admin.execTeam = true;

    DB.db.settings = DB.db.settings || {};
    DB.db.settings.security = Object.assign({ loginAttempts: 6, passwordMinLength: 12, sessionLock: true }, DB.db.settings.security || {});
    DB.db.settings.idleMinutes = DB.db.settings.idleMinutes || 30;
    DB.db.settings.org = {
      name: effectiveOrg,
      shortName: effectiveShort,
      county: primaryCounty || 'kisumu',
      primaryCounty: primaryCounty || 'kisumu',
      emailDomain: domain,
      loginUrl: portal
    };
    DB.db.settings.onboarding = { complete: true, step: 4 };
    DB.db.settings.hostSetupComplete = true;
    DB.db.settings.awaitingGlobalActivation = true;
    DB.db.settings.globallyActivated = false;
    DB.db.meta = Object.assign({}, DB.db.meta || {}, {
      setupComplete: true,
      hostCommissionedAt: todayISO(),
      globallyActivated: false,
      label: 'Host Commissioned · Awaiting Global Activation'
    });
    AUDIT.append({
      actor: admin.id,
      action: 'system.host_setup_completed',
      entity: 'system',
      entityId: 'four-step-host-setup',
      detail: `4-Step Online Setup completed for ${DB.db.settings.org.name}. Returning to Official Sign-In for Chief Admin (${chiefUser}) password change & Global System Activation.`
    });
    if(!hosted) DB.save();

    /* On a hosted PC this is a transaction from the user's perspective.  A
       refused/offline request, or a health read that cannot confirm the new
       commissioned state, must never produce a success screen. */
    if(hosted){
      const setupBody = JSON.stringify({
        admin: { name: chiefFull, username: chiefUser, email: admin.email, password: effectivePw, countyId: primaryCounty || 'kisumu', mustChange: true },
        org: DB.db.settings.org,
        awaitingGlobalActivation: true,
        globallyActivated: false,
        db: DB.db
      });
      const setupBytes = typeof TextEncoder !== 'undefined'
        ? new TextEncoder().encode(setupBody).length
        : (typeof Blob !== 'undefined' ? new Blob([setupBody]).size : setupBody.length);
      /* Keep a margin below Vercel's 4.5 MB Function limit. This is a
         fail-closed preflight, not permission to split a live installation
         into an unverified series of public setup writes. */
      if(setupBytes > 4 * 1024 * 1024){
        rollback();
        throw new Error('The setup package exceeds the safe Vercel request-size limit. Choose "Start with an empty patient register"; no setup request was sent and no completion is being claimed.');
      }
      let response;
      try{
        response = await SYNC._json('api/setup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: setupBody,
          skipAuthHeader: true,
          timeoutMs: 25000
        });
      }catch(e){
        rollback();
        throw new Error('The shared online database could not be reached. Setup was not completed locally.');
      }
      if(!response || !response.ok || !response.body || response.body.ok !== true){
        const authoritative = typeof hostProbe === 'function' ? await hostProbe() : null;
        rollback();
        if(authoritative){ APPX.host = authoritative; SYNC.server = authoritative; }
        throw new Error((response && response.body && response.body.error) || 'The shared online database refused setup. No completion is being claimed.');
      }
      let health = null;
      if (typeof hostProbe === 'function') {
        for (const ms of [0, 200, 450, 900]) {
          if (ms > 0) await new Promise(r => setTimeout(r, ms));
          health = await hostProbe();
          if (health && health.setup === true && health.globallyActivated !== true) break;
        }
      }
      if(!health || health.setup !== true || health.globallyActivated === true){
        /* The API already acknowledged a KV write.  Keep a fail-closed
           commissioned marker while verification is pending, rather than
           rolling back to a fresh-looking page that could offer demo/setup
           again.  This still does not return setup success. */
        APPX.host = Object.assign({}, previousHost || {}, health || {}, {
          setup:true, commissioned:true, demoMode:false,
          globallyActivated:Boolean(health && health.globallyActivated)
        });
        SYNC.server = APPX.host;
        try{ Store.set(DB.KEY, JSON.stringify(DB.db)); }catch(_e){}
        throw new Error('The API accepted setup, but a fresh health read did not verify it. No completion is being claimed; check the shared installation before retrying.');
      }
      APPX.host = health;
      SYNC.server = health;
      SYNC.rev = health.rev || response.body.rev || 0;
      try{ Store.set(DB.KEY, JSON.stringify(DB.db)); }catch(_e){}
      APPX.dirty = false;
    }

    if (typeof SYNC !== 'undefined') {
      clearTimeout(SYNC._timer);
      if (SYNC.stopPolling) SYNC.stopPolling();
      if (SYNC.storeToken) SYNC.storeToken(null);
    }
    if (typeof AUTH !== 'undefined' && AUTH.logout) AUTH.logout();
    if (typeof SYNC !== 'undefined') clearTimeout(SYNC._timer);
    if (typeof APPX !== 'undefined') APPX.dirty = false;
    return { ok: true, chiefUsername: chiefUser, chiefEmail: admin.email, loginUrl: portal, cloudVerified: hosted, rev: hosted ? SYNC.rev : 0 };
  },

  /* Chief System Administrator clicks "Activate System Globally":
     Finalizes confirmed roster seats. The hosted API generates single-use,
     expiring temporary passwords; only explicitly attested mailboxes are
     returned. Unconfirmed seats and the Chief credential are never reissued. */
  async activateSystemGlobally(opts = {}) {
    const actor = (typeof SILENT_OVERRIDE !== 'undefined' && SILENT_OVERRIDE.realActor()) || AUTH.user;
    if (!actor || actor.roleId !== 'chief') {
      toast('Chief System Administrator Only', 'Only the Chief System Administrator can Activate System Globally.', 'err');
      return null;
    }
    const domain = OFFICIAL_EMAIL_DOMAIN;
    const portalUrl = String(opts.loginUrl || opts.portalUrl || this.defaultPortalUrl()).trim();
    const roster = (typeof OFFICIAL_ROSTER !== 'undefined' && Array.isArray(OFFICIAL_ROSTER)) ? OFFICIAL_ROSTER : [];
    const hosted = typeof SYNC !== 'undefined' && SYNC.available && SYNC.available();
    if(hosted && !SYNC.sessionToken){
      toast('Sign in required', 'Global activation must be confirmed by the shared online Chief Administrator session.', 'err');
      return null;
    }
    const previousRaw = JSON.stringify(DB.db || DB.blank());
    const previousHost = typeof APPX !== 'undefined' ? APPX.host : null;
    const previousServer = typeof SYNC !== 'undefined' ? SYNC.server : null;
    const previousDirty = typeof APPX !== 'undefined' ? APPX.dirty : false;
    const rollback = () => {
      try{ DB.db = JSON.parse(previousRaw); DB.migrate(); Store.set(DB.KEY, previousRaw); }catch(_e){}
      if(typeof APPX !== 'undefined'){ APPX.host = previousHost; APPX.dirty = previousDirty; }
      if(typeof SYNC !== 'undefined') SYNC.server = previousServer;
    };

    DB.db.users = DB.db.users || [];
    const packRows = [];

    /* Activation never guesses or rewrites the Chief's mailbox. Mailbox
       authority belongs to the separate, authenticated server attestation. */
    actor.demo = false;
    actor.status = 'active';
    actor.active = true;

    /* Provision / finalize every single organogram account (including applicable Secretaries, Deputies & Clerks) */
    for (let i = 0; i < roster.length; i++) {
      const r = roster[i];
      const uname = String(r.username || '').trim().toLowerCase();
      if (!uname || r.roleId==='chief' || uname === String(actor.username || '').toLowerCase()) continue;

      let u = DB.db.users.find(x => String(x.username || '').toLowerCase() === uname);
      const cId = r.countyId !== undefined ? r.countyId : (r.county !== undefined ? r.county : 'kisumu');
      const deptId = r.dept || (roleObj(r.roleId) || {}).dept || 'admin';
      const jobTitle = r.job || r.title || (roleObj(r.roleId) || {}).name || r.roleId;
      const cleanName = String(r.name || (u && u.name) || uname).replace(/^Demo - /, '');
      const officialEmail = hosted ? ((u && u.mailboxConfirmed && u.email) || '') : uname+'@lomamo.example';
      const tempPassword = hosted ? '' : this.generateStrongPassword(12);
      const salt = newSalt();
      const hash = strongHash(tempPassword, salt);

      if (!u) {
        u = {
          id: 'u-' + uname.replace(/[.]/g, '-'),
          username: uname,
          createdAt: todayISO()
        };
        DB.db.users.push(u);
      }
      u.name = cleanName;
      u.username = uname;
      u.email = officialEmail;
      u.roleId = r.roleId;
      u.departmentId = deptId;
      u.countyId = cId;
      u.areaIds = r.areas || u.areaIds || [];
      u.jobTitle = jobTitle;
      u.seatTier = r.seatTier || u.seatTier || 'staff';
      u.unconfirmed = Boolean(r.unconfirmed);
      if (r.permOverrides) u.permOverrides = r.permOverrides;
      u.demo = false;
      u.active = true;
      u.status = 'pending_activation';
      u.mustChange = true;
      u.mustChangePassword = true;
      u.dpaFirstLoginRequired = true;
      u.provisionedAt = todayISO();
      u.loginUrl = portalUrl;
      if(hosted){delete u.salt;delete u.hash;}else{u.salt=salt;u.hash=hash;}
      if(r.unconfirmed){u.status='unconfirmed';u.active=false;u.mustChange=false;u.mustChangePassword=false;continue;}

      const deptLabel = (typeof deptName === 'function' ? deptName(deptId) : deptId) || 'Foundation';
      const countyLabel = cId ? countyName(cId) : 'Head Office (All Counties)';
      const roleLabel = (roleObj(u.roleId) || {}).name || u.roleId;

      packRows.push({
        name: cleanName,
        username: uname,
        email: officialEmail,
        loginUrl: portalUrl,
        tempPassword,
        role: roleLabel,
        department: deptLabel,
        seatTier: u.seatTier,
        county: countyLabel,
        whatsappBlock:
          `*${cleanName}*\n` +
          `• Seat / Role: ${jobTitle} (${countyLabel})\n` +
          `• Portal URL: ${portalUrl}\n` +
          `• Username: \`${uname}\`  |  Mock Email Alias: \`${officialEmail}\`\n` +
          `• Temporary Password: \`${tempPassword}\`\n` +
          `• Activation: Sign in at the Portal URL and set your private 12+ character password to activate your account.`,
        smsText: `CareLink C-DIMS (${portalUrl}): ${cleanName} | Username: ${uname} | Email: ${officialEmail} | Temp Password: ${tempPassword} — Sign in & change password to activate your account.`
      });
    }

    /* Strip any leftover demo flags on non-roster accounts */
    (DB.db.users || []).forEach(u => { u.demo = false; });

    DB.db.settings = DB.db.settings || {};
    DB.db.settings.org = Object.assign({}, DB.db.settings.org || {}, {
      emailDomain: domain,
      loginUrl: portalUrl
    });
    DB.db.settings.globallyActivated = true;
    DB.db.settings.globallyActivatedAt = todayISO();
    DB.db.settings.globallyActivatedBy = actor.username;
    DB.db.settings.awaitingGlobalActivation = false;
    DB.db.meta = Object.assign({}, DB.db.meta || {}, {
      globallyActivated: true,
      globallyActivatedAt: todayISO(),
      demoDisabled: true,
      productionMode: true,
      label: 'Globally Activated Official Production System'
    });
    if (!hosted && typeof APPX !== 'undefined' && APPX.host) {
      APPX.host.globallyActivated = true;
    }

    AUDIT.append({
      actor: actor.id,
      action: 'system.activated_globally',
      entity: 'system',
      entityId: 'global-activation',
      detail: `Chief System Admin (${actor.username}) activated CareLink globally across ${packRows.length + 1} organogram accounts (@${domain}); demo & host-setup screens permanently removed.`
    });
    if(!hosted) DB.save();

    /* Activation is not complete until the shared online source has both
       committed the activation and confirmed it on a fresh health read.  The
       same request also provisions every temporary staff password in KV. */
    if(hosted){
      let response;
      try{
        response = await SYNC._json('api/setup/activate-global', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            minRev: SYNC.rev || 0,
            emailDomain: domain,
            loginUrl: portalUrl,
            activatedBy: actor.username,
            users: DB.db.users,
            settings: DB.db.settings,
            meta: DB.db.meta,
            accounts: packRows.map(row => {
              const u = (DB.db.users || []).find(x => String(x.username || '').toLowerCase() === row.username);
              return { id:u && u.id, username:row.username, name:row.name, email:row.email,
                roleId:u && u.roleId, countyId:u && u.countyId, areaIds:u && u.areaIds, departmentId:u && u.departmentId };
            })
          })
        });
      }catch(e){
        rollback();
        toast('Global activation not confirmed', 'The shared online source could not be reached. No success is being claimed.', 'err');
        return null;
      }
      if(!response || !response.ok || !response.body || response.body.ok !== true || !Array.isArray(response.body.issued)){
        const authoritative = typeof hostProbe === 'function' ? await hostProbe() : null;
        rollback();
        if(authoritative){ APPX.host = authoritative; SYNC.server = authoritative; }
        toast('Global activation not confirmed', (response && response.body && response.body.error) || 'The online source refused activation or credential provisioning.', 'err');
        return null;
      }
      let health = null;
      if (typeof hostProbe === 'function') {
        for (const ms of [0, 200, 450, 900]) {
          if (ms > 0) await new Promise(r => setTimeout(r, ms));
          health = await hostProbe();
          if (health && health.globallyActivated === true) break;
        }
      }
      if(!health || health.globallyActivated !== true){
        /* The write was acknowledged, so fail closed while the confirming
           read is unavailable.  Do not issue a sheet or report success, but
           also do not reopen demo/setup against an installation that may
           already be active. */
        APPX.host = Object.assign({}, previousHost || {}, health || {}, {
          setup:true, commissioned:true, demoMode:false, globallyActivated:true, demoDisabled:true
        });
        SYNC.server = APPX.host;
        try{ Store.set(DB.KEY, JSON.stringify(DB.db)); }catch(_e){}
        toast('Global activation not confirmed', 'The API accepted activation, but a fresh health read did not confirm it. No credential sheet or success is being issued; verify the shared installation before retrying.', 'err');
        return null;
      }
      APPX.host = health;
      SYNC.server = health;
      SYNC.rev = health.rev || response.body.rev || 0;
      const issuedNames = new Set(response.body.issued.map(x => String(x.username || '').toLowerCase()));
      /* Do not hand out a sheet row for an account the server did not issue.
         In particular, a preserved private password must never be accompanied
         by a newly generated (and therefore invalid) temporary password. */
      for(let i=packRows.length-1;i>=0;i--){
        const uname = String(packRows[i].username || '').toLowerCase();
        if(!issuedNames.has(uname)) packRows.splice(i,1);
      }
      for(const row of packRows){
        const issued=response.body.issued.find(x=>String(x.username||'').toLowerCase()===row.username);
        row.tempPassword=issued.password;row.email=issued.email||'';row.expiresAt=issued.expiresAt;
        row.whatsappBlock=`${row.name}\nUsername: ${row.username}\nConfirmed work email: ${row.email||'not confirmed — use username'}\nLogin: ${portalUrl}\nSingle-use temporary password: ${row.tempPassword}\nExpires: ${row.expiresAt||'per system.config'} — replace privately before opening a workspace.`;
        row.smsText=row.whatsappBlock;
      }
      try{ Store.set(DB.KEY, JSON.stringify(DB.db)); }catch(_e){}
      APPX.dirty = false;
    }

    /* Build formatted Team WhatsApp Broadcast Sheet grouped by Department */
    const byDept = {};
    packRows.forEach(r => {
      (byDept[r.department] = byDept[r.department] || []).push(r);
    });
    const orgTitle = (DB.db.settings.org && DB.db.settings.org.name) || 'LOMAMO Foundation Kenya';
    const waLines = [
      `*==================================================*`,
      `*CARELINK C-DIMS — OFFICIAL GLOBAL ACTIVATION SHEET*`,
      `*${orgTitle}*`,
      `*==================================================*`,
      `Portal Login URL: ${portalUrl}`,
      `Activated By: ${actor.name} (${actor.username})`,
      `Date: ${new Date().toISOString().slice(0, 10)}`,
      ``,
      `*HOW EACH STAFF MEMBER ACTIVATES THEIR ACCOUNT:*`,
      `1. Open ${portalUrl} and sign in with your *Username* (or a confirmed work email, if listed) and *Temporary Password* below.`,
      `   New browsers must be approved by the Chief before sign-in can continue. This file is confidential: give each holder only their own row, never the whole pack.`,
      `2. CareLink immediately prompts you to set your own private 12+ character password known ONLY to you.`,
      `3. Once saved, your individual account status becomes *Activated* automatically.`,
      `4. Forgot password or new county staff? Use *Request / Recover* on Sign-In (routed urgently to your County Office Admin).`,
      ``
    ];
    Object.keys(byDept).forEach(dept => {
      waLines.push(`*--------------------------------------------------*`);
      waLines.push(`*DEPARTMENT: ${dept.toUpperCase()} (${byDept[dept].length} accounts)*`);
      waLines.push(`*--------------------------------------------------*`);
      byDept[dept].forEach((r, idx) => {
        waLines.push(`${idx + 1}. ${r.whatsappBlock}`);
        waLines.push(``);
      });
    });

    this.lastWhatsappSheet = waLines.join('\n');
    this.lastPack = {
      ok: true,
      generatedAt: todayISO(),
      chiefUsername: actor.username,
      emailDomain: domain,
      siteUrl: portalUrl,
      count: packRows.length,
      rows: packRows,
      pack: packRows,
      whatsappText: this.lastWhatsappSheet
    };
    return this.lastPack;
  },

  deliverExport(format, rows, deliver) {
    if (typeof SYNC === 'undefined' || !SYNC.available()) return deliver();
    const actor=AUTH.user && AUTH.user.username,token=SYNC.sessionToken,epoch=ENTRY_ADMIN.epoch;
    return SYNC._json('api/admin/staff-accounts/export-log',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({format,usernames:rows.map(row=>row.username)})
    }).then(result=>{
      if(!result.ok || !AUTH.user || AUTH.user.username!==actor || AUTH.user.roleId!=='chief' || SYNC.sessionToken!==token || ENTRY_ADMIN.epoch!==epoch){
        toast('Export not released',result.body.error||'The Chief session changed. No confidential file was downloaded.','err');return false;
      }
      return deliver();
    }).catch(()=>{toast('Export not released','The host could not record the export audit. Retry online; no file was downloaded.','err');return false;});
  },

  downloadWhatsappTxt() {
    if (!this.requireCredentialPackAccess()) return;
    const p = this.lastPack;
    if (!p || !p.rows.length) return toast('Activate System Globally first', 'Generate the organogram WhatsApp credential sheet first.', 'warn');
    return this.deliverExport('whatsapp-text',p.rows,()=>download('CareLink-Official-WhatsApp-Activation-Sheet-' + todayISO().slice(0, 10) + '.txt', p.whatsappText || this.lastWhatsappSheet, 'text/plain;charset=utf-8'));
  },

  async copyWhatsappSheet() {
    if (!this.requireCredentialPackAccess()) return;
    const txt = (this.lastPack && this.lastPack.whatsappText) || this.lastWhatsappSheet;
    if (!txt) return toast('No WhatsApp sheet in memory', 'Click Activate System Globally first.', 'warn');
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        const copied=await this.deliverExport('clipboard',this.lastPack.rows,()=>navigator.clipboard.writeText(txt));
        if(copied===false) return;
        toast('Copied for Team WhatsApp Platform', `${this.lastPack.count} organogram accounts copied — give each person only their own row through a private channel. Never paste the pack in a group.`, 'ok');
        return;
      }
    } catch (_e) {}
    this.downloadWhatsappTxt();
  },

  globalActivationBannerHTML(user) {
    if (!user || user.roleId !== 'chief') return '';
    if (this.isGloballyActivated()) {
      return `<div class="card" style="margin-bottom:14px;padding:12px 16px;border-left:4px solid var(--ok);background:var(--surface)">
        <div class="spread" style="gap:12px;flex-wrap:wrap">
          <div class="row" style="gap:10px">
            ${badge('System Globally Activated', 'b-ok')}
            <span class="small">Official mode locked — all Demo &amp; first-run setup options have been permanently removed from Landing &amp; Sign-In. Individual staff activate their accounts on first login.</span>
          </div>
          <div class="row" style="gap:8px;flex-wrap:wrap">
            <button class="btn btn-xs btn-primary" data-act="dev-dl-role-directory">${ic('download',12)} Download role account directory (.txt)</button>
            ${this.ownsCredentialPack(user) ? `<button class="btn btn-xs btn-ghost" data-act="dev-dl-credentials">${ic('key',12)} Download confidential credentials (${this.lastPack.count})</button>` : ''}
          </div>
        </div>
      </div>`;
    }
    const patientCount = (DB.db && Array.isArray(DB.db.patients)) ? DB.db.patients.length : 0;
    const masterLoaded = Boolean((DB.db && DB.db.meta && DB.db.meta.referenceMaster) || patientCount >= DEMO_REGISTER.patients);
    const feedingNow = typeof REFERENCE_MASTER !== 'undefined' && (REFERENCE_MASTER.phase === 'loading' || REFERENCE_MASTER.phase === 'uploading');
    return `<div class="card" style="margin-bottom:16px;padding:16px 20px;border:2px solid #D97706;background:linear-gradient(135deg, rgba(245,158,11,.12), rgba(15,118,110,.08))">
      <div class="spread" style="gap:16px;flex-wrap:wrap;align-items:center">
        <div style="flex:1;min-width:260px">
          <div class="xs bold" style="text-transform:uppercase;letter-spacing:.09em;color:#B45309;margin-bottom:4px">${ic('sparkles',13)} Final Commissioning Step · Chief System Administrator Authority</div>
          <div style="font-size:16.5px;font-weight:800;margin-bottom:4px">Ready to Activate CareLink C-DIMS Globally Across All LOMAMO Departments</div>
          <div class="small muted">Issues server-generated, expiring single-use passwords to confirmed roster seats. Unconfirmed seats receive no credentials, and work mail is included only after Chief attestation of an existing mailbox. Every new holder must set a private password before opening a workspace. Demo and setup controls are then locked.</div>
          <div class="xs" style="margin-top:6px">${masterLoaded
            ? `<span style="color:var(--ok);font-weight:700">✓ Complete ${num(DEMO_REGISTER.patients)}-Patient Cloud Dataset Verified in KV (${num(patientCount)} patients · 100% completeness)</span>`
            : `<span class="muted">Patient register currently has <b>${num(patientCount)}</b> records — you can auto-feed the built-in 100%-complete ${num(DEMO_REGISTER.patients)}-patient dataset with zero local file upload before locking activation.</span>`}</div>
        </div>
        <div class="row" style="gap:8px;flex-wrap:wrap">
          ${!masterLoaded ? `<button class="btn btn-soft" type="button" style="padding:11px 16px;font-weight:700" data-act="auto-feed-cloud-master" ${feedingNow?'disabled':''}>${ic('database',15)} ${feedingNow?`Feeding ${num(DEMO_REGISTER.patients)} Patients…`:`Auto-Feed ${num(DEMO_REGISTER.patients)}-Patient Dataset`}</button>` : ''}
          <button class="btn btn-primary" type="button" style="padding:11px 20px;font-weight:800" data-act="open-global-activate">${ic('shieldcheck',16)} Activate System Globally</button>
        </div>
      </div>
    </div>`;
  },

  openGlobalActivateModal() {
    const actor = (typeof SILENT_OVERRIDE !== 'undefined' && SILENT_OVERRIDE.realActor()) || AUTH.user;
    if (!actor || actor.roleId !== 'chief') return toast('Chief System Administrator Only', '', 'err');
    const pack = this.lastPack;
    const rosterCount = (typeof OFFICIAL_ROSTER !== 'undefined' ? OFFICIAL_ROSTER.length : 0);
    const patientCount = (DB.db && Array.isArray(DB.db.patients)) ? DB.db.patients.length : 0;
    const masterLoaded = Boolean((DB.db && DB.db.meta && DB.db.meta.referenceMaster) || patientCount >= DEMO_REGISTER.patients);
    openModal({
      title: this.isGloballyActivated() ? 'Official Team WhatsApp Activation Sheet' : 'Activate CareLink System Globally',
      sub: `${orgName()} · Complete Organogram Provisioning & Permanent Demo Removal`,
      wide: true,
      body: `<form id="globalActivateForm">
        <div class="grid g2" style="gap:12px;margin-bottom:12px">
          <div class="field"><label>Official Staff Email Domain</label>
            <input class="input mono" name="emailDomain" value="${esc(OFFICIAL_EMAIL_DOMAIN)}" readonly>
            <div class="hint">Sign in with the issued username. An existing <code>@${esc(OFFICIAL_EMAIL_DOMAIN)}</code> mailbox appears only after Chief confirmation in Staff credential export. No mailbox is guessed or provisioned; email/SMS 2FA is deferred to Phase 2.</div>
          </div>
          <div class="field"><label>Official System Login URL *</label>
            <input class="input mono" name="loginUrl" value="${esc(this.defaultPortalUrl())}" required>
            <div class="hint">Included on every staff member's WhatsApp dispatch block.</div>
          </div>
        </div>
        ${!this.isGloballyActivated() ? (masterLoaded
          ? `<div class="alert ok" style="margin-bottom:12px">${ic('check',16)}<div><b>100%-Complete ${num(DEMO_REGISTER.patients)}-Patient Cloud Dataset Ready</b><div class="small">All ${num(patientCount)} complete patient profiles, visits, and PDCA cycles are already committed in Cloud KV and will be shared across all departmental consoles.</div></div></div>`
          : `<label class="row" style="gap:10px;align-items:flex-start;padding:12px 14px;margin-bottom:12px;border-radius:10px;border:1.5px solid var(--brand);background:var(--brand-soft,rgba(15,118,110,.06));cursor:pointer">
              <input type="checkbox" name="autoFeedMaster" value="1" style="margin-top:3px">
              <span class="small"><b>Evaluation only: load ${num(DEMO_REGISTER.patients)} synthetic patients before activation</b><br>
              <span class="muted">Off by default. Select only for an isolated evaluation database. Generates synthetic patients and related records at runtime; leave unchecked for production and never use on an existing live register.</span></span>
            </label>`) : ''}
        <div class="alert info" style="margin-bottom:12px">${ic('shield',16)}<div>
          <b>What happens when you click Activate System Globally:</b>
          <div class="small" style="margin-top:4px">1. The <b>${num(rosterCount)} official roster seats</b> retain their actual names or unconfirmed seat labels. Named staff receive unique, server-generated temporary passwords; the Chief and unconfirmed seats do not. No unconfirmed mailbox is exported.<br>
          2. Each staff member needs an approved registered browser, redeems a temporary password once within its validity period (seven days by default), and sets a private password before accessing staff data.<br>
          3. All Demo tabs, "Explore demo accounts", and "First-run online setup" links are <b>permanently removed</b> from Landing &amp; Sign-In.</div>
        </div></div>
        <div class="alert warn" style="margin-bottom:12px"><div><b>Credential handling</b><div class="small">Temporary passwords are secrets. Download the single confidential account document only to an approved device, then distribute each user’s credentials privately and securely delete the file after dispatch.</div></div></div>
      </form>`,
      footer: `<button class="btn btn-ghost" data-act="close-modal">Close</button>
        ${pack ? `<button class="btn btn-primary" data-act="dev-dl-credentials">${ic('download',14)} Download confidential account document</button>`
        : `<button class="btn btn-primary" data-act="exec-global-activate">${ic('shieldcheck',15)} Confirm &amp; Activate System Globally</button>`}`
    });
  },

  generateStrongPassword(len = 14) {
    const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    const lower = 'abcdefghijkmnopqrstuvwxyz';
    const digits = '23456789';
    const syms = '@#%&*+=?';
    const all = upper + lower + digits + syms;
    const rnd = (max) => {
      if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
        const a = new Uint32Array(1);
        crypto.getRandomValues(a);
        return a[0] % max;
      }
      return Math.floor(Math.random() * max);
    };
    const chars = [
      upper[rnd(upper.length)],
      upper[rnd(upper.length)],
      lower[rnd(lower.length)],
      lower[rnd(lower.length)],
      digits[rnd(digits.length)],
      digits[rnd(digits.length)],
      syms[rnd(syms.length)],
      syms[rnd(syms.length)]
    ];
    while (chars.length < len) chars.push(all[rnd(all.length)]);
    for (let i = chars.length - 1; i > 0; i--) {
      const j = rnd(i + 1);
      const t = chars[i]; chars[i] = chars[j]; chars[j] = t;
    }
    return chars.join('');
  },

  validatePrivacyPassword(pw, user, currentPw = '') {
    const s = String(pw || '');
    if (s.length < 12) return 'Password must be at least 12 characters long under CareLink Data Protection standards.';
    if (!/[A-Z]/.test(s)) return 'Include at least one uppercase letter (A–Z).';
    if (!/[a-z]/.test(s)) return 'Include at least one lowercase letter (a–z).';
    if (!/[0-9]/.test(s)) return 'Include at least one number (0–9).';
    if (!/[^A-Za-z0-9]/.test(s)) return 'Include at least one special symbol (e.g. @ # % & * ! ?).';
    if (/lomamo2026|password|123456|qwerty|carelink/i.test(s)) return 'Do not use a known default, organisation name or common sequence.';
    if (currentPw && s === currentPw) return 'Your personal password must be completely different from the temporary SMS password.';
    if (user) {
      const uname = String(user.username || '').toLowerCase();
      if (uname && uname.length >= 3 && s.toLowerCase().includes(uname)) {
        return 'Password must not contain your username.';
      }
      const parts = String(user.name || '').toLowerCase().split(/\s+/).filter(p => p.length >= 4);
      for (const p of parts) {
        if (s.toLowerCase().includes(p)) return 'Password must not contain parts of your personal name.';
      }
    }
    return '';
  },

  async provisionProductionPack({ adminName, adminUsername, adminPassword, orgNameVal, shortNameVal, primaryCounty, seedMode }) {
    const roster = (typeof OFFICIAL_ROSTER !== 'undefined' && Array.isArray(OFFICIAL_ROSTER)) ? OFFICIAL_ROSTER : [];
    const chiefUser = String(adminUsername || 'chief.admin').trim().toLowerCase();
    const chiefName = String(adminName || 'Chief System Administrator').trim();

    /* Build fresh or reference DB */
    const db = DB.blank();
    if (seedMode === 'reference' && typeof seedOfficial === 'function') {
      seedSyntheticDataset(db, new Date('2026-11-22T00:00:00.000Z'), { patients: DEMO_REGISTER.patients, mustChange: true });
    }
    db.meta = Object.assign({}, db.meta || {}, {
      setupComplete: true,
      commissionedAt: todayISO(),
      productionMode: true,
      demoSeeded: seedMode === 'reference',
      label: seedMode === 'reference' ? 'Production Commissioned + Reference Dataset' : 'Production Live Register',
      onlineDatabase: true
    });
    db.settings = db.settings || {};
    db.settings.org = {
      name: orgNameVal || 'Loving Hands Management & Medical Organization',
      shortName: shortNameVal || 'LOMAMO',
      county: primaryCounty || 'kisumu',
      primaryCounty: primaryCounty || 'kisumu'
    };
    db.settings.onboarding = { complete: true, step: 9 };
    db.settings.ai = Object.assign({}, db.settings.ai || {}, { enabled: true, provider: 'online' });

    const packRows = [];
    const provisionedUsers = [];

    /* 1. Chief System Administrator (personal password set during setup) */
    const chiefSalt = newSalt();
    const chiefHash = strongHash(adminPassword, chiefSalt);
    const chiefRec = {
      id: 'u-chief',
      username: chiefUser,
      name: chiefName,
      roleId: 'chief',
      departmentId: 'exec',
      countyId: primaryCounty || 'kisumu',
      areaIds: [],
      jobTitle: 'Chief System Administrator',
      status: 'active',
      active: true,
      mustChange: false,
      mustChangePassword: false,
      passwordSetAt: todayISO(),
      salt: chiefSalt,
      hash: chiefHash,
      createdAt: todayISO()
    };
    provisionedUsers.push(chiefRec);

    /* 2. Generate unique strong SMS temporary passwords for every roster account */
    for (let i = 0; i < roster.length; i++) {
      const r = roster[i];
      if (String(r.username || '').toLowerCase() === chiefUser) continue;
      const tempPassword = this.generateStrongPassword(14);
      const salt = newSalt();
      const hash = strongHash(tempPassword, salt);
      const cId = r.countyId !== undefined ? r.countyId : (r.county !== undefined ? r.county : 'kisumu');
      const uRec = {
        id: 'u-' + String(r.username).replace(/[.]/g, '-'),
        username: String(r.username).toLowerCase(),
        name: r.name,
        roleId: r.roleId,
        departmentId: r.dept || (roleObj(r.roleId) || {}).dept || 'admin',
        countyId: cId,
        areaIds: r.areas || [],
        jobTitle: r.job || r.title || (roleObj(r.roleId) || {}).name || r.roleId,
        status: 'active',
        active: true,
        mustChange: true,
        mustChangePassword: true,
        dpaFirstLoginRequired: true,
        provisionedAt: todayISO(),
        salt,
        hash,
        createdAt: todayISO()
      };
      provisionedUsers.push(uRec);
      packRows.push({
        name: uRec.name,
        username: uRec.username,
        tempPassword,
        role: (roleObj(uRec.roleId) || {}).name || uRec.roleId,
        county: uRec.countyId ? countyName(uRec.countyId) : 'Head Office (All Counties)',
        smsText: `CareLink C-DIMS (${db.settings.org.shortName}): Hello ${uRec.name}, your account is ready at ${location.origin}. Username: ${uRec.username} | One-Time Password: ${tempPassword} . On first sign-in you will set your private password known only to you.`
      });
    }

    db.users = provisionedUsers;
    DB.db = db;
    AUDIT.append({
      actor: chiefRec.id,
      action: 'system.production_commissioned',
      entity: 'system',
      entityId: 'first-run',
      detail: `Commissioned Chief System Admin (${chiefUser}) and generated ${packRows.length} unique SMS staff credentials with mandatory first-login privacy password change.`
    });
    DB.save();

    /* Also push credentials & state to the Unified Online Site Database if reachable */
    try {
      const resp = await fetch('api/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          admin: { name: chiefName, username: chiefUser, password: adminPassword, countyId: primaryCounty || 'kisumu' },
          org: db.settings.org,
          roster: roster.filter(r => String(r.username || '').toLowerCase() !== chiefUser),
          state: db,
          db
        })
      });
      if (resp.ok) {
        const j = await resp.json().catch(() => ({}));
        if (Array.isArray(j.credentialsPack) && j.credentialsPack.length) {
          packRows.length = 0;
          j.credentialsPack.forEach(cp => {
            const match = db.users.find(u => u.username === String(cp.username).toLowerCase());
            if (match && cp.tempPassword) {
              match.salt = newSalt();
              match.hash = strongHash(cp.tempPassword, match.salt);
            }
            packRows.push({
              name: cp.name,
              username: cp.username,
              tempPassword: cp.tempPassword,
              role: (roleObj(cp.roleId) || {}).name || cp.role || cp.roleId,
              county: cp.countyId ? countyName(cp.countyId) : 'Head Office (All Counties)',
              smsText: cp.smsText || `CareLink C-DIMS: Hello ${cp.name}, sign in at ${location.origin} | Username: ${cp.username} | One-Time Password: ${cp.tempPassword} . Set your own private password on first login.`
            });
          });
          DB.save();
        }
      }
    } catch (_e) { /* Offline/static fallback keeps local salted vault */ }

    this.lastPack = {
      generatedAt: todayISO(),
      chiefUsername: chiefUser,
      siteUrl: location.origin,
      count: packRows.length,
      rows: packRows
    };
    return { chiefRec, pack: this.lastPack };
  },

  pendingPackTargets(actor = (typeof AUTH !== 'undefined' ? AUTH.user : null)) {
    if (!actor || !DB.db) return [];
    return (DB.db.users || []).filter(u => u && u.id !== actor.id && u.roleId !== 'chief' &&
      !u.unconfirmed && !u.archivedByRebuild && u.status !== 'inactive' &&
      !u.privacyPasswordSet && (u.mustChange || u.mustChangePassword || u.demo || !u.lastLogin));
  },

  async regeneratePackForMustChangeUsers() {
    const actor = AUTH.user;
    if (!actor || actor.roleId !== 'chief') {
      toast('Chief System Administrator Only', 'Only the Chief System Administrator may generate an initial SMS credential pack.', 'err');
      return null;
    }
    const hosted = typeof SYNC !== 'undefined' && SYNC.available && SYNC.available();
    const previousRaw = JSON.stringify(DB.db || DB.blank());
    const previousDirty = typeof APPX !== 'undefined' ? APPX.dirty : false;
    const rollback = () => {
      try{ DB.db = JSON.parse(previousRaw); DB.migrate(); Store.set(DB.KEY, previousRaw); }catch(_e){}
      if(typeof APPX !== 'undefined') APPX.dirty = previousDirty;
    };
    const targets = this.pendingPackTargets(actor);
    if (!targets.length) {
      toast('All accounts already personalised', 'Every active user has already set their private password. Use per-user reset in Users & Accounts if an individual forgot theirs.', 'info');
      return null;
    }
    const packRows = [];
    for (const u of targets) {
      const tempPassword = hosted ? '' : this.generateStrongPassword(14);
      if(!hosted){const salt=newSalt();u.salt=salt;u.hash=strongHash(tempPassword,salt);}
      u.demo = false;
      u.mustChange = true;
      u.mustChangePassword = true;
      u.dpaFirstLoginRequired = true;
      const cleanName = u.name.replace(/^Demo - /, '');
      packRows.push({
        name: cleanName,
        username: u.username,
        tempPassword,
        role: (roleObj(u.roleId) || {}).name || u.roleId,
        county: u.countyId ? countyName(u.countyId) : 'Head Office (All Counties)',
        smsText: `CareLink C-DIMS: Hello ${cleanName}, sign in at ${location.origin} | Username: ${u.username} | One-Time Password: ${tempPassword} . You will set your own private password on first login.`
      });
    }
    /* A hosted credential sheet is only valid when the online credential
       vault issued the same passwords.  Never fall back to the browser's
       locally generated hashes after a failed request. */
    if(hosted){
      let resp;
      try{
        resp = await SYNC._json('api/credentials/provision', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ accounts: targets.map(u => ({
            id: u.id, username: u.username, email:u.email || undefined, name: u.name.replace(/^Demo - /, ''),
            roleId: u.roleId, departmentId: u.departmentId, countyId: u.countyId,
            areaIds: u.areaIds, jobTitle: u.jobTitle
          })) })
        });
      }catch(_e){
        rollback();
        toast('Credential pack not confirmed', 'The shared online source could not be reached. No local-only credential sheet was issued.', 'err');
        return null;
      }
      const srvList = resp && resp.body && Array.isArray(resp.body.issued) ? resp.body.issued : [];
      if(!resp || !resp.ok || srvList.length !== targets.length){
        rollback();
        toast('Credential pack not confirmed', (resp && resp.body && resp.body.error) || 'The online source did not issue every requested credential. No local-only sheet was issued.', 'err');
        return null;
      }
      packRows.length = 0;
      srvList.forEach(cp => {
        const pw = cp.tempPassword || cp.password;
        const match = targets.find(t => t.username === String(cp.username).toLowerCase());
        if(match){delete match.hash;delete match.salt;match.email=cp.email||'';}
        packRows.push({
          name: cp.name,
          username: cp.username,
          email: cp.email || '',
          department: cp.departmentId || (match && match.departmentId) || '',
          tempPassword: pw,
          expiresAt: cp.expiresAt,
          role: cp.roleName || (roleObj(cp.roleId) || {}).name || cp.role || cp.roleId || '',
          county: cp.county || (cp.countyId ? countyName(cp.countyId) : 'Head Office'),
          smsText: cp.smsText || `CareLink C-DIMS: Hello ${cp.name}, sign in at ${location.origin} | Username: ${cp.username} | One-Time Password: ${pw} . Set your own private password on first login.`
        });
      });
    }

    AUDIT.append({
      actor: actor.id,
      action: 'system.sms_credential_pack_generated',
      entity: 'users',
      entityId: String(packRows.length),
      detail: `Generated one-time SMS credential pack for ${packRows.length} account(s); first-login private password enforced.`
    });
    DB.save();
    this.lastPack = { kind:'pending-only', generatedAt: todayISO(), chiefUsername: actor.username, siteUrl: location.origin, count: packRows.length, rows: packRows };
    return this.lastPack;
  },

  openReactivationModal(recover = false) {
    if(!AUTH.user || AUTH.user.roleId !== 'chief') return toast('Chief only', '', 'err');
    openModal({ title: recover ? 'Recover confidential credential pack' : 'Rebuild and reactivate the official hierarchy', narrow:true,
      sub:'Chief System Administrator authorisation',
      body:`<div class="alert warn"><div><b>${recover ? 'Recovery is available for 24 hours' : 'This resets non-Chief accounts'}</b>
        <p class="small">${recover
          ? 'Only temporary passwords that are still valid are included. Personalised passwords cannot be recovered. Changing the Chief password also makes the recovery copy unreadable.'
          : 'All other existing accounts and sessions, including any other Chief accounts, are replaced or deactivated. Only your current Chief sign-in and non-account records are preserved. Named officers receive server-generated single-use passwords. They must replace them privately before accessing a workspace; temporary passwords expire under system.config. Unconfirmed seats remain disabled.'}</p>
        <p class="small">Only explicitly confirmed existing <code>@${esc(OFFICIAL_EMAIL_DOMAIN)}</code> mailboxes are exported. All other officers sign in by assigned username. Distribute each credential privately.</p></div></div>
        <div class="field"><label for="reactivationPassword">Current Chief password</label>
          <input class="input" id="reactivationPassword" type="password" autocomplete="current-password"></div>
        ${recover ? '' : '<div class="field"><label for="reactivationConfirm">Type REBUILD to confirm</label><input class="input" id="reactivationConfirm" autocomplete="off"></div>'}`,
      footer:`<button type="button" class="btn btn-ghost" data-act="close-modal">Cancel</button>
        <button type="button" class="btn ${recover?'btn-primary':'btn-danger'}" data-act="${recover?'dev-recover-reactivation':'dev-confirm-reactivation'}">${recover?'Recover pack':'Rebuild accounts'}</button>` });
  },

  async runReactivation(recover = false) {
    const actor = AUTH.user;
    if(!actor || actor.roleId !== 'chief' || !SYNC.available()) return toast('Chief online session required', '', 'err');
    if(this._reactivating) return;
    const password = String(document.querySelector('#reactivationPassword')?.value || '');
    const confirmation = String(document.querySelector('#reactivationConfirm')?.value || '');
    if(!password || (!recover && confirmation !== 'REBUILD')) return toast('Confirmation required', 'Enter your password and, when rebuilding, type REBUILD.', 'warn');
    if(!recover && (SYNC._inflight || APPX.dirty)) return toast('Save pending work first', 'Wait for the current save to finish, then retry the rebuild.', 'warn');
    this._reactivating = true;
    clearTimeout(SYNC._timer);
    try {
      const r = await SYNC._json(recover ? 'api/admin/reactivation-pack' : 'api/admin/reactivate', {
        method:'POST', headers:{'Content-Type':'application/json'}, timeoutMs:55000,
        body:JSON.stringify({password, ...(recover ? {} : {confirm:confirmation})})
      });
      if(!r.ok || !Array.isArray(r.body.issued)) {
        const detail = r.body.error || 'The server did not confirm this operation.';
        toast('Reactivation not confirmed', detail + (r.status >= 500 && !recover ? ' Use Recover recent pack before trying another rebuild.' : ''), 'err');
        return;
      }
      const rows = r.body.issued.map(row=>({ ...row, county:countyName(row.county),
        loginUrl:location.origin, smsText:`CareLink: Sign in at ${location.origin} with username ${row.username}${row.email?' or confirmed work email '+row.email:''}. Your private handoff contains a single-use temporary password, expiring ${row.expiresAt||'under system.config'}. Use an approved registered browser and set a private password before opening a workspace.` }));
      this.lastPack = { kind:recover ? 'recovered-rebuild' : 'official-rebuild', generatedAt:todayISO(), chiefUsername:actor.username, siteUrl:location.origin,
        count:rows.length, rows, expiresAt:r.body.expiresAt };
      this.lastWhatsappSheet = '';
      closeAllModals();
      /* Never discard edits made while the rebuild request was in flight. */
      const hasPending = APPX.dirty || SYNC._inflight;
      const refreshed = !hasPending && await SYNC.pullFull({minRev:r.body.rev});
      if(!refreshed){
        SYNC.stopPolling();
        toast('Pack ready; refresh needed', hasPending
          ? 'Download the pack. Pending device edits were kept; resolve them before refreshing the rebuilt hierarchy.'
          : 'Download the pack. Reload or sign in again before editing the shared workspace.', 'warn');
      } else {
        AUTH.user = (DB.db.users||[]).find(u=>u.username===actor.username) || actor;
        toast(recover ? 'Credential pack recovered' : 'Hierarchy rebuilt', `${rows.length} named staff received expiring, single-use temporary credentials. Approved browser and private-password replacement are required before workspace access. Download the confidential document now.`, 'ok');
      }
      render();
    } catch(_e) {
      toast('Result not confirmed', 'If the connection dropped, use Recover credential pack before trying another rebuild.', 'err');
    } finally { this._reactivating = false; }
  },

  downloadCredentialDocument() {
    if (!this.requireCredentialPackAccess()) return;
    const p = this.lastPack;
    if (!p || !p.rows.length) return toast('No active pack in memory', 'Generate a credential sheet first.', 'warn');
    const html = v => esc(String(v ?? ''));
    const packDescription = p.kind === 'official-rebuild' ? 'Official hierarchy rebuild — newly issued named officers' : p.kind === 'recovered-rebuild' ? 'Recovered rebuild pack — only still-valid temporary passwords' : 'Pending-account pack — not the full official hierarchy';
    const rows = p.rows.map((r, i) => `<tr>
      <td>${i + 1}</td><td><strong>${html(r.name)}</strong></td><td>${html(r.username)}</td>
      <td>${html(r.email || 'Not confirmed — use username')}</td>
      <td class="password">${html(r.tempPassword)}</td><td>${html(r.role)}</td>
      <td>${html(r.department || '')}</td><td>${html(r.county)}</td>
    </tr>`).join('');
    const document = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Confidential CareLink Account Provisioning</title><style>
      :root{color-scheme:light}body{font:14px/1.5 Arial,sans-serif;color:#172033;margin:32px auto;padding:0 22px;max-width:1200px}
      header{border-bottom:3px solid #0f766e;padding-bottom:14px;margin-bottom:18px}h1{font-size:24px;margin:0 0 4px}
      .notice{border:1px solid #b45309;background:#fff7ed;padding:14px;margin:18px 0;border-radius:8px}
      table{width:100%;border-collapse:collapse;font-size:12px}th,td{border:1px solid #cbd5e1;padding:8px;text-align:left;vertical-align:top}
      th{background:#e8f2f1}tr:nth-child(even){background:#f8fafc}.password{font-family:monospace;font-weight:bold;white-space:nowrap}
      .meta{color:#475569}.footer{margin-top:20px;color:#475569;font-size:12px}@media print{body{margin:12mm;padding:0}.notice{break-inside:avoid}tr{break-inside:avoid}button{display:none}}
      </style></head><body><header><h1>CareLink C-DIMS · Initial Account Provisioning</h1>
      <div>${html((DB.db.settings.org && DB.db.settings.org.name) || 'LOMAMO Foundation Kenya')}</div>
      <div class="meta">${html(packDescription)} · Single-use temporary credentials · Generated ${html(p.generatedAt)} · Portal ${html(p.siteUrl)} · ${p.rows.length} accounts</div></header>
      <section class="notice"><strong>CONFIDENTIAL — ACCOUNT PASSWORDS</strong><br>
      This document contains account credentials. The Chief System Administrator must distribute each account holder’s credentials privately through an approved channel. Never post this file to a shared group, public repository, or unapproved storage. Temporary passwords expire after seven days by default (or the configured system.config period) and can be redeemed once, on an approved registered browser. Every holder must choose a private password before opening a workspace. Securely delete this document after dispatch; retain no reusable password copy. This document is not a substitute for account authorization or access controls.</section>
      <table><thead><tr><th>#</th><th>Account holder / seat</th><th>Username</th><th>Confirmed work mailbox</th><th>Single-use temporary password</th><th>Role</th><th>Department</th><th>Office / county</th></tr></thead><tbody>${rows}</tbody></table>
      <p class="footer">Credential handoff record only. Confirm the recipient’s identity before sharing. Only explicitly confirmed existing work mailboxes may be listed. An empty address is not evidence of a mailbox; use the username. Unconfirmed seats receive no credential.</p>
      </body></html>`;
    return this.deliverExport('html',p.rows,()=>download('CareLink-Confidential-Account-Provisioning-' + todayISO().slice(0, 10) + '.html', document, 'text/html;charset=utf-8'));
  },

  async downloadRoleDirectory() {
    const actor = AUTH && AUTH.user;
    if(!actor || actor.roleId !== 'chief') return toast('Restricted', 'Only the Chief System Administrator may export the account directory.', 'err');
    if(!this.isGloballyActivated()) return toast('Commissioning required', 'The role account directory is available only after global activation.', 'warn');
    try {
      // Never export guessed/legacy DB.users emails or browser-invented people.
      // Online: the same authoritative roster and mailbox attestations as CSV.
      // Offline: roster labels only; no unverified work addresses are released.
      const users = typeof SYNC !== 'undefined' && SYNC.available()
        ? (await ENTRY_ADMIN.request('staff-accounts')).rows
        : OFFICIAL_ROSTER.map(seat=>({...seat,username:seat.roleId==='chief'?actor.username:seat.username,email:'',mailboxConfirmed:false}));
      const clean=value=>String(value||'').replace(/[\r\n]+/g,' ').trim();
      const lines = [
        'CARELINK C-DIMS — COMMISSIONED ROLE ACCOUNT DIRECTORY',
        'Confidential official roster, including unconfirmed seat labels. No passwords or patient information.',
        'Generated: ' + todayISO(),
        'Roster seats: ' + users.length,
        '='.repeat(64),
        ...users.map((u,i) => {
          const role = roleObj(u.roleId);
          const email=u.mailboxConfirmed && /^[a-z0-9._-]+@lomamofoundation\.org$/i.test(u.email||'') ? u.email : 'not confirmed — use username';
          return `${String(i+1).padStart(3,'0')}. ${clean(u.name || u.jobTitle || u.job || u.username)}${u.unconfirmed?' [unconfirmed seat]':''}\n` +
            `     Role: ${clean((role && role.name) || u.roleId || 'Staff')}\n` +
            `     Confirmed official email: ${email}\n` +
            `     Username: ${clean(u.username)}\n`;
        })
      ].join('\n');
      return await this.deliverExport('directory-text',users,()=>{download('CareLink-Commissioned-Role-Account-Directory-' + todayISO() + '.txt', lines, 'text/plain;charset=utf-8');toast('Directory downloaded', `${users.length} actual roster seats listed. No passwords are included.`, 'ok');});
    } catch(error) { toast('Directory not released',error.message,'err'); }
  },

  downloadCSV() {
    if (!this.requireCredentialPackAccess()) return;
    const p = this.lastPack;
    if (!p || !p.rows.length) return toast('No active pack in memory', 'Generate a credential sheet first.', 'warn');
    const escCsv = v => {let text=String(v??'');if(/^[=+\-@\t\r]/.test(text))text="'"+text;return `"${text.replace(/"/g,'""')}"`;};
    const lines = [
      ['Full Name / Organogram Seat', 'Username', 'Confirmed Work Mailbox', 'Portal Login URL', 'Issued Password', 'Assigned Role', 'Department', 'Office / County', 'WhatsApp / SMS Dispatch'].map(escCsv).join(','),
      ...p.rows.map(r => [r.name, r.username, r.email || '', r.loginUrl || p.siteUrl || this.defaultPortalUrl(), r.tempPassword, r.role, r.department || '', r.county, r.whatsappBlock || r.smsText].map(escCsv).join(','))
    ];
    return this.deliverExport('csv',p.rows,()=>download('CareLink-Official-Organogram-Credentials-' + todayISO().slice(0, 10) + '.csv', lines.join('\r\n'), 'text/csv;charset=utf-8'));
  },

  downloadSMSText() {
    if (!this.requireCredentialPackAccess()) return;
    const p = this.lastPack;
    if (!p || !p.rows.length) return toast('No active pack in memory', 'Generate a one-time SMS credential pack first.', 'warn');
    const body = [
      '====================================================================',
      'CARELINK C-DIMS — CONFIDENTIAL SMS CREDENTIAL DISPATCH PACK',
      'Generated: ' + p.generatedAt + ' | Portal: ' + p.siteUrl,
      'PRIVACY NOTICE (DPA 2019): Temporary passwords are single-use and expire',
      'under system.config (seven days by default). Use an approved browser and',
      'set a private password BEFORE workspace access. Delete after private dispatch.',
      '====================================================================',
      '',
      ...p.rows.map((r, i) => `[${i + 1}] ${r.name} (${r.role} · ${r.county})\nSMS -> ${r.smsText}\n`)
    ].join('\r\n');
    return this.deliverExport('sms-text',p.rows,()=>download('CareLink-SMS-Dispatch-' + todayISO().slice(0, 10) + '.txt', body, 'text/plain;charset=utf-8'));
  }
};

/* ---------------- 2. Chief Admin Audited Silent Override ---------------- */
const SILENT_OVERRIDE = {
  state: null, /* { active:true, realAdmin, targetId, targetUsername, targetRole, startedAt, reason, viewsVisited:[] } */

  isActive() {
    return Boolean(this.state && this.state.active && this.state.realAdmin);
  },

  realActor() {
    return this.isActive() ? this.state.realAdmin : AUTH.user;
  },

  canOverride(user) {
    const real = this.isActive() ? this.state.realAdmin : user;
    return Boolean(real && real.roleId === 'chief' && RBAC.has(real, 'system.override.silent'));
  },

  async enter(targetUserId, reasonInput = '') {
    const real = this.realActor();
    if (!this.canOverride(real)) {
      toast('Chief System Administrator Only', 'Silent workspace override is restricted to the Chief System Administrator.', 'err');
      return false;
    }
    const target = (DB.db.users || []).find(u => u.id === targetUserId);
    if (!target) {
      toast('Account not found', 'Could not locate target user account.', 'err');
      return false;
    }
    if (target.id === real.id) {
      toast('Already in Chief Admin account', 'Select a different staff account to inspect.', 'info');
      return false;
    }
    const reason = String(reasonInput || 'Workspace & role-navigation verification by Chief System Administrator').trim();

    this.state = {
      active: true,
      realAdmin: real,
      targetId: target.id,
      targetName: target.name,
      targetUsername: target.username,
      targetRole: (roleObj(target.roleId) || {}).name || target.roleId,
      startedAt: todayISO(),
      reason,
      viewsVisited: ['home']
    };

    /* Switch active session lens to target user WITHOUT notifying or alerting target user */
    AUTH.user = target;
    APPX.view = 'home';
    APPX.params = {};

    /* Record complete, tamper-evident system audit entry (local + online server) */
    AUDIT.append({
      actor: real.id,
      action: 'system.silent_override.start',
      entity: 'user',
      entityId: target.id,
      detail: `Chief System Admin (${real.username}) entered silent workspace & left-nav override for ${target.username} (${this.state.targetRole}). Target user not notified. Reason: ${reason}`
    });
    DB.save();

    try {
      const tok = (typeof SYNC !== 'undefined' && SYNC.token) ? SYNC.token : '';
      fetch('api/admin/silent-override', {
        method: 'POST',
        headers: Object.assign({ 'Content-Type': 'application/json' }, tok ? { 'X-CareLink-Session': tok } : {}),
        body: JSON.stringify({ phase: 'start', targetUserId: target.id, targetUsername: target.username, targetRole: target.roleId, reason })
      }).catch(() => {});
    } catch (_e) {}

    render();
    return true;
  },

  recordView(viewId) {
    if (!this.isActive() || !viewId) return;
    if (!this.state.viewsVisited.includes(viewId)) {
      this.state.viewsVisited.push(viewId);
      AUDIT.append({
        actor: this.state.realAdmin.id,
        action: 'system.silent_override.view',
        entity: 'view',
        entityId: viewId,
        detail: `Silent override as ${this.state.targetUsername}: inspected view '${viewId}'`
      });
    }
  },

  exit() {
    if (!this.isActive()) return;
    const st = this.state;
    const real = st.realAdmin;
    this.state = null;
    AUTH.user = real;
    AUDIT.append({
      actor: real.id,
      action: 'system.silent_override.end',
      entity: 'user',
      entityId: st.targetId,
      detail: `Chief System Admin (${real.username}) exited silent override of ${st.targetUsername}. Views inspected: ${st.viewsVisited.join(', ')}`
    });
    DB.save();

    try {
      const tok = (typeof SYNC !== 'undefined' && SYNC.token) ? SYNC.token : '';
      fetch('api/admin/silent-override', {
        method: 'POST',
        headers: Object.assign({ 'Content-Type': 'application/json' }, tok ? { 'X-CareLink-Session': tok } : {}),
        body: JSON.stringify({ phase: 'end', targetUserId: st.targetId, targetUsername: st.targetUsername, reason: 'Visited: ' + st.viewsVisited.join(', ') })
      }).catch(() => {});
    } catch (_e) {}

    APPX.view = 'devconsole';
    APPX.params = { tab: 'override' };
    render();
  },

  bannerHTML() {
    if (!this.isActive()) return '';
    const st = this.state;
    return `<div class="override-bar no-print" role="region" aria-label="Silent Administrator Override Active">
      <span class="ovb-badge">${ic('shield', 14)} SILENT OVERRIDE · AUDITED</span>
      <span class="ovb-text">Viewing customized workspace &amp; left navigation as <b>${esc(st.targetName.replace(/^Demo - /, ''))}</b> (${esc(st.targetRole)} · <code style="color:inherit">${esc(st.targetUsername)}</code>) — <i>User is not notified; session logged to System Audit Trail.</i></span>
      <div class="ovb-actions">
        <button class="btn btn-xs ovb-btn-primary" data-act="silent-override-exit">${ic('lock', 12)} Return to Chief System Admin</button>
      </div>
    </div>`;
  }
};

/* ---------------- 2b. System Administrator Version Control Engine ---------------- */
const VERSION_CONTROL = {
  RELEASES: [
    { tag:'v6.9.6', date:'2026-11-22', channel:'Production', schema:6, author:'CareLink OS Core Engineering',
      summary:'Hardened the installed application (install button, offline and new-version notices, a bounded navigation fallback), measured every department palette against the contrast rule it is drawn with, and added the weekly planning page and the report gaps the usage trial report names.',
      changes:['Install button is now actually attached on every host; an offline strip, a new-version reload notice and an "Offline on this device" status chip were added',
        'Held work is replayed the moment the network returns, not at the next poll',
        'Every department palette reviewed: banner contrast corrected stop by stop and badge tints corrected, with the department identity preserved',
        'Weekly Planning Indicators report: 16 named figures, bags by code, villages versus slums, and a not-recorded count that is never counted as a decision',
        'Reports now carry the period they actually cover (ISO week, month, quarter, registry month) and one list drives both the report centre and the archive',
        'New capability patient.ministry.view gates the recorded-decision count',
        'Demonstration support issues now use the register\u2019s own seven items and are dated along the programme'] },
    { tag:'v6.9.5', date:'2026-11-22', channel:'Production', schema:6, author:'CareLink OS Core Engineering',
      summary:'Rebuilt the demonstration register to the Foundation specification (4,000 patients, ages 5–75, 40% in the day 60–80 window, 50/50 Kisumu–Homa Bay, three-weekly weights) and added team audio and video calling.',
      changes:['Fixed 4,000-patient board register with an exact 40% day 60–80 window and an even county split','Every patient carries at least 12 recorded contacts on a 21-day home-visit rhythm and three or more weights','Reference master, API validation and operator screens now state one register size instead of a scattered number','Team Chat audio and video calling with invitation, ringing, answer, decline and audited call records'] },
    { tag:'v6.9.4', date:'2026-11-22', channel:'Production', schema:6, author:'CareLink OS Core Engineering',
      summary:'Refined role workspace banners and navigation, balanced the public front door, and updated the fresh-install roster with the supplied county and department instructions.' },
    { tag:'v6.9.3', date:'2026-11-22', channel:'Production', schema:6, author:'CareLink OS Core Engineering',
      summary:'Refined the LOMAMO black, white, grey and red front door and sign-in; clarified commissioning status and secure account recovery.',
      changes:['Logo-inspired neutral front door with restrained red accents','Clear distinction between fresh setup and an already commissioned installation','Updated application, API and build version identifiers'] },
    { tag:'v6.9.2', date:'2026-10-29', channel:'Production Stable', schema:63, author:'CareLink OS Core Engineering',
      summary:'Restored the Heritage Sapphire blue sign-in identity with deep sapphire brand panel, subtle radial depth, and blue-white access console while preserving readable white sign-in forms.',
      changes:['Deep sapphire gradient and radial depth on desktop sign-in brand panel','Blue-white sign-in canvas, refined card shadows and mobile sign-in treatment','Preserved accessible white sign-in form controls and Foundation White role consoles'] },
    { tag:'v6.9.1', date:'2026-10-29', channel:'Production Stable', schema:63, author:'CareLink OS Core Engineering',
      summary:'Write-once non-expiring KV shard architecture + automatic Shard 2 self-healing recovery, Heritage Sapphire blue front-door landing page & layered topology graphic restored, and Quiet Precision white workspace consoles.',
      changes:['Write-once immutable KV shard keys + automatic degraded shard self-healing','Lightweight manifest-head login/logout commits (zero shard rewrites)','Restored Heritage Sapphire blue front/landing page & layered radial-beam topology graphic','Preserved Quiet Precision Foundation White signed-in workspace consoles'] },
    { tag:'v6.9.0', date:'2026-10-29', channel:'Production Stable', schema:63, author:'CareLink OS Core Engineering',
      summary:'Quiet Precision Architectural White Redesign: Monochrome + Single Sapphire Palette, Clean Light Landing Architecture Diagram, Zero Colored Stripes/Rainbow KPIs, Single-Tier Console Header, Automatic uiEpoch=690 Legacy Cache Reset, and Streamlined 29-Role Consoles.' },
    { tag:'v6.8.0', date:'2026-10-29', channel:'Production', schema:63, author:'CareLink OS Core Engineering',
      summary:'Global Luminous Pearl-White Default Theme (Landing, Sign-In, Glass Command Topbar, White Chrome & Specular Top-Bar KPIs), 100% Elimination of Hardcoded White-Fill Visibility Bugs Across All 30 Themes, Decongested Shell & Compact 2x2 Sidebar Dock, and 29 Bespoke Departmental & Geographic-Scope Console Workbenches.' },
    { tag:'v6.7.0', date:'2026-10-27', channel:'Production', schema:63, author:'CareLink OS Core Engineering',
      summary:'Strategic Plan (2027–2031) Live Alignment (7× Caseload Scale-Up to 3,703 Active, Sub-County Sequence & Alumni Network), 9-Part Confidentiality & Ethical Storytelling Policy (22-Point Pre-Pub Gate & 5-Layer Consent) + Kenya DPA (2019) HIV/Health Safeguards, Decongested 6-Archetype Departmental Consoles, 100% Zero White-Out Text/Tabs, 5-Tier Banner Typography & Seamless Online-Safe Account Switching.' },
    { tag:'v6.6.8', date:'2026-10-25', channel:'Production', schema:63, author:'CareLink OS Core Engineering',
      summary:'Restored Heritage Sapphire Royal Blue Landing Page, bumped APP.version v6.6.8, Upstash root POST + Native Redis RESP2 TCP/TLS Failover, Exact Host/Body 403 Diagnostics, 30 Workspace Themes (Foundation White console default) & Strict 29-Role Scoped Left Navigation.' },
    { tag:'v6.6.0', date:'2026-10-24', channel:'Production', schema:63, author:'CareLink OS Core Engineering',
      summary:'Official CareLink C-DIMS PDCA 120-Day & Discharge Engine, AI Monday Meeting Processor & Secretary Desk, Baseline-Anchored Charts, Dominant Dept Banners, Installable Font/Theme Packs, Tablet Foundation Default & System Admin Version Control.' },
    { tag:'v6.5.0', date:'2026-10-23', channel:'Production', schema:63, author:'CareLink OS Core Engineering',
      summary:'Global System Activation & WhatsApp Credential Sheet, Urgent County Sign-In Routing, CareLink AI Workflow Engine, Executive Sitting Console, C-DIMS Coins & Expenditure-vs-Budget Boards.' },
    { tag:'v6.4.0', date:'2026-10-22', channel:'Production', schema:63, author:'CareLink OS Core Engineering',
      summary:'County Admin Daily PAYG, Weekly Suppliers, 9th Statutory Deductions, Operational Expenses, Kisumu HQ Kenya Reports, Dedicated Dev Console & Audited Silent Override.' },
    { tag:'v6.3.0', date:'2026-10-21', channel:'Production', schema:63, author:'CareLink OS Core Engineering',
      summary:`${DEMO_REGISTER.patients.toLocaleString('en-GB')} Complete Beneficiary Longitudinal Records (12+ visits), Child Growth Curves, MCM SOAP Console, Hard-Copy Intake Scans, Monday Meeting & 4-Tier Procurement.` },
    { tag:'v6.0.0', date:'2026-10-15', channel:'Foundation Baseline', schema:60, author:'LOMAMO Foundation ICT',
      summary:'Unified CareLink C-DIMS Operating System across 10 Ministry Areas, Kisumu & Homa Bay County Offices, and PBKDF2-SHA256 Zero-Knowledge Vault.' }
  ],

  ensureStore(){
    if(!DB.db) return;
    DB.db.versionControl = DB.db.versionControl || { snapshots: [] };
    if(!Array.isArray(DB.db.versionControl.snapshots)) DB.db.versionControl.snapshots = [];
    if(!DB.db.versionControl.snapshots.length){
      DB.db.versionControl.snapshots.push({
        id: 'vcs-init-660',
        tag: `v${APP.version}-baseline`,
        category: 'System Release Baseline',
        message: `Initial CareLink v${APP.version} verified configuration & RBAC baseline checkpoint.`,
        author: 'Chief System Administrator',
        createdAt: todayISO(),
        checksum: this.computeChecksum(),
        counts: this.captureCounts(),
        configSnapshot: this.captureConfig()
      });
    }
  },

  captureConfig(){
    const s = (DB.db && DB.db.settings) || {};
    return JSON.parse(JSON.stringify({
      consoleTheme: s.consoleTheme || 'foundation',
      consoleThemeExplicit: Boolean(s.consoleThemeExplicit),
      density: s.density || 'comfortable',
      accentMode: s.accentMode || 'department',
      programme: s.programme || { defaultDays: 90, maxDays: 120, reviewCadence: 30 },
      security: s.security || { loginAttempts: 6, passwordMinLength: 12, sessionLock: true },
      installedVisualPacks: s.installedVisualPacks || [],
      customRoles: (DB.db && DB.db.customRoles) || []
    }));
  },

  captureCounts(){
    const db = DB.db || {};
    return {
      users: (db.users||[]).length,
      patients: (db.patients||[]).length,
      visits: (db.visits||[]).length,
      customRoles: (db.customRoles||[]).length,
      visualPacks: (db.settings && db.settings.installedVisualPacks || []).length,
      auditEntries: (db.audit||[]).length
    };
  },

  computeChecksum(){
    const raw = JSON.stringify(this.captureConfig());
    let h = 2166136261;
    for(let i=0;i<raw.length;i++){
      h ^= raw.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return 'sha-' + (h >>> 0).toString(16).padStart(8,'0');
  },

  commitSnapshot({ tag, category, message }, actor){
    this.ensureStore();
    const cleanTag = String(tag || `v${APP.version}-cp${DB.db.versionControl.snapshots.length+1}`).trim();
    const snap = {
      id: uid('vcs'),
      tag: cleanTag,
      category: category || 'Configuration Checkpoint',
      message: String(message || 'System Administrator configuration checkpoint').trim(),
      author: (actor && actor.name ? actor.name.replace(/^Demo - /,'') : 'Chief System Administrator'),
      createdAt: new Date().toISOString(),
      checksum: this.computeChecksum(),
      counts: this.captureCounts(),
      configSnapshot: this.captureConfig()
    };
    DB.db.versionControl.snapshots.unshift(snap);
    AUDIT.append({
      actor: (actor && actor.id) || 'system',
      action: 'system.vcs.checkpoint_created',
      entity: 'version_control',
      entityId: snap.tag,
      detail: `[${snap.category}] ${snap.message} (checksum ${snap.checksum})`
    });
    DB.save();
    return snap;
  },

  diffAgainstLive(snapId){
    this.ensureStore();
    const snap = DB.db.versionControl.snapshots.find(s=>s.id===snapId);
    if(!snap) return [];
    const live = this.captureConfig();
    const old = snap.configSnapshot || {};
    const keys = ['consoleTheme','density','accentMode','programme','security','customRoles','installedVisualPacks'];
    return keys.map(k=>{
      const a = JSON.stringify(old[k]);
      const b = JSON.stringify(live[k]);
      return { key:k, changed: a !== b, snapshotVal: a, liveVal: b };
    });
  },

  rollbackConfig(snapId, actor){
    this.ensureStore();
    const snap = DB.db.versionControl.snapshots.find(s=>s.id===snapId);
    if(!snap || !snap.configSnapshot) return { ok:false, msg:'Checkpoint snapshot not found.' };
    const cfg = JSON.parse(JSON.stringify(snap.configSnapshot));
    DB.db.settings = DB.db.settings || {};
    DB.db.settings.consoleTheme = cfg.consoleTheme || 'foundation';
    DB.db.settings.consoleThemeExplicit = Boolean(cfg.consoleThemeExplicit);
    DB.db.settings.density = cfg.density || 'comfortable';
    DB.db.settings.accentMode = cfg.accentMode || 'department';
    if(cfg.programme) DB.db.settings.programme = cfg.programme;
    if(cfg.security) DB.db.settings.security = cfg.security;
    DB.db.settings.installedVisualPacks = cfg.installedVisualPacks || [];
    DB.db.customRoles = cfg.customRoles || [];
    AUDIT.append({
      actor: (actor && actor.id) || 'system',
      action: 'system.vcs.rollback_executed',
      entity: 'version_control',
      entityId: snap.tag,
      detail: `Restored configuration & role state from checkpoint ${snap.tag} (${snap.checksum}). Patient clinical data preserved untouched.`
    });
    DB.save();
    if(typeof applyTheme === 'function') applyTheme();
    return { ok:true, snap };
  }
};

/* ---------------- 3. Dedicated Development Console ---------------- */
const DEV_CONSOLE_STATE = {
  tab: 'telemetry',
  cloudStatus: null,
  probing: false,
  searchUser: '',
  overrideReason: 'Routine workspace & role-navigation audit verification'
};

const DEV_CONSOLE = {
  canAccess(user) {
    const real = SILENT_OVERRIDE.realActor() || user;
    return Boolean(real && RBAC.has(real, 'dev.console'));
  },

  async probeCloud() {
    DEV_CONSOLE_STATE.probing = true;
    render();
    const out = { checkedAt: todayISO(), bootstrapOk: false, storageMode: 'browser-indexeddb', rev: DB.db?.meta?.rev || 1, aiOk: false, aiProvider: 'offline-fallback', aiModel: '-' };
    try {
      const r = await fetch('api/bootstrap', { cache: 'no-store' });
      if (r.ok) {
        const j = await r.json();
        out.bootstrapOk = true;
        out.storageMode = j.storageMode || (j.onlineDatabase ? 'online-site-db' : 'lan-sqlite-wal');
        out.rev = j.rev ?? out.rev;
        out.accounts = j.accounts ?? (DB.db.users || []).length;
        out.setup = Boolean(j.setup);
      }
    } catch (_e) {}
    try {
      const a = await AI.probe();
      out.aiOk = Boolean(a.ok);
      out.aiProvider = a.provider || (a.ok ? 'online-cloud' : 'deterministic-summary');
      out.aiModel = a.pick || (a.models && a.models[0]) || '-';
    } catch (_e) {}
    DEV_CONSOLE_STATE.cloudStatus = out;
    DEV_CONSOLE_STATE.probing = false;
    render();
  },

  render(user, params = {}) {
    if (!this.canAccess(user)) return deniedPanel('dev.console');
    if (params.tab) DEV_CONSOLE_STATE.tab = params.tab;
    const tab = DEV_CONSOLE_STATE.tab;
    const real = SILENT_OVERRIDE.realActor() || user;
    const isChief = real.roleId === 'chief';
    const cs = DEV_CONSOLE_STATE.cloudStatus;
    const users = DB.db.users || [];
    const personalised = users.filter(u => !u.mustChangePassword && !u.demo).length;
    const awaitingFirstLogin = users.filter(u => u.mustChangePassword).length;
    const pendingPackCount = PROD_SETUP.pendingPackTargets(real).length;
    const namedRosterCount = typeof OFFICIAL_ROSTER !== 'undefined' ? OFFICIAL_ROSTER.filter(r=>!r.unconfirmed && r.roleId!=='chief').length : 0;
    const overrideLogs = (DB.db.audit || []).filter(a => String(a.action || '').startsWith('system.silent_override')).slice(-30).reverse();

    VERSION_CONTROL.ensureStore();
    const vcsSnaps = DB.db.versionControl.snapshots || [];
    const liveChecksum = VERSION_CONTROL.computeChecksum();

    const tabs = [
      ['vcs', `Version Control (${vcsSnaps.length})`],
      ['telemetry', 'Online Site Database & Shared AI'],
      ['provisioning', 'First-Run Setup & SMS Credential Pack'],
      ...(isChief ? [['override', 'Chief Admin Silent Override']] : []),
      ['diagnostics', 'RBAC Matrix, Schema & Layout Diagnostics']
    ];

    const devUtil = (typeof utilMenu === 'function') ? utilMenu('Admin Utilities', [
      { label:'Commit Version Checkpoint', icon:'save', act:'dev-vcs-commit-modal' },
      { label:'Export Release & VCS Ledger (.json)', icon:'download', act:'dev-vcs-export' },
      { divider:true },
      { label:'Probe Online DB & AI', icon:'refresh', act:'dev-probe-cloud' },
      ...(isChief ? [{ label:'Launch First-Run Setup Wizard', icon:'sparkles', act:'goto-onboard' }] : [])
    ], { icon:'settings' }) : '';

    const head = pageHead(
      'CareLink Development Console · Version Control & Cloud Governance',
      `CareLink C-DIMS v${APP.version} (Build ${window.BUILD_STAMP || APP.build}) · System Administrator Version Control, Unified Online Site Database, Shared Intelligence & Audited Silent Override.`,
      `<div class="row" style="gap:8px;flex-wrap:wrap">
        <button class="btn btn-sm btn-primary" data-act="dev-vcs-commit-modal">${ic('save', 14)} Commit Checkpoint</button>
        <button class="btn btn-sm btn-ghost" data-act="dev-probe-cloud">${ic('refresh', 14)} ${DEV_CONSOLE_STATE.probing ? 'Probing...' : 'Probe Cloud'}</button>
        ${devUtil}
      </div>`
    );

    const kpis = `<div class="grid g4" style="margin-bottom:16px">
      ${kpi('Active System Release', `v${APP.version}`, `Schema v${APP.schema} · Checksum ${liveChecksum}`, 'ok', 'flow')}
      ${kpi('Site Database Engine', cs ? cs.storageMode : ((typeof SYNC !== 'undefined' && SYNC.online) ? 'Online Synced DB' : 'Unified Site DB Ready'), `${num(users.length)} accounts · ${num((DB.db.patients||[]).length)} patients`, 'info', 'database')}
      ${kpi('DPA Password Privacy', `${num(personalised)} private`, `${num(awaitingFirstLogin)} awaiting 1st-login change`, 'ok', 'lock')}
      ${kpi('VCS Checkpoints & Audit', `${num(vcsSnaps.length)} tags`, `${num(overrideLogs.length)} override audit logs`, 'info', 'shieldcheck')}
    </div>`;

    const tabBar = `<div class="tabs" role="tablist" style="margin-bottom:16px">
      ${tabs.map(([id, label]) => `<button class="tab ${tab === id ? 'active' : ''}" role="tab" data-act="dev-tab" data-tab="${id}">${esc(label)}</button>`).join('')}
    </div>`;

    let body = '';

    if (tab === 'vcs') {
      body = `<div class="grid g2" style="margin-bottom:16px">
        ${card('Active Release Build & Configuration Integrity', `
          <div class="dl">
            <dt>Release Tag</dt><dd><b class="mono">CareLink C-DIMS v${esc(APP.version)}</b> ${badge('Production Active','b-ok',false)}</dd>
            <dt>Database Schema</dt><dd class="mono">Schema v${esc(String(APP.schema))} (backward-compatible LWW merge)</dd>
            <dt>Build Timestamp</dt><dd class="mono">${esc(window.BUILD_STAMP || APP.build || todayISO())}</dd>
            <dt>Live Config Checksum</dt><dd class="mono bold">${esc(liveChecksum)}</dd>
            <dt>Custom Roles &amp; Visual Packs</dt><dd>${num((DB.db.customRoles||[]).length)} custom role(s) &middot; ${num((DB.db.settings?.installedVisualPacks||[]).length)} custom pack(s)</dd>
          </div>
          <div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap">
            <button class="btn btn-xs btn-primary" data-act="dev-vcs-commit-modal">${ic('plus',12)} Create Checkpoint Tag</button>
            <button class="btn btn-xs btn-ghost" data-act="dev-vcs-export">${ic('download',12)} Export VCS Manifest (.json)</button>
          </div>
        `)}
        ${card('System Administrator Checkpoint Snapshots', table([
          { label:'Tag & Checksum', render:s=>`<b class="mono">${esc(s.tag)}</b><div class="xs mono muted">${esc(s.checksum)}</div>` },
          { label:'Commit Summary', render:s=>`<b>${esc(s.category)}</b><div class="xs muted">${esc(s.message)}</div><div class="xs muted">By ${esc(s.author)} &middot; ${esc(fmtDateTime(s.createdAt))}</div>` },
          { label:'Actions', cls:'right', render:s=>`<div class="row" style="gap:6px;justify-content:flex-end">
            <button class="btn btn-xs btn-ghost" data-act="dev-vcs-diff" data-id="${esc(s.id)}">Diff</button>
            ${isChief ? `<button class="btn btn-xs btn-soft" data-act="dev-vcs-rollback" data-id="${esc(s.id)}">Restore</button>` : ''}
          </div>` }
        ], vcsSnaps), { sub:'Snapshots preserve configuration, roles, security thresholds & visual packs while never overwriting clinical patient charts.' })}
      </div>`
      + card('Institutional Release History & Changelog Ledger', table([
        { label:'Release', cls:'mono', render:r=>`<b>${esc(r.tag)}</b><div class="xs muted">${esc(r.date)}</div>` },
        { label:'Channel', render:r=>badge(r.channel, r.tag==='v'+APP.version?'b-ok':'b-neutral', false) },
        { label:'Schema', cls:'mono', render:r=>`v${r.schema}` },
        { label:'Engineering & Governance Deliverables', render:r=>`<span class="small">${esc(r.summary)}</span>` }
      ], VERSION_CONTROL.RELEASES));
    }

    if (tab === 'telemetry') {
      const colCounts = Object.keys(DB.db || {}).filter(k => Array.isArray(DB.db[k])).map(k => ({ name: k, count: DB.db[k].length }));
      body = `<div class="grid g2" style="margin-bottom:16px">
        ${card('Unified Online Site Database (`/api/*`)', `<div class="dl">
          <dt>Architecture</dt><dd><b>Single Shared Online Site Database</b> (replaces local Wi-Fi-only storage)</dd>
          <dt>Active Endpoint</dt><dd class="mono">${esc(location.origin)}/api/state</dd>
          <dt>Storage Backend</dt><dd class="mono">${esc(cs?.storageMode || ((typeof SYNC !== 'undefined' && SYNC.online) ? 'Connected Online Host' : 'Serverless KV / Persistent Vault'))}</dd>
          <dt>Password Vault Protection</dt><dd>${badge('PBKDF2-SHA256 · 160,000 rounds · Hashes stripped from client sync', 'b-ok', 'nodot')}</dd>
          <dt>Field-Level Merge</dt><dd>Concurrent multi-account edits merged by record timestamp + append-only audit log</dd>
        </div>
        <div style="margin-top:12px" class="row">
          <button class="btn btn-xs btn-primary" data-act="dev-probe-cloud">${ic('refresh', 12)} Run Live Endpoint Probe</button>
          ${typeof SYNC !== 'undefined' ? `<button class="btn btn-xs btn-ghost" data-act="open-sync">${ic('database', 12)} Online Sync Status</button>` : ''}
        </div>`)}
        ${card('Shared Online Intelligence (`/api/ai/chat`)', `<div class="dl">
          <dt>Routing Mode</dt><dd><b>Server-Mediated Shared Online Intelligence</b> (all signed-in accounts share one online AI service)</dd>
          <dt>Zero-Localhost Guarantee</dt><dd>${badge('No browser localhost calls · Relative /api/ai/* proxy', 'b-ok', 'nodot')}</dd>
          <dt>Active Provider</dt><dd class="mono">${esc(cs?.aiProvider || AI.status.provider || 'online')}</dd>
          <dt>Active Model</dt><dd class="mono">${esc(cs?.aiModel || AI.status.model || 'Cloud / Deterministic CareLink Summary')}</dd>
          <dt>Role-Scoped Redaction</dt><dd>Prompts are scoped to each user's RBAC lens; HR &amp; Media never receive clinical identifiers</dd>
        </div>
        <div style="margin-top:12px" class="row">
          <button class="btn btn-xs btn-primary" data-act="toggle-ai">${ic('sparkles', 12)} Open Shared Intelligence Drawer</button>
        </div>`)}
      </div>`
      + card('Live Database Collections Inventory', table([
        { label: 'Collection Key', render: r => `<span class="mono bold">${esc(r.name)}</span>` },
        { label: 'Records in Shared Store', cls: 'num', render: r => `<b class="mono">${num(r.count)}</b>` },
        { label: 'Sync Policy', render: r => badge(r.name === 'audit' ? 'Append-only hash chain' : 'Field-level LWW merge', 'b-neutral', 'nodot') }
      ], colCounts));
    }

    if (tab === 'provisioning') {
      const pack = PROD_SETUP.ownsCredentialPack(real) ? PROD_SETUP.lastPack : null;
      body = `<div class="alert info" style="margin-bottom:16px">${ic('shield', 18)}<div>
        <b>Production First-Run &amp; Strict Privacy Password Architecture (Kenya Data Protection Act, 2019)</b>
        <span class="small">The official rebuild issues a new confidential document for the named roster; the separate pending-account generator is only a subset. Every issued temporary password is single-use and expires under system.config. Approved browser and private-password replacement are mandatory before workspace access.</span>
      </div></div>`
      + (isChief && PROD_SETUP.isGloballyActivated() ? card('Rebuild the official hierarchy', `<p class="small">Reconcile the Kisumu and Homa Bay roster and issue ${num(namedRosterCount)} named officers single-use temporary passwords; they expire under system.config and must be replaced privately on an approved browser before work. Only confirmed existing work mailboxes are included. Unconfirmed seats stay disabled. Your current Chief sign-in and non-account records are retained; all other legacy accounts, including any other Chief accounts, are replaced or deactivated.</p>
          <div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn btn-danger" data-act="dev-open-reactivation">Rebuild &amp; reactivate</button>
          <button class="btn btn-ghost" data-act="dev-open-recover-reactivation">Recover recent pack</button></div>
          <p class="hint">The Chief password is required. If the response is interrupted, recover the encrypted pack within 24 hours before retrying.</p>`) : '')
      + `<div class="grid g2" style="margin-bottom:16px">
        ${card('Pending accounts only — not the full roster', `<p class="small muted" style="margin-top:0">This creates credentials only for ${num(pendingPackCount)} eligible pending accounts, not the ${num(namedRosterCount)}-officer official rebuild. Previously personalised and unconfirmed accounts are excluded. To issue the complete named roster use <b>Rebuild &amp; reactivate</b> above.</p>
          <div class="row" style="gap:8px;flex-wrap:wrap;margin-top:12px">
            ${isChief ? `<button class="btn btn-sm btn-primary" data-act="dev-gen-sms-pack">${ic('key', 14)} Generate pending-only pack (${num(pendingPackCount)} accounts)</button>` : ''}
            <button class="btn btn-sm btn-ghost" data-act="goto-onboard">${ic('sparkles', 14)} Open First-Run Setup Wizard</button>
          </div>
          ${pack ? `<div class="divider"></div>
            <div class="alert ok" style="margin-top:10px">${ic('check', 16)}<div>
              <b>${pack.kind === 'official-rebuild' ? 'Official rebuild' : pack.kind === 'recovered-rebuild' ? 'Recovered rebuild (still-valid only)' : 'Pending accounts only'} credential pack ready (${num(pack.count)} accounts)</b>
              <span class="small">Generated ${fmtDateTime(pack.generatedAt)}. Download now for SMS dispatch; temporary passwords are never persisted in cleartext.</span>
            </div></div>
            <div class="row" style="gap:8px;margin-top:10px;flex-wrap:wrap">
              ${isChief ? `<button class="btn btn-sm btn-primary" data-act="dev-dl-credentials">${ic('download', 14)} Download Confidential Account Document</button>` : ''}
            </div>` : ''}`)}
        ${card('First-Login Privacy Password Standard', `<div class="dl">
          <dt>Minimum Length</dt><dd><b>12 characters</b> (enforced on first sign-in)</dd>
          <dt>Character Classes</dt><dd>Uppercase + Lowercase + Digit + Special Symbol</dd>
          <dt>Identity Check</dt><dd>Rejects username, personal name parts &amp; previous temporary password</dd>
          <dt>Zero-Knowledge Storage</dt><dd>Salted PBKDF2-HMAC-SHA256; server strips <code>hash</code> &amp; <code>salt</code> from all API responses</dd>
        </div>`)}
      </div>`
      + (pack ? card('Preview of Current One-Time SMS Credential Pack (In-Memory Only)', table([
          { label: 'Staff Name', render: r => `<b>${esc(r.name)}</b>` },
          { label: 'Username', render: r => `<code class="mono">${esc(r.username)}</code>` },
          { label: 'One-Time SMS Password', render: r => `<code class="mono bold">${esc(r.tempPassword)}</code>` },
          { label: 'Role & County', render: r => `<span class="small">${esc(r.role)} · ${esc(r.county)}</span>` }
        ], pack.rows.slice(0, 25)), { sub: `Showing first ${Math.min(25, pack.rows.length)} of ${pack.rows.length} generated SMS credentials.` }) : '');
    }

    if (tab === 'override' && isChief) {
      const q = (DEV_CONSOLE_STATE.searchUser || '').toLowerCase().trim();
      const candidates = users.filter(u => u.id !== real.id && (!q || `${u.name} ${u.username} ${u.roleId} ${u.countyId || ''}`.toLowerCase().includes(q)));
      body = `<div class="alert warn" style="margin-bottom:16px">${ic('shield', 18)}<div>
        <b>Chief System Administrator — Silent Workspace &amp; Left-Navigation Override</b>
        <span class="small">Inspect any account's live role-scoped workspace and customized left-panel navigation <b>silently without notifying or interrupting the user</b>. Every override start, view visited, and exit is permanently recorded in the hash-chained System Audit Log.</span>
      </div></div>`
      + card('Launch Audited Silent Override', `
        <div class="grid g2" style="margin-bottom:12px">
          <div class="field"><label>Filter Staff / Role / County</label>
            <input class="input" placeholder="Search name, username, role (e.g. homabay, media, clinician)..." value="${esc(DEV_CONSOLE_STATE.searchUser)}" oninput="DEV_CONSOLE_STATE.searchUser=this.value;render()">
          </div>
          <div class="field"><label>Mandatory Audit Log Reason</label>
            <input class="input" id="silentOverrideReason" value="${esc(DEV_CONSOLE_STATE.overrideReason)}" oninput="DEV_CONSOLE_STATE.overrideReason=this.value" placeholder="Reason recorded in System Audit Log">
          </div>
        </div>`
        + table([
          { label: 'Account', render: u => `<div class="cellname">${esc(u.name.replace(/^Demo - /, ''))}<span class="sm mono">${esc(u.username)}</span></div>` },
          { label: 'Role', render: u => badge((roleObj(u.roleId) || {}).name || u.roleId, 'b-neutral', 'nodot') },
          { label: 'Department & Office', render: u => `<span class="small">${esc(deptName(u.departmentId))} · ${esc(u.countyId ? countyName(u.countyId) : 'Head Office')}</span>` },
          { label: 'Password State', render: u => badge(u.mustChangePassword ? 'Awaiting 1st Login' : 'Private Set', u.mustChangePassword ? 'b-warn' : 'b-ok', 'nodot') },
          { label: '', cls: 'act', render: u => `<button class="btn btn-xs btn-primary" data-act="silent-override-start" data-id="${esc(u.id)}">${ic('eye', 12)} Silent Override</button>` }
        ], candidates.slice(0, 30)))
      + `<div style="margin-top:16px">${card('Silent Override Audit Log (`system.silent_override.*`)', table([
          { label: 'Seq', cls: 'num', render: a => `<span class="mono xs">${a.seq}</span>` },
          { label: 'Timestamp', render: a => `<span class="xs">${fmtDateTime(a.ts)}</span>` },
          { label: 'Event', render: a => badge(a.action, 'b-info', 'nodot') },
          { label: 'Target', render: a => `<span class="mono xs">${esc(a.entity)}:${esc(a.entityId)}</span>` },
          { label: 'Audit Detail', render: a => `<span class="small">${esc(a.detail)}</span>` },
          { label: 'Chain Hash', render: a => `<span class="mono xs muted">${esc(a.hash)}</span>` }
        ], overrideLogs, { emptyMsg: 'No silent override sessions have been initiated yet.' }))}</div>`;
    }

    if (tab === 'diagnostics') {
      const checks = [
        { name: 'Returning Patient Checker hidden from Media Department', pass: !RBAC.has({ roleId: 'media', status: 'active' }, 'patient.view.basic') && !RBAC.has({ roleId: 'media', status: 'active' }, 'intake.create') },
        { name: 'Clinical Assessment & Discharge hidden from HR Department', pass: !RBAC.has({ roleId: 'hr', status: 'active' }, 'patient.view.clinical') && !RBAC.has({ roleId: 'hr', status: 'active' }, 'clinical.assess') },
        { name: 'Homa Bay Kenya Reports restricted to Kisumu Head Office Admin', pass: ADMIN_OPS.canPrepareKenyaReport({ roleId: 'countyadmin', countyId: 'kisumu', status: 'active' }) && !ADMIN_OPS.canPrepareKenyaReport({ roleId: 'countyadmin', countyId: 'homabay', status: 'active' }) },
        { name: 'Silent Override restricted exclusively to Chief System Administrator', pass: SILENT_OVERRIDE.canOverride({ roleId: 'chief', status: 'active' }) && !SILENT_OVERRIDE.canOverride({ roleId: 'director', status: 'active' }) && !SILENT_OVERRIDE.canOverride({ roleId: 'it', status: 'active' }) },
        { name: 'Workspace Non-Zoom Fixed Shell (`--zoom: 1`)', pass: typeof getComputedStyle === 'function' ? getComputedStyle(document.documentElement).getPropertyValue('--zoom').trim() !== '0.9' : true },
        { name: 'Audit Trail Hash-Chain Integrity', pass: AUDIT.verify().ok }
      ];
      body = card('Live Architecture, Privacy & UI Invariant Checks', table([
        { label: 'Invariant Check', render: c => `<b>${esc(c.name)}</b>` },
        { label: 'Verification', render: c => badge(c.pass ? 'PASS' : 'FAIL', c.pass ? 'b-ok' : 'b-crit') }
      ], checks), {
        actions: `<button class="btn btn-xs btn-ghost" data-act="run-security-test">${ic('play', 12)} Run Full RBAC Self-Test</button>`
      });
    }

    return head + kpis + tabBar + body;
  }
};

Object.assign(ACTIONS, {
  'dev-tab': d => { DEV_CONSOLE_STATE.tab = d.tab || 'telemetry'; render(); },
  'dev-probe-cloud': () => DEV_CONSOLE.probeCloud(),
  'dev-open-reactivation': () => PROD_SETUP.openReactivationModal(false),
  'dev-open-recover-reactivation': () => PROD_SETUP.openReactivationModal(true),
  'dev-confirm-reactivation': () => PROD_SETUP.runReactivation(false),
  'dev-recover-reactivation': () => PROD_SETUP.runReactivation(true),
  'dev-gen-sms-pack': async () => {
    const pack = await PROD_SETUP.regeneratePackForMustChangeUsers();
    if (pack) { toast('SMS Credential Pack Generated', `${pack.count} unique strong passwords ready for SMS export.`, 'ok'); render(); }
  },
  'dev-dl-credentials': () => PROD_SETUP.downloadCredentialDocument(),
  'dev-dl-role-directory': () => PROD_SETUP.downloadRoleDirectory(),
  'dev-dl-sms-csv': () => PROD_SETUP.downloadCSV(),
  'dev-dl-sms-txt': () => PROD_SETUP.downloadSMSText(),
  'dl-whatsapp-txt': () => PROD_SETUP.downloadWhatsappTxt(),
  'copy-whatsapp-pack': () => PROD_SETUP.copyWhatsappSheet(),
  'open-global-activate': () => PROD_SETUP.openGlobalActivateModal(),
  'exec-global-activate': async () => {
    const f = document.querySelector('#globalActivateForm');
    const fd = f ? new FormData(f) : null;
    const emailDomain = fd ? fd.get('emailDomain') : PROD_SETUP.defaultEmailDomain();
    const loginUrl = fd ? fd.get('loginUrl') : PROD_SETUP.defaultPortalUrl();
    const wantAutoFeed = Boolean(fd && fd.get('autoFeedMaster'));
    const patientCount = (DB.db && Array.isArray(DB.db.patients)) ? DB.db.patients.length : 0;
    if (wantAutoFeed && patientCount < DEMO_REGISTER.patients && typeof REFERENCE_MASTER !== 'undefined' && typeof REFERENCE_MASTER.autoFeedFromCloud === 'function') {
      toast(`Feeding ${DEMO_REGISTER.patients.toLocaleString('en-GB')}-Patient Cloud Dataset…`, 'Verifying and committing the 100%-complete dataset into Cloud KV before Global Activation.', 'info');
      const fed = await REFERENCE_MASTER.autoFeedFromCloud({ silent: true });
      if (!fed || !fed.ok) {
        return toast('Cloud Dataset Auto-Feed Halted', (fed && fed.error) || `Could not auto-feed the ${DEMO_REGISTER.patients.toLocaleString('en-GB')}-patient dataset before activation.`, 'crit');
      }
    }
    const pack = await PROD_SETUP.activateSystemGlobally({ emailDomain, loginUrl });
    if (pack) {
      toast('CareLink System Activated Globally', `${pack.count} organogram accounts generated for WhatsApp dispatch. Demo & setup prompts permanently removed.`, 'ok');
      PROD_SETUP.openGlobalActivateModal();
      render();
    }
  },
  'silent-override-start': d => {
    const reasonEl = $('#silentOverrideReason');
    const reason = reasonEl ? reasonEl.value : DEV_CONSOLE_STATE.overrideReason;
    SILENT_OVERRIDE.enter(d.id, reason);
  },
  'silent-override-exit': () => SILENT_OVERRIDE.exit(),

  'dev-vcs-commit-modal': () => {
    VERSION_CONTROL.ensureStore();
    const nextNum = (DB.db.versionControl.snapshots || []).length + 1;
    openModal({
      title: 'Commit System Version Control Checkpoint',
      sub: 'Records a tagged configuration, custom-role & visual-pack snapshot with deterministic checksum.',
      wide: false,
      body: `<form id="vcsCommitForm">
        <div class="grid g2">
          <div class="field"><label>Version / Checkpoint Tag *</label>
            <input class="input mono" name="tag" value="v${esc(APP.version)}-cp${nextNum}" required>
          </div>
          <div class="field"><label>Change Category</label>
            <select class="input" name="category">
              <option>Configuration Checkpoint</option>
              <option>Roles &amp; Permissions Update</option>
              <option>Theme &amp; Font Pack Release</option>
              <option>Pre-Maintenance Safety Tag</option>
            </select>
          </div>
        </div>
        <div class="field"><label>Commit message / change notes *</label>
          <textarea class="input" name="message" rows="3" required placeholder="Describe the system configuration, role customisation or policy adjustment captured in this checkpoint..."></textarea>
        </div>
      </form>`,
      footer: `<button class="btn btn-ghost" data-act="close-modal">Cancel</button>
        <button class="btn btn-primary" data-act="dev-vcs-commit-save">${ic('save',14)} Commit Tag &amp; Snapshot</button>`
    });
  },

  'dev-vcs-commit-save': () => {
    const f = document.querySelector('#vcsCommitForm');
    if(!f) return;
    const fd = new FormData(f);
    const msg = String(fd.get('message')||'').trim();
    if(!msg) return toast('Commit message required','Describe what this checkpoint captures.','err');
    const actor = SILENT_OVERRIDE.realActor() || AUTH.user;
    const snap = VERSION_CONTROL.commitSnapshot({
      tag: fd.get('tag'),
      category: fd.get('category'),
      message: msg
    }, actor);
    closeModal(true);
    DEV_CONSOLE_STATE.tab = 'vcs';
    toast('Version Checkpoint Committed', `Tag ${snap.tag} (${snap.checksum}) saved to Version Control.`, 'ok');
    render();
  },

  'dev-vcs-diff': (d={}) => {
    const diffs = VERSION_CONTROL.diffAgainstLive(d.id);
    const snap = (DB.db.versionControl?.snapshots||[]).find(x=>x.id===d.id);
    if(!snap) return;
    openModal({
      title: `Compare Checkpoint ${snap.tag} vs Live System`,
      sub: `Snapshot taken ${fmtDateTime(snap.createdAt)} · Checksum ${snap.checksum}`,
      wide: true,
      body: table([
        { label:'Configuration Domain', cls:'mono', render:r=>`<b>${esc(r.key)}</b>` },
        { label:'Status', render:r=>badge(r.changed?'Modified Since Tag':'Identical', r.changed?'b-warn':'b-ok', false) },
        { label:'Checkpoint Value', render:r=>`<code class="xs mono" style="word-break:break-all">${esc(String(r.snapshotVal||'').slice(0,120))}</code>` },
        { label:'Live Value', render:r=>`<code class="xs mono" style="word-break:break-all">${esc(String(r.liveVal||'').slice(0,120))}</code>` }
      ], diffs),
      footer: `<button class="btn btn-ghost" data-act="close-modal">Close</button>`
    });
  },

  'dev-vcs-rollback': (d={}) => {
    const actor = SILENT_OVERRIDE.realActor() || AUTH.user;
    if(!actor || actor.roleId !== 'chief') return toast('Chief System Administrator Only','Only the Chief System Administrator may restore a configuration checkpoint.','err');
    const r = VERSION_CONTROL.rollbackConfig(d.id, actor);
    if(!r.ok) return toast('Restore failed', r.msg, 'err');
    toast('Checkpoint Restored', `Configuration restored to ${r.snap.tag} (${r.snap.checksum}) and logged in System Audit.`, 'ok');
    render();
  },

  'dev-vcs-export': () => {
    VERSION_CONTROL.ensureStore();
    const payload = {
      exportedAt: new Date().toISOString(),
      activeVersion: APP.version,
      schema: APP.schema,
      liveChecksum: VERSION_CONTROL.computeChecksum(),
      releases: VERSION_CONTROL.RELEASES,
      snapshots: DB.db.versionControl.snapshots
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type:'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `CareLink-VCS-Manifest-v${APP.version}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(a.href), 4000);
    toast('VCS Manifest Exported', `Downloaded ${a.download}.`, 'ok');
  }
});
